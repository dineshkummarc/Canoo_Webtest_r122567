This folder is used as a own Maven repository when we need extra dependencies that are not yet available in a public repository.

When it's empty, then it means that we only rely on artifacts available in public repositories