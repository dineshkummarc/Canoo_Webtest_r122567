// Copyright � 2004-2005 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.boundary;

import com.canoo.webtest.engine.StepExecutionException;
import com.canoo.webtest.extension.applet.AppletRunnerStep;
import com.canoo.webtest.steps.Step;
import org.apache.log4j.Logger;
import org.apache.tools.ant.taskdefs.Execute;
import org.apache.tools.ant.types.CommandlineJava;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Boundary class for {@link AppletRunnerStep}.
 *
 * @author Paul King
 */
public final class AppletRunnerStepBoundary
{
    private static final Logger LOG = Logger.getLogger(AppletRunnerStepBoundary.class);
    private AppletRunnerStepBoundary() {}

    public static CommandlineJava tryClone(final CommandlineJava fCommandline, final Step step) {
        try {
            return (CommandlineJava) fCommandline.clone();
        } catch (CloneNotSupportedException e) {
            throw new StepExecutionException(e.getMessage(), step);
        }
    }

    public static int tryExecute(final Execute execute, final Step step) {
        try {
            return execute.execute();
        } catch (IOException e) {
            final String message = "Execute fork failed: ";
            LOG.error(message, e);
            throw new StepExecutionException(message + e.getMessage(), step);
        }
    }

    public static URL tryGetUrlForClass(final String aClassName, final AppletRunnerStep step) {
        try {
            return AppletRunnerStep.getUrlForClass(aClassName);
        } catch (MalformedURLException e) {
            final String msg = e.getMessage() + " for class " + aClassName;
            LOG.error(msg, e);
            throw new StepExecutionException(msg, step);
        }
    }
}
