// Copyright � 2004-2005 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.boundary;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.cookie.CookieSpec;
import org.apache.log4j.Logger;

import com.gargoylesoftware.htmlunit.WebClient;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper class for interacting with HttpClient.
 *
 * @author Paul King
 */
public final class HttpClientBoundary
{
    private HttpClientBoundary() {}

    private static final Logger LOG = Logger.getLogger(HttpClientBoundary.class);
    private static final Cookie[] EMPTY_COOKIE_JAR = new Cookie[0];

    /**
     * Retrieve cookie array from HttpClient state.
     *
     * Wraps a HttpClient BUG.
     *
     * @param stateForUrl
     * @param url
     * @return the retrieved cookies (or an empty cookie array if no state found)
     */
    public static Cookie[] getCookiesFromState(final WebClient webClient, final URL url) {
        final boolean secure = "https".equals(url.getProtocol());
        final int port;
        if (url.getPort() != -1) {
            port = url.getPort();
        }
        else {
            port = url.getDefaultPort();
        }

        final CookieSpec cookieSpec = CookiePolicy.getDefaultSpec();
        final List<Cookie> cookies = new ArrayList<Cookie>();
        for (final Cookie cookie : webClient.getCookieManager().getCookies())
        {
        	if (cookieSpec.match(url.getHost(), port,
                url.getPath(), secure, cookie))
        	{
        		cookies.add(cookie);
        	}
        }

        return cookies.toArray(new Cookie[]{});
    }

}
