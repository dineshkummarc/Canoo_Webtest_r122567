// Copyright � 2004-2005 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.boundary;

import com.canoo.webtest.extension.applet.AbstractAppletTag;
import com.canoo.webtest.extension.applet.runner.Context;
import org.apache.log4j.Logger;
import org.netbeans.jemmy.JemmyException;

import java.net.MalformedURLException;
import java.net.URLClassLoader;

/**
 * Boundary class for {@link com.canoo.webtest.extension.applet.runner.AppletRunner}.
 *
 * @author Paul King
 */
public class AppletRunnerBoundary
{
    private static final Logger LOG = Logger.getLogger(AppletRunnerBoundary.class);

    public static Object assertObjectHasCorrectClass(final Class expectedClass, final Object object, final String msg) throws Exception {
        if (expectedClass.isInstance(object)) {
            return object;
        }
        final String error = "Expected class " + expectedClass + " but found " + object.getClass().getName();
        LOG.error(msg + error);
        throw new Exception(msg + error);
    }

    public static URLClassLoader tryCreateUrlClassLoader(final AbstractAppletTag appletTag, final ClassLoader classLoader) throws Exception {
        try {
            return new URLClassLoader(appletTag.getArchiveURL(), classLoader);
        } catch (MalformedURLException e) {
            final String msg = "Can't build classpath url for " + appletTag.getCode();
            LOG.error(msg, e);
            throw new Exception(msg + " " + e.getMessage());
        }
    }

    public static void storeJemmyExceptionIfNeeded(final JemmyException jemmyException, final Context appletContext) {
        if (jemmyException != null) {
            appletContext.getAppletPluginResults().setJemmyException(jemmyException);
            LOG.error(jemmyException.getMessage(), jemmyException);
        }
    }

    public void processClassNotFound(final int classNotFoundErrorCode) {
        System.exit(classNotFoundErrorCode);
    }

    public void processIoException(final int ioErrorCode) {
        System.exit(ioErrorCode);
    }
}
