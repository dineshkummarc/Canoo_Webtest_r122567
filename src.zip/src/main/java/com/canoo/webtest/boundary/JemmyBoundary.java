package com.canoo.webtest.boundary;

import org.netbeans.jemmy.Waiter;
import org.netbeans.jemmy.Waitable;
import org.netbeans.jemmy.JemmyException;
import com.canoo.webtest.extension.applet.runner.Context;

/**
 * Boundary class for interacting with Jemmy.
 *
 * @author Paul King
 */
public final class JemmyBoundary {
    private JemmyBoundary() {}

    public static void tryWaitAction(final Waiter stateWaiter, final Waitable state, final Context context) {
        try {
            stateWaiter.waitAction(context);
        } catch (InterruptedException e) {
            throw new JemmyException("Waiting of '" + state.getDescription() + "' has been interrupted!");
        }
    }
}
