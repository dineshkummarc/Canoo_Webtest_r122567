// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.security;


/**
 * @author Carsten Seibert
 */
public class ConnectionInitializationException extends Exception
{

    public ConnectionInitializationException(String s) {
        super(s);
    }
}
