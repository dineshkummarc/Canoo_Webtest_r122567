package com.canoo.webtest.extension.applet;

import com.gargoylesoftware.htmlunit.html.HtmlApplet;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlObject;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Denis N. Antonioli
 */
public abstract class AbstractAppletTag implements Serializable {
	private static final Logger LOG = Logger.getLogger(AbstractAppletTag.class);
	private final URL fBase;
	private final Map fParameter;
	/**
	 * Specifies the initial width of the applet's display area (excluding any windows or dialogs that the applet creates).
	 * <p>Required attribute.
	 */
	public static final String ATTR_WIDTH = "WIDTH";
	/**
	 * Specifies the initial height of the applet's display area (excluding any windows or dialogs that the applet
	 * creates). <p>Required attribute.
	 */
	public static final String ATTR_HEIGHT = "HEIGHT";
	/**
	 * Specifies either the name of the class file that contains the applet's compiled applet subclass or the path to get
	 * the class, including the class file itself. It is interpreted with respect to the applet's codebase. <p>One of
	 * {@link #ATTR_CODE code} or {@link #ATTR_OBJECT object} must be present.
	 */
	public static final String ATTR_CODE = "CODE";
	/**
	 * Specifies a name for the applet instance, which makes it possible for applets on the same page to find (and
	 * communicate with) each other.
	 */
	public static final String ATTR_NAME = "NAME";
	/**
	 * Specifies the base URI for the applet. If this attribute is not specified, then it defaults the same base URI as for
	 * the current document. Values for this attribute may only refer to subdirectories of the directory containing the
	 * current document.
	 */
	public static final String ATTR_CODEBASE = "CODEBASE";
	/**
	 * Names a resource containing a serialized representation of an applet's state. It is interpreted relative to the
	 * applet's codebase. The serialized data contains the applet's class name but not the implementation. The class name
	 * is used to retrieve the implementation from a class file or archive. <p>When the applet is "deserialized" the
	 * start() method is invoked but not the init() method. Attributes valid when the original object was serialized are
	 * not restored. Any attributes passed to this APPLET instance will be available to the applet. Authors should use this
	 * feature with extreme caution. An applet should be stopped before it is serialized. <p>Either code or object must be
	 * present. If both {@link #ATTR_CODE code} and {@link #ATTR_OBJECT object} are given, it is an error if they provide
	 * different class names.
	 */
	public static final String ATTR_OBJECT = "OBJECT";
	public static final String ATTR_ARCHIVE = "ARCHIVE";

	static final List PARAM;

	static {
		PARAM = new ArrayList();
		PARAM.add("param");
	}


	{
		fParameter = new HashMap();
		addParameterObject(AbstractAppletTag.ATTR_ARCHIVE, new ArrayList());
		addParameterLength(AbstractAppletTag.ATTR_WIDTH, "0");
		addParameterLength(AbstractAppletTag.ATTR_HEIGHT, "0");
	}

	public AbstractAppletTag(String base) throws MalformedURLException {
		fBase = makeDirectoryURL(base);
		addParameterObject(AbstractAppletTag.ATTR_CODEBASE, fBase);
	}

	protected static URL makeDirectoryURL(String base) throws MalformedURLException {
		final URL url = new URL(base);
		String path = url.getPath();
		int lastSlash = path.lastIndexOf('/');
		return new URL(url.getProtocol(), url.getHost(), url.getPort(), path.substring(0, 1 + lastSlash));
	}

	public void setArchive(String value) {
		List archive = (List) getParameterObject(AbstractAppletTag.ATTR_ARCHIVE);
		for (StringTokenizer st = new StringTokenizer(value, ", "); st.hasMoreTokens();) {
			archive.add(st.nextToken());
		}
	}

	public List getArchive() {
		return (List) getParameterObject(AbstractAppletTag.ATTR_ARCHIVE);
	}

	public String getCode() {
		String code = getParameter(AbstractAppletTag.ATTR_CODE);
		if (code.endsWith(".class")) {
			return code.substring(0, code.length() - ".class".length());
		}
		return code;
	}

	/**
	 * Specifies the base URI for the current document.
	 */
	public URL getBase() {
		return fBase;
	}

	public URL getCodebase() {
		return (URL) getParameterObject(AbstractAppletTag.ATTR_CODEBASE);
	}

	/**
	 * Sets the code base URI. Resolves the uri in the context of the existing URI if it is relative.
	 *
	 * @param codeBase The new code base URI.
	 * @throws java.net.MalformedURLException
	 */
	public void setCodebase(final String codeBase) throws MalformedURLException {
		URL codebase = new URL(fBase, codeBase + (codeBase.endsWith("/") ? "" : "/"));
		if (!codebase.getHost().equals(fBase.getHost())) {
			LOG.info("According to the JavaPlugin, the URL can be relative or absolute but it should be in the domain of the current document.");
		}
		if (!codebase.getPath().startsWith(fBase.getPath())) {
			LOG.info("According to HTML 4.0, the codebase may only refer to subdirectories of the directory containing the current document");
		}
		addParameterObject(AbstractAppletTag.ATTR_CODEBASE, codebase);
	}

	public String getHeight() {
		return getParameter(AbstractAppletTag.ATTR_HEIGHT);
	}

	public String getName() {
		return getParameter(AbstractAppletTag.ATTR_NAME);
	}

	public void addParameter(final String name, final String value) throws MalformedURLException {
		if (AbstractAppletTag.ATTR_WIDTH.equalsIgnoreCase(name) || AbstractAppletTag.ATTR_HEIGHT.equalsIgnoreCase(name)) {
			addParameterLength(name, value);
		} else if (AbstractAppletTag.ATTR_CODEBASE.equalsIgnoreCase(name)) {
			setCodebase(value);
		} else if (AbstractAppletTag.ATTR_ARCHIVE.equalsIgnoreCase(name)) {
			setArchive(value);
		} else {
			addParameterObject(name, value);
		}
	}

	protected void addParameterObject(final String key, final Object base) {
		fParameter.put(key.toUpperCase(Locale.US), base);
	}

	private Object getParameterObject(final String key) {
		return fParameter.get(key.toUpperCase(Locale.US));
	}

	/**
	 * Adds an html length to the parameter map. In html, a length is either an absolute number of pixel,
	 * <code>[<b>0</b>-<b>9</b>]+</code>, or a percentage of the available space, <code>[<b>0</b>-<b>9</b>]+<b>%</b></code>.
	 *
	 * @param name   The name of the parameter.
	 * @param length The value of the parameter.
	 * @throws NumberFormatException If value is not an html length.
	 */
	public void addParameterLength(final String name, final String length) throws NumberFormatException {
		if (length.endsWith("%")) {
			Integer.parseInt(length.substring(0, length.length() - 1));
		} else {
			Integer.parseInt(length);
		}
		addParameterObject(name, length);
	}

	/**
	 * Browser Note:� Although at least one Java-enabled browser conducts a case-sensitive search, the expected behavior is
	 * for the getApplet method to perform a case-insensitive search. For example, getApplet("old pal") and getApplet("OLD
	 * PAL") should both find an applet named "Old Pal".
	 *
	 * @param name The name of the parameter.
	 * @return The value for the parameter, or null.
	 */
	public String getParameter(final String name) {
		Object value = fParameter.get(name.toUpperCase(Locale.US));
		if (value == null) {
			return null;
		}
		if (value instanceof URL) {
			return ((URL) value).toExternalForm();
		}
		if (value instanceof List) {
			StringBuffer arc = new StringBuffer();
			for (Iterator iterator = ((List) value).iterator(); iterator.hasNext();) {
				arc.append((String) iterator.next()).append(", ");
			}
			if (arc.length() > 2) {
				arc.setLength(arc.length() - 2);
			}
			return arc.toString();
		}
		return (String) value;
	}

	public String getWidth() {
		return getParameter(AbstractAppletTag.ATTR_WIDTH);
	}

	public URL[] getArchiveURL() throws MalformedURLException {
		List archive = (List) getParameterObject(AbstractAppletTag.ATTR_ARCHIVE);
		URL[] urls = new URL[archive.size() + 1];
		URL codebase = getCodebase();
		for (int i = 0; i < urls.length - 1; i++) {
			urls[i] = new URL(codebase, (String) archive.get(i));
			LOG.info(urls[i].toExternalForm());
		}
		urls[urls.length - 1] = codebase;
		return urls;
	}

	/**
	 * @param base       The base URI for the current document.
	 * @param appletNode
	 * @return The parsed element.
	 * @throws NoSuchFieldException           If a required attribute is missing from the html declaration.
	 * @throws java.net.MalformedURLException If there is an error in the base or the codebase attribute.
	 * @throws IllegalArgumentException If the name of the element isn't known.
	 */
	static AbstractAppletTag newInstance(final URL base, final HtmlElement appletNode) throws NoSuchFieldException, MalformedURLException, IllegalArgumentException {
		AbstractAppletTag appletTag;
		if (appletNode instanceof HtmlApplet) {
			appletTag = new AppletTag(base.toExternalForm());
		} else if (appletNode instanceof HtmlObject) {
			appletTag = new ObjectTag(base.toExternalForm());
		} else {
			throw new IllegalArgumentException("Don't know how to handle element <" + appletNode.getTagName() + ">.");
		}

		appletTag.addsAllAttributes(appletNode);
		appletTag.addsAllParameters(appletNode);
		return appletTag;
	}

	protected abstract void addsAllAttributes(final HtmlElement appletNode) throws NoSuchFieldException, MalformedURLException;

    protected void addsAllParameters(HtmlElement appletNode) throws NoSuchFieldException, MalformedURLException {
        for (Iterator iterator = appletNode.getHtmlElementsByTagNames(PARAM).iterator(); iterator.hasNext();) {
            HtmlElement paramNode = (HtmlElement) iterator.next();
            String name = paramNode.getAttribute("name");
            if (name == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
                throw new NoSuchFieldException("Attribute name of param is missing.");
            }
            String value = paramNode.getAttribute("value");
            if (value == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
                LOG.info("Skipping parameter named '" + name + "', it has no value.");
            } else {
                addParameter(name, value);
            }
        }
    }
}
