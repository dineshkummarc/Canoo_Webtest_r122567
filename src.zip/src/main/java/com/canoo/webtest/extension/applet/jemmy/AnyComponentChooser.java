// Copyright (c) 2002-2005 Canoo Engineering AG, Switzerland. All Rights Reserved.

package com.canoo.webtest.extension.applet.jemmy;



import org.netbeans.jemmy.ComponentChooser;

import java.awt.Component;



/**

 * Accepts any components.

 * This chooser is to be used to wait for components identified by their index:

 * <pre>

 * JTextFieldOperator.waitJTextField(secOper, <em>new AnyComponentChooser()</em>, index);

 * </pre>.

 */

public class AnyComponentChooser implements ComponentChooser {

    public static final ComponentChooser ANY_COMPONENT_CHOOSER;



    static {

        ANY_COMPONENT_CHOOSER = new AnyComponentChooser();

    }



    public boolean checkComponent(Component component) {

        return true;

    }



    public String getDescription() {

        return "Accepts any components.";

    }

}

