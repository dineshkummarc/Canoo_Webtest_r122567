package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;

/**
 * @author Denis N. Antonioli
 */
public class SwingStub extends AbstractAppletStub {
	private final JLabel fStatusLabel;

	SwingStub(final Context context,
	          final JApplet applet,
	          final AbstractAppletTag appletTag,
	          final String baseWindowName) {
		super(context, applet, appletTag, new JFrame(), baseWindowName);
		JFrame frame = (JFrame) getRootFrame();
		frame.setSize(getAppletDimension());
		frame.getContentPane().add(applet, BorderLayout.CENTER);
		fStatusLabel = new JLabel("");
		fStatusLabel.setName(APPLET_STATUS_NAME);
		frame.getContentPane().add(fStatusLabel, BorderLayout.SOUTH);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	public void showStatus(String status) {
		fStatusLabel.setText(status);
	}
}
