package com.canoo.webtest.extension.applet;

import com.canoo.webtest.engine.NameValuePair;

/**
 * @author Denis N. Antonioli
 * @webtest.nested
 * category="Extension"
 * name="parameter"
 * description="Pass an arbitary name/value pair to a scenario."
 */
public class Parameter extends NameValuePair {

    /**
     * Empty constructor for Ant.
     */
    public Parameter() {
    }

    public Parameter(String name, String value) {
        setName(name);
        setValue(value);
    }

	/**
	 * @webtest.parameter
	 * required="yes"
	 * description="The name of the parameter in the scenario."
	 */
	public void setName(String name) {
		super.setName(name);
	}

	/**
	 * @webtest.parameter
	 * required="yes"
	 * description="The value of the parameter in the scenario."
	 */
	public void setValue(String value) {
		super.setValue(value);
	}
}
