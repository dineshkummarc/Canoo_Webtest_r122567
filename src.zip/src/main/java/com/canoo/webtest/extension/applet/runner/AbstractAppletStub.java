package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;

import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.awt.Dimension;
import java.awt.Frame;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public abstract class AbstractAppletStub implements AppletStub {

	/**
	 * The name of the status label. Use this for the test scenario to check the status of an applet.
	 */
	public static final String APPLET_STATUS_NAME = "AppletStatus";

	private final AbstractAppletTag fAppletTag;
	private final Frame fFrame;
	private final Applet fApplet;
	private final com.canoo.webtest.extension.applet.runner.Context fAppletContext;
	private boolean fIsActive;

	AbstractAppletStub(final Context context,
	                   final Applet applet,
	                   final AbstractAppletTag appletTag,
	                   final Frame frame,
	                   final String baseWindowName) {
		fAppletTag = appletTag;
		applet.setStub(this);
		fApplet = applet;
		fFrame = frame;
		fAppletContext = context;
		fFrame.setTitle("Webtest - " + baseWindowName + " - "+ applet.getName());
	}

	public AppletContext getAppletContext() {
		return fAppletContext;
	}

	public Frame getRootFrame() {
		return fFrame;
	}

	Dimension getAppletDimension() {
		String widthS = fAppletTag.getWidth();
		int last = widthS.length();
		if (widthS.endsWith("%")) {
			last--;
		}
		int width = Integer.parseInt(widthS.substring(0, last));

		String heightS = fAppletTag.getHeight();
		last = heightS.length();
		if (heightS.endsWith("%")) {
			last--;
		}
		int height = Integer.parseInt(heightS.substring(0, last));
		return new Dimension(width, height);
	}

	public abstract void showStatus(String status);

	void show() {
		fFrame.show();
	}

	public void appletResize(int width, int height) {
		fFrame.setSize(width, height);
	}

	public URL getDocumentBase() {
		return fAppletTag.getBase();
	}

	public URL getCodeBase() {
		return fAppletTag.getCodebase();
	}

	public String getParameter(String name) {
		return fAppletTag.getParameter(name);
	}

	public boolean isActive() {
		return fIsActive;
	}

	void init() {
		fApplet.init();
	}

	void start() {
		fIsActive = true;
		fApplet.start();
	}

	void stop() {
		fApplet.stop();
		fIsActive = false;
	}

	void destroy() {
		fApplet.destroy();
	}

	Applet getApplet() {
		return fApplet;
	}
}
