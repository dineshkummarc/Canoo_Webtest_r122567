package com.canoo.webtest.extension.applet.runner;

/*
 * Copyright (C) The Apache Software Foundation. All rights reserved.
 *
 * This software is published under the terms of the Apache Software
 * License version 1.1, a copy of which has been included with this
 * distribution in the LICENSE.APL file.
 */

import com.canoo.webtest.util.Checker;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import java.io.IOException;
import java.io.OutputStream;

/**
 * An OutputStream that flushes out to a Logger. <p> Note that no data is written out to the logger until the stream is
 * flushed or closed.
 * <p> Example:<pre>
 * // make sure everything sent to System.err is logged
 * System.setErr(new PrintStream(new LoggingOutputStream(Category.getRoot(), Priority.WARN), true));
 * // make sure everything sent to System.out is also logged
 * System.setOut(new PrintStream(new LoggingOutputStream(Category.getRoot(), Priority.INFO), true));
 * </pre>
 *
 * @author <a href="mailto://Jim.Moore@rocketmail.com">Jim Moore</a>
 * @author Denis N. Antonioli
 */
public class LoggingOutputStream extends OutputStream {
    static final String LINE_SEPARATOR = System.getProperty("line.separator");

    /**
     * Used to maintain the contract of {@link #close()}.
     */
    private boolean fHasBeenClosed;

    /**
     * The internal buffer where data is stored.
     */
    private byte fBuf[];

    /**
     * The number of valid bytes in the buffer. This value is always in the range <tt>0</tt> through <tt>buf.length</tt>;
     * elements <tt>buf[0]</tt> through <tt>buf[count-1]</tt> contain valid byte data.
     */
    private int fCount;

    /**
     * Remembers the size of the buffer for speed.
     */
    private int fBufLength;

    /**
     * The default number of bytes in the buffer.
     */
    public static final int DEFAULT_BUFFER_LENGTH = 2048;

    /**
     * The logger to write to.
     */
    private final Logger fLogger;

    /**
     * The priority to use when writing to the Category.
     */
    private final Priority fPriority;
    /**
     * The last framework class for Log4j. Log4j generates a stack trace and uses the first entry after the named class as
     * the location in a log entry.
     */
    private final String fLastFrameworkClassName;

    {
        fBuf = new byte[DEFAULT_BUFFER_LENGTH];
        fBufLength = fBuf.length;
    }

    /**
     * Creates the LoggingOutputStream to flush to the given Category.
     *
     * @param lastFrameworkClass The last class for log4j to ignore in a stack trace.
     * @param log                The Logger to write to.
     * @param priority           The Priority to use when writing to the Logger.
     * @throws IllegalArgumentException if one of the argument is null.
     */
    public LoggingOutputStream(final Class lastFrameworkClass, Logger log, Priority priority) {
        Checker.assertNonNull(lastFrameworkClass, "lastFrameworkClass cannot be null");
        Checker.assertNonNull(log, "log cannot be null");
        Checker.assertNonNull(priority, "priority cannot be null");

        fPriority = priority;
        fLogger = log;
        fLastFrameworkClassName = lastFrameworkClass.getName();
    }

    /**
     * Closes this output stream and releases any system resources associated with this stream. The general contract of
     * <code>close</code> is that it closes the output stream. A closed stream cannot perform output operations and cannot
     * be reopened.
     */
    public void close() {
        flush();
        fHasBeenClosed = true;
    }

    String getLastFrameworkClassName() {
        return fLastFrameworkClassName;
    }

    Priority getPriority() {
        return fPriority;
    }

    Logger getLogger() {
        return fLogger;
    }

    int getCount() {
        return fCount;
    }

    /**
     * Writes the specified byte to this output stream. The general contract for <code>write</code> is that one byte is
     * written to the output stream. The byte to be written is the eight low-order bits of the argument <code>b</code>. The
     * 24 high-order bits of <code>b</code> are ignored.
     *
     * @param b the <code>byte</code> to write
     * @throws IOException if an I/O error occurs. In particular, an <code>IOException</code> may be thrown if the output
     *                     stream has been closed.
     */
    public void write(final int b) throws IOException {
        if (fHasBeenClosed) {
            throw new IOException("The stream has been closed.");
        }

        // don't log nulls
        if (b == 0) {
            return;
        }

        // would this be writing past the buffer?
        if (fCount == fBufLength) {
            // grow the buffer
            final int newBufLength = fBufLength + DEFAULT_BUFFER_LENGTH;
            final byte[] newBuf = new byte[newBufLength];

            System.arraycopy(fBuf, 0, newBuf, 0, fBufLength);

            fBuf = newBuf;
            fBufLength = fBuf.length;
        }

        fBuf[fCount++] = (byte) b;
    }

    /**
     * Flushes this output stream and forces any buffered output bytes to be written out. The general contract of
     * <code>flush</code> is that calling it is an indication that, if any bytes previously written have been buffered by
     * the implementation of the output stream, such bytes should immediately be written to their intended destination.
     */
    public void flush() {
        if (fCount == 0) {
            return;
        }

        // don't print out blank lines; flushing from PrintStream puts out these
        if (fCount == LINE_SEPARATOR.length()) {
            if (((char) fBuf[0]) == LINE_SEPARATOR.charAt(0) &&
               ((fCount == 1) || // <- Unix & Mac, -> Windows
               ((fCount == 2) && ((char) fBuf[1]) == LINE_SEPARATOR.charAt(1)))) {
                reset();
                return;
            }
        }

        fLogger.log(fLastFrameworkClassName, fPriority, new String(fBuf, 0, fCount), null);

        reset();
    }

    private void reset() {
        // not resetting the buffer -- assuming that if it grew that big
        //   it will likely grow similarly again
        fCount = 0;
    }

}