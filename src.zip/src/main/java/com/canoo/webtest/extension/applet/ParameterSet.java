package com.canoo.webtest.extension.applet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.MapIterator;
import org.apache.commons.collections.iterators.EntrySetMapIterator;

import com.canoo.webtest.steps.Step;

/**
 * @author Denis N. Antonioli
 */
public class ParameterSet {
	public static final Pattern PATTERN_SLASH_DIGITS;

	private final List fParameters = new ArrayList();

	static {
		PATTERN_SLASH_DIGITS = Pattern.compile("\\\\\\d+");
	}

	public void expandProperties(final Step step) {
		final List expandedParam = new ArrayList();
		for (Iterator iterator = fParameters.iterator(); iterator.hasNext();) {
			final Object obj = iterator.next();
			if (obj instanceof Parameter) {
				final Parameter param = (Parameter) obj;
				param.setName(step.getProject().replaceProperties(param.getName()));
				param.setValue(step.getProject().replaceProperties( param.getValue()));
			} 
			else {
				iterator.remove();
				final ParameterRef param = (ParameterRef) obj;
				param.setName(step.getProject().replaceProperties(param.getName()));
				param.setRegex(step.getProject().replaceProperties(param.getRegex()));
				expandedParam.addAll(addMatchedParameters(step, param));
			}
		}
		// add here, so as not to expand the matched properties?
		fParameters.addAll(expandedParam);
	}

	static List addMatchedParameters(final Step step, final ParameterRef paramRef) {
		final List expandedParam = new ArrayList();
		final Pattern pattern = Pattern.compile(paramRef.getRegex());
		for (MapIterator iterator = new EntrySetMapIterator(step.getWebtestProperties(paramRef.getPropertyType()));
		     iterator.hasNext();) {
			final Matcher matcher = pattern.matcher((String) iterator.next());
			if (matcher.matches()) {
				expandedParam.add(new Parameter(replaceGroups(paramRef.getName(), matcher), (String) iterator.getValue()));
			}
		}
		return expandedParam;
	}

	static String replaceGroups(final String name, final Matcher allSubstitutions) {
		final StringBuffer sb = new StringBuffer();

		final Matcher nameMatcher = PATTERN_SLASH_DIGITS.matcher(name);
		while (nameMatcher.find()) {
			final String matched = nameMatcher.group();
			final int i = Integer.parseInt(matched.substring(1));
			nameMatcher.appendReplacement(sb, i > allSubstitutions.groupCount() ? ("\\"+matched) : allSubstitutions.group(i));
		}
		nameMatcher.appendTail(sb);

		return sb.toString();
	}

	public void add(final Parameter param) {
		fParameters.add(param);
	}

	public void add(final ParameterRef param) {
		fParameters.add(param);
	}

	public Iterator iterator() {
		return fParameters.iterator();
	}
}
