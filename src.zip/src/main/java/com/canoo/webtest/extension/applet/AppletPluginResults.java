/*
 * Copyright (c) 2004 Your Corporation. All Rights Reserved.
 */
package com.canoo.webtest.extension.applet;

import com.canoo.webtest.steps.Step;
import org.netbeans.jemmy.JemmyException;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Denis N. Antonioli
 */
public class AppletPluginResults implements Serializable {
	private final Map fFrames;
	private final List fProperties;

	private Integer fReturnValue;
	private String fException;
	private String fJemmyException;

	{
		fFrames = new HashMap();
		fProperties = new ArrayList();
	}

	public void setFrame(String target, URL url) {
		fFrames.put(target, url);
	}

	public Map getFrames() {
		return fFrames;
	}

	public void setReturnValue(Integer returnValue) {
		fReturnValue = returnValue;
	}

	public Integer getReturnValue() {
		return fReturnValue;
	}

	public void setException(Throwable exception) {
//		if (exception instanceof JemmyException) {
//
//		}
		fException = getExceptionMessage(exception);
	}

	private static String getExceptionMessage(Throwable exception) {
		final String message = exception.getMessage();
		if (message != null) {
			return message;
		}
		return exception.toString();
	}

	public String getException() {
		return fException;
	}

	public void setJemmyException(JemmyException jemmyException) {
		fJemmyException = getExceptionMessage(jemmyException);
	}

	public String getJemmyException() {
		return fJemmyException;
	}

	public void setProperty(final String name, final String value, final String propertyType) {
		fProperties.add(new Property(name, value, propertyType));
	}

	public List getProperties() {
		return fProperties;
	}

	public static class Property implements Serializable {
		public static final String DEFAULT = Step.PROPERTY_TYPE_DEFAULT;
		public static final String ANT = Step.PROPERTY_TYPE_ANT;
		public static final String DYNAMIC = Step.PROPERTY_TYPE_DYNAMIC;

		private final String fName;
		private final String fValue;
		private final String fType;

		public Property(final String name, final String value, final String type) {
			fName = name;
			fValue = value;
			fType = type;
		}

		public String getName() {
			return fName;
		}

		public String getValue() {
			return fValue;
		}

		public String getType() {
			return fType;
		}
	}
}
