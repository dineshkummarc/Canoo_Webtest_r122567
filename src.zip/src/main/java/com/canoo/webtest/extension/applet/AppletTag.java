package com.canoo.webtest.extension.applet;

import com.gargoylesoftware.htmlunit.html.HtmlElement;

import java.net.MalformedURLException;


/**
 * The content of an applet tag. <p>Element specification according to <em>HTML 4.01 Specification</em>. <p>TODO: case
 * insensitive <br>Browser Note:� Although at least one Java-enabled browser conducts a case-sensitive search, the
 * expected behavior is for the getApplet method to perform a case-insensitive search. For example, getApplet("old pal")
 * and getApplet("OLD PAL") should both find an applet named "Old Pal".
 *
 * @author Denis N. Antonioli
 */
public class AppletTag extends AbstractAppletTag {

	public AppletTag(String base) throws MalformedURLException {
		super(base);
	}

	protected void addsAllAttributes(HtmlElement appletNode) throws NoSuchFieldException, MalformedURLException {
		String attr = appletNode.getAttribute("code");
		if (attr == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			throw new NoSuchFieldException("Applet element does not define the code.");
		}
		addParameter(AbstractAppletTag.ATTR_CODE, attr);

		attr = appletNode.getAttribute("width");
		if (attr == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			throw new NoSuchFieldException("Applet element does not define the width.");
		}
		addParameterLength(AbstractAppletTag.ATTR_WIDTH, attr);

		attr = appletNode.getAttribute("height");
		if (attr == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			throw new NoSuchFieldException("Applet element does not define the height.");
		}
		addParameterLength(AbstractAppletTag.ATTR_HEIGHT, attr);

		attr = appletNode.getAttribute("archive");
		if (attr != HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			setArchive(attr);
		}
		attr = appletNode.getAttribute("name");
		if (attr != HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			addParameter(AbstractAppletTag.ATTR_NAME, attr);
		}
		attr = appletNode.getAttribute("codebase");
		if (attr != HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			setCodebase(attr);
		}
		if (appletNode.getAttribute("object") != HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			throw new NoSuchFieldException("Attribute object is not supported.");
		}
	}

}
