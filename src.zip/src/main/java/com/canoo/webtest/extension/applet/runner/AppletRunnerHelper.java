// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.boundary.StreamBoundary;
import com.canoo.webtest.boundary.AppletRunnerBoundary;
import com.canoo.webtest.extension.applet.AppletPluginArguments;
import org.apache.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * Helper class for applet test scenarii.
 * @author Denis N. Antonioli
 * @author Paul King
 */
public class AppletRunnerHelper {
    private static final Logger LOG = Logger.getLogger(AppletRunnerHelper.class);
    private final int fClassNotFoundErrorCode;
    private final int fIoErrorCode;
    private final AppletRunnerBoundary fBoundary;

    public AppletRunnerHelper(int classNotFoundErrorCode, int ioErrorCode, AppletRunnerBoundary boundary) {
        fClassNotFoundErrorCode = classNotFoundErrorCode;
        fIoErrorCode = ioErrorCode;
        fBoundary= boundary;
    }

    public AppletPluginArguments readPluginArguments(String file) {
        FileInputStream fis = null;
        ObjectInputStream ois = null;
		try {
			fis = new FileInputStream(file);
			ois = createObjectInputStream(fis);
			return (AppletPluginArguments) readObject(ois);
		} catch (ClassNotFoundException e) {
            LOG.error("Can't deserialize the arguments.", e);
            fBoundary.processClassNotFound(fClassNotFoundErrorCode);
        } catch (IOException e) {// as well as FileNotFoundException
            LOG.error("Can't read the arguments file.", e);
            fBoundary.processIoException(fIoErrorCode);
        } finally {
            StreamBoundary.closeInputStream(ois);
            StreamBoundary.closeInputStream(fis);
        }
		return null;
	}

    protected ObjectInputStream createObjectInputStream(FileInputStream fis) throws IOException {
        return new ObjectInputStream(fis);
    }

    protected Object readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        return ois.readObject();
    }

}
