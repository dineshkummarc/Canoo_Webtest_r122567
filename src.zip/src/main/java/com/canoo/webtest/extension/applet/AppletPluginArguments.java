package com.canoo.webtest.extension.applet;

import org.apache.commons.httpclient.Cookie;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

/**
 * @author Denis N. Antonioli
 */
public class AppletPluginArguments implements Serializable {
	private static final Logger LOG = Logger.getLogger(AppletPluginArguments.class);
	static final URL[] EMPTY_URL_LIST = new URL[0];

	private URL fScenarioLocation[];
	private String fScenario;
	private AbstractAppletTag fAppletTag;
	private final Map fArguments;
	private File fOutputFile;
	private boolean fSaveResponse;
	private File fSaveDirectory;
	private String fBaseWindowName;
	private final List fCookies;

	{
		fCookies = new ArrayList();
		fArguments = new HashMap();
		fScenarioLocation = EMPTY_URL_LIST;
	}

	public URL[] getScenarioLocation() {
		LOG.debug("get scenario location\n" + listURLs(fScenarioLocation));
		return fScenarioLocation;
	}

	public void setScenarioLocation(URL[] newScenarioLocation) {
		URL[] scenarioLocation = newScenarioLocation;
		if (scenarioLocation == null) {
			scenarioLocation = EMPTY_URL_LIST;
		}
		LOG.debug("set scenario location\n" + listURLs(scenarioLocation));
		fScenarioLocation = scenarioLocation;
	}

	private static String listURLs(URL[] scenarioLocation) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < scenarioLocation.length; i++) {
			sb.append("   ").append(scenarioLocation[i].toExternalForm()).append("\n");
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
        return sb.toString();
	}

	public String getScenario() {
		return fScenario;
	}

	public void setScenario(String scenario) {
		LOG.debug("set scenario " + scenario);
		fScenario = scenario;
	}

	public AbstractAppletTag getAppletTag() {
		return fAppletTag;
	}

	public void setAppletTag(AbstractAppletTag appletTag) {
		fAppletTag = appletTag;
	}

	public boolean hasArguments() {
		return !fArguments.isEmpty();
	}

	public void addArgument(Parameter parameter) {
		LOG.debug("add parameter " + parameter.getName() + " to " + parameter.getValue());
		fArguments.put(parameter.getName(), parameter.getValue());
	}

	public String getArgument(String name) {
		return (String) fArguments.get(name);
	}

	public Iterator getArguments() {
		return fArguments.entrySet().iterator();
	}

	public void setOutputFile(File outputFile) {
		LOG.debug("set output file " + outputFile);
		fOutputFile = outputFile;
	}

	public File getOutputFile() {
		return fOutputFile;
	}

	public void setSaveResponse(boolean saveResponse) {
		LOG.debug("set save response " + saveResponse);
		fSaveResponse = saveResponse;
	}

	public boolean isSaveResponse() {
		return fSaveResponse;
	}

	public void setSaveDirectory(File saveDirectory) {
		LOG.debug("set save directory " + saveDirectory);
		fSaveDirectory = saveDirectory;
	}

	public File getSaveDirectory() {
		return fSaveDirectory;
	}

	public void setBaseWindowName(String baseWindowName) {
		LOG.debug("set base window name " + baseWindowName);
		fBaseWindowName = baseWindowName;
	}

	public String getBaseWindowName() {
		return fBaseWindowName;
	}

	public void addCookies(Cookie cookies[]) {
		fCookies.addAll(Arrays.asList(cookies));
	}

	public Cookie[] getCookies() {
		return (Cookie[]) fCookies.toArray(new Cookie[0]);
	}
}
