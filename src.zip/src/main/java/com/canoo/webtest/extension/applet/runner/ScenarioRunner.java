package com.canoo.webtest.extension.applet.runner;

import org.apache.log4j.Logger;
import org.netbeans.jemmy.*;

/**
 * @author Denis N. Antonioli
 * @see org.netbeans.jemmy.Test
 */
public class ScenarioRunner extends ActionProducer implements Timeoutable, Outputable {
	private static final Logger LOG = Logger.getLogger(ScenarioRunner.class);
	/**
	 * Jetty timeout for a scenario.
 	 */
	public static final String WHOLE_TEST_TIMEOUT_NAME = "ScenarioRunner.WholeTestTimeout";
	/**
	 * Internal Jetty timeout for an action producer.
	 */
	static final String ACTION_PRODUCER_MAX_ACTION_TIME_NAME = "ActionProducer.MaxActionTime";

	/**
	 * Test timeouts.
	 */
	private Timeouts fTimeouts;

	/**
	 * Test output.
	 */
	private TestOut fOutput;

	/**
	 * The test scenario to execute.
	 */
	private final Scenario fScenario;

	/**
	 * Exception thrown by jemmy.
	 */
	private JemmyException fJemmyException;

	/**
	 * The jemmy description for this class.
	 */
	static final String DESCRIPTION = "Jemmy scenario runner for Webtest's AppletRunner.";

	static {
		Timeouts.initDefault(WHOLE_TEST_TIMEOUT_NAME, 3600000);
	}

	/**
	 * Creates a subclass of {@link org.netbeans.jemmy.ActionProducer} and {@link java.lang.Thread} that runs in a separate
	 * thread of execution and waits for execution to finish. The current output stream assignments and timeouts are used.
	 *
	 * @param scenario A test scenario
	 * @see org.netbeans.jemmy.Scenario
	 */
	public ScenarioRunner(Scenario scenario) {
		super(true);
		setTimeouts(JemmyProperties.getCurrentTimeouts());
		fScenario = scenario;
		setName("ScenarioRunner for " + fScenario.getClass().getName());
	}

	/**
	 * Set the timeouts used by this <code>ScenarioRunner</code>.
	 *
	 * @param	timeouts A collection of timeout assignments.
	 * @see	org.netbeans.jemmy.Timeoutable
	 * @see	org.netbeans.jemmy.Timeouts
	 * @see #getTimeouts
	 */
	public void setTimeouts(Timeouts timeouts) {
		fTimeouts = timeouts;
		Timeouts times = timeouts.cloneThis();
		times.setTimeout(ACTION_PRODUCER_MAX_ACTION_TIME_NAME, timeouts.getTimeout(WHOLE_TEST_TIMEOUT_NAME));
		super.setTimeouts(times);
	}

	/**
	 * Get the timeouts used by this test.
	 *
	 * @see org.netbeans.jemmy.Timeoutable
	 * @see org.netbeans.jemmy.Timeouts
	 * @see #setTimeouts
	 */
	public Timeouts getTimeouts() {
		return fTimeouts;
	}

	/**
	 * Executes test.
	 */
	public void startTest() throws InterruptedException {
		LOG.info("Test " + fScenario.getClass().getName() + " has been started.");
		try {
			produceAction(null);
		} catch (JemmyException e) {
			fJemmyException = e;
			LOG.info(e.getMessage(), e);
		}
	}

	/**
	 * Launch an action. Pass arguments to and execute a test <code>Scenario</code>.
	 *
	 * @param obj An argument object that controls test execution. This might be a <code>java.lang.String[]</code>
	 *            containing command line arguments.
	 * @return an Integer containing test status.
	 * @see org.netbeans.jemmy.Action
	 */
	public final Object launch(Object obj) {
		setTimeouts(fTimeouts);
		final int result = fScenario.runIt(obj);
		LOG.info(fScenario.getClass().getName() + " ends with " + result);
		return new Integer(result);
	}

	public void printSynopsis() {
		fOutput.printLine(DESCRIPTION);
	}

	public final String getDescription() {
		return "Scenario " + fScenario.getClass().getName();
	}

	public TestOut getOutput() {
		return fOutput;
	}

	public void setOutput(TestOut output) {
		fOutput = output;
		super.setOutput(output);
	}

	public JemmyException getJemmyException() {
		return fJemmyException;
	}
}
