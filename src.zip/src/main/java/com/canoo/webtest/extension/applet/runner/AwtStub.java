package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Label;

/**
 * @author Denis N. Antonioli
 */
public class AwtStub extends AbstractAppletStub {
	private final Label fStatusLabel;

	AwtStub(final Context context,
	        final Applet applet,
	        final AbstractAppletTag appletTag,
	        final String baseWindowName) {
		super(context, applet, appletTag, new Frame(), baseWindowName);
		final Frame frame = getRootFrame();
		frame.setSize(getAppletDimension());
		frame.add(applet, BorderLayout.CENTER);
		fStatusLabel = new Label("");
		fStatusLabel.setName(APPLET_STATUS_NAME);
		frame.add(fStatusLabel, BorderLayout.SOUTH);
	}

	public void showStatus(String status) {
		fStatusLabel.setText(status);
	}

}
