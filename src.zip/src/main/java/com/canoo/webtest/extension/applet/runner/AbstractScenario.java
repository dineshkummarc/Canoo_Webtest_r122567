package com.canoo.webtest.extension.applet.runner;

import org.netbeans.jemmy.Scenario;

import java.awt.Frame;

/**
 * Base class for all test scenarii.
 *
 * @author Denis N. Antonioli
 */
public abstract class AbstractScenario implements Scenario {
	/**
	 * The root frame for the jemmy test scenario.
	 */
	private final Frame fRootFrame;
	/**
	 * The enclosing AppletRunner step. Use it to get parameter values, ...
	 */
	private final AppletRunner fAppletRunner;

	/**
	 * Instantiates a new scenario.
	 *
	 * @param appletRunner The enclosing AppletRunnerStep step.
	 * @param rootFrame    The root frame for the jemmy test scenario.
	 */
	protected AbstractScenario(com.canoo.webtest.extension.applet.runner.AppletRunner appletRunner, Frame rootFrame) {
		fAppletRunner = appletRunner;
		fRootFrame = rootFrame;
	}

	public Frame getRootFrame() {
		return fRootFrame;
	}

	public AppletRunner getAppletRunner() {
		return fAppletRunner;
	}
}
