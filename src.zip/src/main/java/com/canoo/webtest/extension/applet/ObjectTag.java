package com.canoo.webtest.extension.applet;

import com.gargoylesoftware.htmlunit.html.HtmlElement;
import org.apache.log4j.Logger;

import java.net.MalformedURLException;

/**
 * @author Denis N. Antonioli
 */
public class ObjectTag extends AbstractAppletTag {
	private static final Logger LOG = Logger.getLogger(ObjectTag.class);
	private static final String ATTR_CACHE_ARCHIVE = "cache_archive";

	public ObjectTag(String base) throws MalformedURLException {
		super(base);
	}

	protected void addsAllAttributes(HtmlElement appletNode) throws NoSuchFieldException, MalformedURLException {
		String attr;

		// TODO: check value of attribute classid

		attr =  appletNode.getAttribute("width");
		if (attr == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			throw new NoSuchFieldException("Object element does not define the width.");
		}
		addParameterLength(AbstractAppletTag.ATTR_WIDTH, attr);

		attr = appletNode.getAttribute("height");
		if (attr == HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			throw new NoSuchFieldException("Object element does not define the height.");
		}
		addParameterLength(AbstractAppletTag.ATTR_HEIGHT, attr);

		attr = appletNode.getAttribute("name");
		if (attr != HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			addParameter(AbstractAppletTag.ATTR_NAME, attr);
		}

		if (appletNode.getAttribute("codebase") != HtmlElement.ATTRIBUTE_NOT_DEFINED) {
			LOG.info("Attribute 'codebase' is not supported'.");
		}
	}

	protected void addsAllParameters(HtmlElement appletNode) throws NoSuchFieldException, MalformedURLException {
        super.addsAllParameters(appletNode);
        String type = getParameter("type");
		if (type == null) {
			throw new NoSuchFieldException("Object element does not define the required parameter 'type'.");
		}
		if (!type.startsWith("application/x-java-applet;")) {
			throw new IllegalArgumentException("The parameter 'type' must start with 'application/x-java-applet;'.");
		}
		if (getParameter(AbstractAppletTag.ATTR_OBJECT) != null) {
			throw new NoSuchFieldException("Attribute object is not supported.");
		}
		if (getParameter(AbstractAppletTag.ATTR_CODE) == null) {
			throw new NoSuchFieldException("Object element does not define the required parameter 'code'.");
		}
	}

	public void addParameter(String name, String value) throws MalformedURLException {
		if (ObjectTag.ATTR_CACHE_ARCHIVE.equalsIgnoreCase(name)) {
			// TODO: does cache_archive overwrite/extend archive?
			setArchive(value);
		} else {
			super.addParameter(name, value);
		}
	}
}
