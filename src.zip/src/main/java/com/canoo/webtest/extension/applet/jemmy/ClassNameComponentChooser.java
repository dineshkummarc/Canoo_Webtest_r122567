package com.canoo.webtest.extension.applet.jemmy;

import org.netbeans.jemmy.ComponentChooser;

import java.awt.Component;

/**
 * Specifies criteria for component lookup basing on the type of the component.
 * This chooser takes a String instead of a Class to reduce the coupling between the applet and the scenario.
 *
 * @author Denis N. Antonioli
 */
public class ClassNameComponentChooser implements ComponentChooser {
	private final String fDescription;
	private final String fClassName;

	/**
	 * Creates an instance to search for a component by the name of its class.
	 *
	 * @param description     A description for the chooser.
	 * @param className       Expected component class name.
	 */
	public ClassNameComponentChooser(final String description, final String className) {
		fDescription = description;
		fClassName = className;
	}

	public boolean checkComponent(Component comp) {
		return comp.getClass().getName().equals(fClassName);
	}

	public String getDescription() {
		return "component '" + fDescription + "'";
	}
}

