package com.canoo.webtest.extension.applet.jemmy;

import com.canoo.webtest.boundary.JemmyBoundary;
import com.canoo.webtest.extension.applet.runner.Context;
import org.netbeans.jemmy.JemmyProperties;
import org.netbeans.jemmy.Outputable;
import org.netbeans.jemmy.TestOut;
import org.netbeans.jemmy.Timeoutable;
import org.netbeans.jemmy.Timeouts;
import org.netbeans.jemmy.Waitable;
import org.netbeans.jemmy.Waiter;

import java.net.URL;

/**
 * @author Denis N. Antonioli
 */

public class ContextOperator implements Outputable, Timeoutable {
    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     */
    private TestOut fOutput;
    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     */
    private Timeouts fTimeouts;
    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     */
    private JemmyProperties fProperties;

    public static final String WAIT_TIMEOUT_NAME = "ContextOperator.WaitStateTimeout";

    private final Context fContext;

    static {
        Timeouts.initDefault(WAIT_TIMEOUT_NAME, 3600000);
    }

    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     */
    {
        setTimeouts(JemmyProperties.getProperties().getTimeouts());
        setOutput(JemmyProperties.getProperties().getOutput());
        setProperties(JemmyProperties.getProperties());
    }

    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public void setOutput(TestOut output) {
        fOutput = output;
    }


    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public TestOut getOutput() {
        return fOutput;
    }

    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public void setTimeouts(Timeouts timeouts) {
        fTimeouts = timeouts;
    }

    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public Timeouts getTimeouts() {
        return fTimeouts;
    }

    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public JemmyProperties getProperties() {
        return fProperties;
    }

    /**
     * Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public JemmyProperties setProperties(JemmyProperties properties) {
        JemmyProperties oldProperties = getProperties();
        fProperties = properties;
        return oldProperties;
    }

    /**
     * Waits a state specified by a Waitable instance. Should be in org.netbeans.jemmy.operators.AbstractOperator
     *
     * @see org.netbeans.jemmy.operators.Operator
     */
    public void waitState(final Waitable state) {
        Waiter stateWaiter = new Waiter(state);
        stateWaiter.setTimeouts(getTimeouts().cloneThis());
        stateWaiter.getTimeouts().setTimeout("Waiter.WaitingTime", getTimeouts().getTimeout(WAIT_TIMEOUT_NAME));
        stateWaiter.setOutput(getOutput().createErrorOutput());
        JemmyBoundary.tryWaitAction(stateWaiter, state, fContext);
    }

    public ContextOperator(Context context) {
        fContext = context;
    }

    public void waitShowDocument() {
        waitShowDocument(Context.DEFAULT_TARGET);
    }

    public void waitShowDocument(String target) {
        getOutput().printLine("Wait any url in frame " + target);
        getOutput().printGolden("Wait any url in frame " + target);
        waitState(new WaitFrame(target));
    }

    public void waitShowDocument(URL url) {
        waitShowDocument(url, Context.DEFAULT_TARGET);
    }

    public void waitShowDocument(URL url, String target) {
        getOutput().printLine("Wait \"" + url + "\" in frame " + target);
        getOutput().printGolden("Wait \"" + url + "\" in frame " + target);
        waitState(new WaitUrlInFrame(url, target));
    }

    public Context getContext() {
        return fContext;
    }

    /**
     * Checks that the applet asked for any document to be displayed.
     */
    static class WaitFrame implements Waitable {
        private final String fTarget;

        WaitFrame(String target) {
            fTarget = target;
        }

        public Object actionProduced(final Object obj) {
            return ((Context) obj).getAppletPluginResults().getFrames().get(getTarget());
        }

        public String getDescription() {
            return "Wait for showDocument(" + getTarget() + ", ...)";
        }

        public String getTarget() {
            return fTarget;
        }
    }

    /**
     * Checks that the applet asked for a specific document to be displayed.
     */
    static class WaitUrlInFrame extends WaitFrame {
        private final URL fUrl;

        WaitUrlInFrame(URL url, String target) {
            super(target);
            fUrl = url;
        }

        public Object actionProduced(Object obj) {
            URL url = (URL) super.actionProduced(obj);
            if (fUrl.equals(url)) {
                return url;
            }
            return null;
        }

        public String getDescription() {
            return "Wait for showDocument(" + getTarget() + ", " + fUrl.toExternalForm() + ")";
        }
    }
}