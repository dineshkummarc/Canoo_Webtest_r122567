package com.canoo.webtest.extension.applet;

import com.canoo.webtest.steps.Step;

/**
 * @author Denis N. Antonioli
 * @webtest.nested
 * category="Extension"
 * name="parameterRef"
 * description="Pass a set of properties to a scenario."
 */
public class ParameterRef {
	private String fName;
	private String fRegex;
	private String fPropertyType;

	public ParameterRef() {
		fPropertyType = Step.PROPERTY_TYPE_DEFAULT;
	}

	public ParameterRef(final String name, final String regex, final String propertyType) {
		fName = name;
		fRegex = regex;
		fPropertyType = propertyType;
	}

	public String getName() {
		return fName;
	}

	/**
	 * @webtest.parameter
	 * required="yes"
	 * description="The name of the parameter in the scenario."
	 */
	public void setName(String name) {
		fName = name;
	}

	public String getRegex() {
		return fRegex;
	}

	/**
	 * @webtest.parameter
	 * required="yes"
	 * description="A pattern to select properties to pass to the scenario."
	 */
	public void setRegex(String regex) {
		fRegex = regex;
	}

	public String getPropertyType() {
		return fPropertyType;
	}

	/**
	 * @webtest.parameter
	 *   required="no"
	 *   description="The kind of properties to include. Either \"ant\" or \"dynamic\"."
	 *   default="The \"defaultPropertyType\" as specified in the \"config\" element is used."
	 */
	public void setPropertyType(String propertyType) {
		fPropertyType = propertyType;
	}
}
