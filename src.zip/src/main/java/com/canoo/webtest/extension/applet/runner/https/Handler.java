// Copyright (c) 2002-2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.runner.https;

import com.canoo.webtest.engine.Configuration;
import com.canoo.webtest.extension.applet.runner.http.HttpURLConnection;
import com.canoo.webtest.interfaces.IConnectionInitializer;
import com.canoo.webtest.interfaces.IPropertyHandler;
import com.canoo.webtest.security.ConnectionInitializationException;
import com.canoo.webtest.steps.request.TargetHelper;
import org.apache.commons.httpclient.HttpsURL;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

/**
 * @author Denis N. Antonioli
 */
public class Handler extends URLStreamHandler
{
    private static final Logger LOG = Logger.getLogger(Handler.class);
    private static boolean sAlreadyInitialized;
    private static Configuration sConfig;

    public static final IPropertyHandler SYSTEM_PROPERTY_HANDLER = new IPropertyHandler()
    {
        public String getProperty(String propertyName) {
            return System.getProperty(propertyName);
        }
    };

    static {
        sConfig = new Configuration();
        sConfig.setPropertyHandler(SYSTEM_PROPERTY_HANDLER);
        sConfig.setProtocol("https");
    }

    public static boolean isAlreadyInitialized() {
        return sAlreadyInitialized;
    }

    static void initializeCustomConnectionInitializer() {
        if (sAlreadyInitialized) {
            return;
        }
        sAlreadyInitialized = true;

        String customInitializerClassName = sConfig.getExternalProperty(TargetHelper.CONNECTION_INITIALIZER_KEY);
        if (customInitializerClassName == null) {
            return;
        }

        allocateAndInit(customInitializerClassName);
    }

    static void allocateAndInit(final String customInitializerClassName) {
        IConnectionInitializer customInitializer;
        try {
            customInitializer = (IConnectionInitializer) Class.forName(customInitializerClassName).newInstance();
        } catch (Exception e) {
            LOG.info("exception instantiating Connection Initializer " + e.getMessage(), e);
            throw (RuntimeException) e;
        }
        try {
            customInitializer.initializeConnection(sConfig);
            LOG.info("custom connection initializer set-up.");
        } catch (ConnectionInitializationException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    protected int getDefaultPort() {
        return HttpsURL.DEFAULT_PORT;
    }

    protected URLConnection openConnection(URL url) throws IOException {
        initializeCustomConnectionInitializer();
        return new HttpURLConnection(url);
    }
}