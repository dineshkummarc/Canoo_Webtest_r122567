package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;
import com.canoo.webtest.extension.applet.AppletPluginArguments;
import com.canoo.webtest.extension.applet.AppletPluginResults;
import org.apache.log4j.Logger;

import javax.swing.JApplet;
import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AudioClip;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * The context in which an applet is running.
 * <p><b>Note:</b> According to the javadoc, the stream-access methods should be limited by the
 * codebase of the applet. This has not been implemented yet.
 * <p><b>Note:</b> The two methods {@link #getAudioClip(java.net.URL)} and {@link #getImage(java.net.URL)}
 * should maintain a cache of previously seen medias. It isn't required, but the implementations do it.
 *
 * @author Denis N. Antonioli
 */
public class Context implements AppletContext {
	private static final Logger LOG = Logger.getLogger(Context.class);
	public static final String DEFAULT_TARGET = "_top";

	private final AppletPluginResults fAppletPluginResults;

	private final List fApplets = new Vector();
	private final Map fStreams = new HashMap();

    private Enumeration getAppletElements() {
        return ((Vector)fApplets).elements();
    }

	public Context(AppletPluginResults appletPluginResults) {
		fAppletPluginResults = appletPluginResults;
	}

	public AudioClip getAudioClip(URL url) {
		return Applet.newAudioClip(url);
	}

	public Image getImage(URL url) {
		return Toolkit.getDefaultToolkit().createImage(url);
	}

	public Applet getApplet(String name) {
		if (name == null) {
			return null;
		}
		for (Enumeration en = getAppletElements(); en.hasMoreElements();) {
			AbstractAppletStub abstractAppletStub = (AbstractAppletStub) en.nextElement();
			if (name.equals(abstractAppletStub.getParameter("name"))) {
				return abstractAppletStub.getApplet();
			}
		}
		return null;
	}

	public Enumeration getApplets() {
		return getAppletElements();
	}

	public void showDocument(URL url) {
		showDocument(url, DEFAULT_TARGET);
	}

	public void showDocument(URL url, String target) {
		LOG.info("Storing attempt to show document " + url.toExternalForm() + " in target " + target);
		fAppletPluginResults.setFrame(target, url);
	}

	public void showStatus(String status) {
		for (Enumeration en = getAppletElements(); en.hasMoreElements();) {
			((AbstractAppletStub) en.nextElement()).showStatus(status);
		}
	}

	public void setStream(String key, InputStream inputStream) throws IOException {
		if (inputStream == null) {
			fStreams.remove(key);
		} else {
			fStreams.put(key, inputStream);
		}
	}

	public InputStream getStream(String key) {
		return (InputStream) fStreams.get(key);
	}

	public Iterator getStreamKeys() {
		return fStreams.keySet().iterator();
	}

	AbstractAppletStub newStub(final Applet applet, final AbstractAppletTag appletTag, final AppletPluginArguments appletPluginArguments) {
		AbstractAppletStub stub;
		if (applet instanceof JApplet) {
			stub = new SwingStub(this, (JApplet) applet, appletTag, appletPluginArguments.getBaseWindowName());
		} else {
			stub = new AwtStub(this, applet, appletTag, appletPluginArguments.getBaseWindowName());
		}
		fApplets.add(stub);
		return stub;
	}

	public AppletPluginResults getAppletPluginResults() {
		return fAppletPluginResults;
	}
}
