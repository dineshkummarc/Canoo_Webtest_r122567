// Copyright (c) 2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.runner.http;

import org.apache.commons.httpclient.HttpURL;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

/**
 * @author Denis N. Antonioli
 */
public class Handler extends URLStreamHandler {

	protected int getDefaultPort() {
		return HttpURL.DEFAULT_PORT;
	}

	protected URLConnection openConnection(URL url) throws IOException {
		return new HttpURLConnection(url);
	}
}
