// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.engine;

public interface CallBlock
{
	void call() throws Throwable;
}
