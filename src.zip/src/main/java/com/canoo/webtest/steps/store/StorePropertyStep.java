// Copyright � 2002-2007 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.steps.store;

import org.apache.commons.lang.StringUtils;

import com.canoo.webtest.engine.StepFailedException;
import com.canoo.webtest.util.ConversionUtil;
import com.canoo.webtest.util.Evaluator;
import com.canoo.webtest.util.Expression;

/**
 * Step which stores a value into a property.<p>
 *
 * @author Paul King
 * @webtest.step
 *   category="Core"
 *   name="storeProperty"
 *   alias="storeDynamicProperty"
 *   description="Provides the ability to store a given value into a property. It supports both dynamic properties and traditional ant properties."
 */
public class StorePropertyStep extends BaseStoreStep implements Evaluator {
    private String fPropertyValue;
    private String fEval;
    private String fName;


    public void doExecute() {
    	final String value = isEval() ? doEvaluate(getValue()) : getValue();
        storeProperty(value, getName());
    }

    String doEvaluate(final String propertyValue) {
        final double d = Expression.evaluateExpression(propertyValue, this);
        if (d == (int)d) {
            return Integer.toString((int)d);
        }
        return Double.toString(d);
    }

    public String getName() {
        return fName;
    }

    /**
     * Sets the property name
     *
     * @param name
     * @webtest.parameter
     *   required="yes/no"
     *   description="The property name. Must be set if <em>property</em> is not set."
     */
    public void setName(final String name) {
    	fName = name;
    }

    public String getValue() {
        return fPropertyValue;
    }

    /**
     * Sets the property value
     *
     * @param value
     * @webtest.parameter
     *   required="yes"
     *   description="The property value."
     */
    public void setValue(final String value) {
        fPropertyValue = value;
    }


    public boolean isEval() {
        return ConversionUtil.convertToBoolean(getEval(), false);
    }

    public String getEval() {
        return fEval;
    }

    /**
     * Sets the eval flag
     *
     * @param eval
     * @webtest.parameter
     *   required="no"
     *   default="false"
     *   description="A flag which determines if the value is to be treated as a mathematical expression to be evaluated."
     */
    public void setEval(final String eval) {
        fEval = eval;
    }

    protected void verifyParameters() {
        super.verifyParameters();
        nullParamCheck(StringUtils.defaultString(getProperty(), fName), "name");
        nullParamCheck(getValue(), "value");
    }

    public double evaluate(final String s) {
        final String result = getProject().replaceProperties(s);
        try {
            return Double.parseDouble(result);
        }
        catch (final NumberFormatException e) {
            throw new StepFailedException("Attempted to evaluate non-numeric property '"
                    + s + "': " + e.getMessage(), this);
        }
    }

    /**
     * The property value if inlined.
     *
     * @param text The new value
     * @webtest.nested.parameter
     *    required="no"
     *    description="An alternative to the attribute value."
     */
    public void addText(final String text) {
        fPropertyValue = text;
    }
}
