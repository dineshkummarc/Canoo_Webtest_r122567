// Copyright � 2004-2005 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.steps.verify;

import com.canoo.webtest.engine.StepFailedException;
import com.canoo.webtest.steps.store.StoreCookie;
import org.apache.commons.httpclient.Cookie;
import org.apache.log4j.Logger;

/**
 * Verifies a cookie value.<p>
 *
 * @author Paul King, ASERT
 * @author Denis N. Antonioli
 * @webtest.step category="Core"
 * name="verifyCookie"
 * description="Provides the ability to check an <key>HTTP</key> Cookie value."
 */
public class VerifyCookie extends AbstractVerifyTextStep {
    private static final Logger LOG = Logger.getLogger(VerifyCookie.class);
    private String fName;

    {
        setOptionalText(true);
    }

    /**
     * Sets the Name of the cookie of interest
     *
     * @param name The new Name name
     * @webtest.parameter required="yes"
     * description="The name of the cookie of interest."
     */
    public void setName(String name) {
        fName = name;
    }

    public String getName() {
        return fName;
    }

    /**
     * @param text The new text
     * @webtest.parameter required="no"
     * description="The text of the cookie of interest. If omitted just checks for existence of the cookie."
     */
    public void setText(String text) {
        super.setText(text);
    }

    public void doExecute() {
        final Cookie[] cookies = StoreCookie.getCookies(getContext());
        LOG.debug("Found " + cookies.length + " cookie(s)");
        if (cookies.length == 0) {
            throw new StepFailedException("No cookie available!", this);
        }
        for (int i = 0; i < cookies.length; i++) {
            Cookie cookie = cookies[i];
            if (cookie.getName().equals(getName())) {
                // just check for existence of cookie if no text given
                if (getText() == null) {
                    return;
                }
                if (verifyText(cookie.getValue())) {
                    return;
                }
                throw new StepFailedException("Wrong cookie \"" + getName() + "\" value found!",
                		getText(), cookie.getValue(), this);
            }
        }
        throw new StepFailedException("Cookie \"" + getName() + "\" not set!", this);
    }

    /**
     * Verifies the parameters
     */
    protected void verifyParameters() {
        super.verifyParameters();
        nullParamCheck(getName(), "name");
        nullResponseCheck();
	}
}