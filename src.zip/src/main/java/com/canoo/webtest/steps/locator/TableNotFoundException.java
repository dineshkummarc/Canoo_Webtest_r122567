// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.steps.locator;

/** @author Dierk K�nig */
public class TableNotFoundException extends Exception
{
    public TableNotFoundException(String s) {
        super(s);
    }
}
