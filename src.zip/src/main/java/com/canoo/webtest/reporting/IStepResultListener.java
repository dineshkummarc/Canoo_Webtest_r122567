package com.canoo.webtest.reporting;

import java.util.Map;

/**
 * Defines
 * @author Marc Guillemot
 */
public interface IStepResultListener {
	void stepResults(final Map map);
}
