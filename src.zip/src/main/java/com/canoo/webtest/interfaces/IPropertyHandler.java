// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.interfaces;

/**
 * @author Carsten Seibert
 */
public interface IPropertyHandler
{
    String getProperty(String propertyName);
}
