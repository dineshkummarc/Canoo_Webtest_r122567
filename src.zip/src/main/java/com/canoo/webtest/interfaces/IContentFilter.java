// Copyright � 2004-2005 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.interfaces;

/**
 * Interface indicating that this step will filter context when executed.
 *
 * @author Paul King
 */
public interface IContentFilter
{
}
