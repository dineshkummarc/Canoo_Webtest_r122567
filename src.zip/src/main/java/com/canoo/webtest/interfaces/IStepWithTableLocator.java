// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.interfaces;

/**
 * @author Paul King
 */

public interface IStepWithTableLocator
{
    ITableLocator getTableLocator();
}
