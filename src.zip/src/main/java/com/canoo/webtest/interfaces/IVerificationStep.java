package com.canoo.webtest.interfaces;

/**
 * Markers to indicate that a class is a verification step.
 * It would be probably better to use an annotation, but current doc extraction doesn't work with Java5 syntax
 * and therefore it should be avoided. 
 * @author Marc Guillemot
 */
public interface IVerificationStep {
	// nothing
}
