package com.canoo.webtest.extension.applet.awt;

import com.canoo.webtest.extension.applet.runner.AbstractScenario;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.LabelOperator;

import java.awt.Component;
import java.awt.Frame;

/**
 * A simple failing scenario. Scenario may signal error with a return value different from 0.
 *
 * @author Denis N. Antonioli
 * @see com.canoo.webtest.extension.applet.swing.FailScenario
 */
public class FailScenario extends AbstractScenario {

	public FailScenario(com.canoo.webtest.extension.applet.runner.AppletRunner appletRunner, Frame applet) {
		super(appletRunner, applet);
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());
		Component comp = appOper.findSubComponent(new LabelOperator.LabelByLabelFinder("XXXX " + Applet.WELCOME));
		if (comp == null) {
			return 1;
		}
		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (failure expected)";
	}
}