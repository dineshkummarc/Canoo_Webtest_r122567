// Copyright (c) 2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.jemmy;

import com.canoo.webtest.extension.applet.runner.AbstractScenario;
import com.canoo.webtest.extension.applet.runner.AppletRunner;
import org.netbeans.jemmy.operators.ButtonOperator;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.LabelOperator;
import org.netbeans.jemmy.util.NameComponentChooser;

import java.awt.Frame;
import java.awt.Label;

/**
 * @author Denis N. Antonioli
 */
public class SuccessScenario extends AbstractScenario {
	private final String fTarget;

	public SuccessScenario(AppletRunner appletRunner, Frame applet) {
		this(appletRunner, applet, null);
	}

	public SuccessScenario(AppletRunner appletRunner, Frame applet, String target) {
		super(appletRunner, applet);
		fTarget = target;
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());

		Label compWelcomeLbl = (Label) appOper.findSubComponent(new LabelOperator.LabelByLabelFinder(Applet.WELCOME));
		if (compWelcomeLbl == null) {
			return 1;
		}

		ButtonOperator btnOper = new ButtonOperator(appOper, new NameComponentChooser(Applet.NAME_BTN));
		if (btnOper == null) {
			return 2;
		}
		btnOper.push();

		final ContextOperator contextOperator = new ContextOperator(getAppletRunner().getAppletContext());
		if (fTarget == null) {
			contextOperator.waitShowDocument();
		} else {
			contextOperator.waitShowDocument(fTarget);
		}
		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (success expected)";
	}

}
