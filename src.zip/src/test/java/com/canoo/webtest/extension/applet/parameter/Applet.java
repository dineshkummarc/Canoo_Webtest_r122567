package com.canoo.webtest.extension.applet.parameter;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class Applet extends java.applet.Applet {
	private final TextArea fParameters;

	static final String NAME_TA_PARAMETERS = "parameters";
	static final String NAME_BTN = "Get";

	static final String WELCOME = "Welcome to the test Parameter Applet.";

	public Applet() {
		setLayout(new FlowLayout());

		Label captionLabel = new Label(WELCOME, Label.CENTER);
		add(captionLabel);

		Button btn = new Button(NAME_BTN);
		btn.setName(NAME_BTN);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					getAppletContext().showDocument(new URL(getDocumentBase(), "formTest?"+fParameters.getText()));
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
					e1.printStackTrace(System.out);
					showStatus(e1.getMessage());
				}
			}
		});
		add(btn);

		fParameters = new TextArea(10, 80);
		fParameters.setEditable(true);
		fParameters.setName(NAME_TA_PARAMETERS);
		add(fParameters);
	}

}
