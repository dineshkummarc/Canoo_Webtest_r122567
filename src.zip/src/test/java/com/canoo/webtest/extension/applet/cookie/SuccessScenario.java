package com.canoo.webtest.extension.applet.cookie;

import com.canoo.webtest.extension.applet.runner.AppletRunner;
import org.apache.log4j.Logger;
import org.netbeans.jemmy.operators.ButtonOperator;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.LabelOperator;
import org.netbeans.jemmy.util.NameComponentChooser;

import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;

/**
 * @author Denis N. Antonioli
 */
public class SuccessScenario extends com.canoo.webtest.extension.applet.runner.AbstractScenario {
	private static final Logger LOG = Logger.getLogger(SuccessScenario.class);

	public SuccessScenario(AppletRunner appletRunner, Frame applet) {
		super(appletRunner, applet);
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());

		Label welcomeLbl = (Label) appOper.findSubComponent(new LabelOperator.LabelByLabelFinder(Applet.WELCOME));
		if (welcomeLbl == null) {
			return 1;
		}

		TextArea outputTextArea = (TextArea) appOper.findSubComponent(new NameComponentChooser(Applet.NAME_TA_HEADERS));
		if (outputTextArea == null) {
			return 2;
		}

		Label getBtnLbl = (Label) appOper.findSubComponent(new NameComponentChooser(Applet.NAME_LBL_GET_BTN_OUTPUT));
		if (getBtnLbl == null || !Applet.GET_BTN_LBL_BEFORE.equals(getBtnLbl.getText())) {
			return 3;
		}
		Label postBtnLbl = (Label) appOper.findSubComponent(new NameComponentChooser(Applet.NAME_LBL_POST_BTN_OUTPUT));
		if (postBtnLbl == null || !Applet.POST_BTN_LBL_BEFORE.equals(postBtnLbl.getText())) {
			return 4;
		}

		ButtonOperator getBtnOper = new ButtonOperator(appOper, new NameComponentChooser(Applet.NAME_GET_BTN));
		if (getBtnOper == null) {
			return 5;
		}
		getBtnOper.push();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			return 6;
		}

		if (!Applet.GET_BTN_LBL_AFTER.equals(getBtnLbl.getText())) {
			return 7;
		}

		if (outputTextArea.getText().indexOf("Cookie: " + getAppletRunner().getAppletPluginArguments().getArgument("text")) == -1) {
			LOG.info("Missing\nCookie: " + getAppletRunner().getAppletPluginArguments().getArgument("text") + "\n" + outputTextArea.getText());
			return 8;
		}

		ButtonOperator postBtnOper = new ButtonOperator(appOper, new NameComponentChooser(Applet.NAME_POST_BTN));
		if (postBtnOper == null) {
			return 9;
		}
		postBtnOper.push();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			return 10;
		}

		if (!Applet.POST_BTN_LBL_AFTER.equals(postBtnLbl.getText())) {
			return 11;
		}

		if (outputTextArea.getText().indexOf("Cookie: " + getAppletRunner().getAppletPluginArguments().getArgument("text")) == -1) {
			LOG.info("Missing\nCookie: " + getAppletRunner().getAppletPluginArguments().getArgument("text") + "\n" + outputTextArea.getText());
			return 12;
		}
		if (outputTextArea.getText().indexOf(Applet.KEY_CONTENT_TYPE) == -1) {
			LOG.info("Missing\nContent-Type key: " + Applet.KEY_CONTENT_TYPE + "\n" + outputTextArea.getText());
			return 13;
		}
		if (outputTextArea.getText().indexOf(Applet.VALUE_CONTENT_TYPE) == -1) {
			LOG.info("Missing\nContent-Type value: " + Applet.VALUE_CONTENT_TYPE + "\n" + outputTextArea.getText());
			return 14;
		}
		if (outputTextArea.getText().indexOf(Applet.MSG_SENT_TO_SERVER) == -1) {
			LOG.info("Missing\nBody: " + getAppletRunner().getAppletPluginArguments().getArgument("text") + "\n" + Applet.MSG_SENT_TO_SERVER);
			return 15;
		}

		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (success expected)";
	}
}