// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.extension.applet;

import com.gargoylesoftware.htmlunit.html.HtmlElement;
import junit.framework.TestCase;
import org.apache.commons.httpclient.Cookie;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class AppletPluginArgumentsTest extends TestCase {

	private AppletPluginArguments fAppletPluginArguments;

	protected void setUp() throws Exception {
		fAppletPluginArguments = new AppletPluginArguments();
	}

	public void testGetArgument() throws Exception {
		assertFalse(fAppletPluginArguments.hasArguments());
		Parameter param = new Parameter();
		param.setName("nom");
		param.setValue("valeur");
		fAppletPluginArguments.addArgument(param);
		assertTrue(fAppletPluginArguments.hasArguments());
		assertEquals("valeur", fAppletPluginArguments.getArgument("nom"));
	}

	public void testGetScenarioLocation() throws MalformedURLException {
		assertEquals(0, fAppletPluginArguments.getScenarioLocation().length);

		fAppletPluginArguments.setScenarioLocation(null);
		assertEquals(0, fAppletPluginArguments.getScenarioLocation().length);

		fAppletPluginArguments.setScenarioLocation(new URL[0]);
		assertEquals(0, fAppletPluginArguments.getScenarioLocation().length);

		URL loc = new File("/usr/webtest/lib").toURI().toURL();
		fAppletPluginArguments.setScenarioLocation(new URL[]{loc});
		assertEquals(1, fAppletPluginArguments.getScenarioLocation().length);
		assertEquals(loc, fAppletPluginArguments.getScenarioLocation()[0]);
	}

	public void testGetScenario() throws Exception {
		assertNull(fAppletPluginArguments.getScenario());
		String loc = "aScenario";
		fAppletPluginArguments.setScenario(loc);
		assertEquals(loc, fAppletPluginArguments.getScenario());
	}

	public void testGetAppletTag() throws Exception {
		assertNull(fAppletPluginArguments.getAppletTag());
		AbstractAppletTag loc = new AbstractAppletTag("http://localhost:9090/selftest/") {
			protected void addsAllAttributes(HtmlElement appletNode) {
			}

			protected void addsAllParameters(HtmlElement appletNode) {
			}
		};
		loc.addsAllAttributes(null); // to satisfy clover...
		loc.addsAllParameters(null); // to satisfy clover...
		fAppletPluginArguments.setAppletTag(loc);
		assertEquals(loc, fAppletPluginArguments.getAppletTag());
	}

	public void testGetBaseWindowName() throws Exception {
		assertNull(fAppletPluginArguments.getBaseWindowName());
		String loc = "aScenario";
		fAppletPluginArguments.setBaseWindowName(loc);
		assertEquals(loc, fAppletPluginArguments.getBaseWindowName());
	}

	public void testSaveResponse() {
		assertFalse(fAppletPluginArguments.isSaveResponse());
		fAppletPluginArguments.setSaveResponse(true);
		assertTrue(fAppletPluginArguments.isSaveResponse());
	}

	public void testSaveDirectory() {
		assertNull(fAppletPluginArguments.getSaveDirectory());
		File aDir = new File(".");
		fAppletPluginArguments.setSaveDirectory(aDir);
		assertEquals(aDir, fAppletPluginArguments.getSaveDirectory());
	}

	public void testAddGetCookies() throws MalformedURLException {
		final String host = "webtest.canoo.com";
		assertEquals(0, fAppletPluginArguments.getCookies().length);

		fAppletPluginArguments.addCookies(new Cookie[]{new Cookie(host, "biscuit", "Lu")});
		Cookie[] cookies = fAppletPluginArguments.getCookies();
		assertEquals(1, cookies.length);
		assertEquals("biscuit", cookies[0].getName());
		assertEquals("Lu", cookies[0].getValue());

		fAppletPluginArguments.addCookies(new Cookie[]{new Cookie(host, "guezli", "Hug")});
		cookies = fAppletPluginArguments.getCookies();
		assertEquals(2, cookies.length);
		assertEquals("biscuit", cookies[0].getName());
		assertEquals("Lu", cookies[0].getValue());
		assertEquals("guezli", cookies[1].getName());
		assertEquals("Hug", cookies[1].getValue());

	}

}
