package com.canoo.webtest.extension.applet.cookie;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

/**
 * @author Denis N. Antonioli
 */
public class Applet extends java.applet.Applet {
	private final Label fGetBtnOutputLbl, fPostBtnOutputLbl;
	private final TextArea fHeaders;

	static final String NAME_TA_HEADERS = "headers";
	static final String NAME_LBL_GET_BTN_OUTPUT = "get.output";
	static final String NAME_LBL_POST_BTN_OUTPUT = "post.output";
	static final String NAME_GET_BTN = "Get";
	static final String NAME_POST_BTN = "Post";

	private static final String BTN_LBL_BEFORE = " button has not been pushed yet";
	private static final String BTN_LBL_AFTER = " button has been pushed";
	static final String GET_BTN_LBL_BEFORE = NAME_GET_BTN + BTN_LBL_BEFORE;
	static final String GET_BTN_LBL_AFTER = NAME_GET_BTN + BTN_LBL_AFTER;
	static final String POST_BTN_LBL_BEFORE = NAME_POST_BTN + BTN_LBL_BEFORE;
	static final String POST_BTN_LBL_AFTER = NAME_POST_BTN + BTN_LBL_AFTER;
	static final String WELCOME = "Welcome to the test Cookie Applet.";
	public static final String MSG_SENT_TO_SERVER = "<message>Greetings from Applet</message>";
	public static final String KEY_CONTENT_TYPE = "Content-Type";
	public static final String VALUE_CONTENT_TYPE = "text/xml";

	public Applet() {
		setLayout(new FlowLayout());

		final Label captionLabel = new Label(WELCOME, Label.CENTER);
		add(captionLabel);

		fGetBtnOutputLbl = new Label(GET_BTN_LBL_BEFORE);
		fGetBtnOutputLbl.setName(NAME_LBL_GET_BTN_OUTPUT);
		Button btn = new Button(NAME_GET_BTN);
		btn.setName(NAME_GET_BTN);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				fGetBtnOutputLbl.setText(GET_BTN_LBL_AFTER);
				try {
					final URL showHeadersURL = new URL(getDocumentBase(), "showHeaders");
					final URLConnection urlConnection = showHeadersURL.openConnection();

                    final InputStream is = urlConnection.getInputStream();
					final StringBuffer sb = new StringBuffer();
					for (int ch; (ch = is.read()) > -1;) {
						sb.append((char) ch);
					}
					is.close();

					fHeaders.setText(sb.toString());
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
					e1.printStackTrace(System.out);
					showStatus(e1.getMessage());
				}
			}
		});
		add(fGetBtnOutputLbl);
		add(btn);

		fPostBtnOutputLbl = new Label(POST_BTN_LBL_BEFORE);
		fPostBtnOutputLbl.setName(NAME_LBL_POST_BTN_OUTPUT);
		btn = new Button(NAME_POST_BTN);
		btn.setName(NAME_POST_BTN);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				fPostBtnOutputLbl.setText(POST_BTN_LBL_AFTER);
				try {
					final URL showHeadersURL = new URL(getDocumentBase(), "showHeaders");
					final URLConnection urlConnection = showHeadersURL.openConnection();
					urlConnection.setDoOutput(true);
					urlConnection.setDoInput(true);

					urlConnection.setRequestProperty(KEY_CONTENT_TYPE, VALUE_CONTENT_TYPE);
					final OutputStream os = urlConnection.getOutputStream();
					os.write(MSG_SENT_TO_SERVER.getBytes());
					os.flush();

					final InputStream is = urlConnection.getInputStream();
					final StringBuffer sb = new StringBuffer();
					for (int ch; (ch = is.read()) > -1;) {
						sb.append((char) ch);
					}

					is.close();

					fHeaders.setText(sb.toString());
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
					e1.printStackTrace(System.out);
					showStatus(e1.getMessage());
				}
			}
		});
		add(fPostBtnOutputLbl);
		add(btn);


		fHeaders = new TextArea(10, 80);
		fHeaders.setEditable(false);
		fHeaders.setName(NAME_TA_HEADERS);
		add(fHeaders);
	}
}
