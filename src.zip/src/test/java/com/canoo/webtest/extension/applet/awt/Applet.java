package com.canoo.webtest.extension.applet.awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Denis N. Antonioli
 */
public class Applet extends java.applet.Applet {
	static final String NAME_LBL_BTN_OUTPUT = "field.output";
	static final String NAME_BTN = "clickMe";
	static final String NAME_TXT_FIELD = "field.input";
	static final String NAME_LBL_IMG_SIZE = "image.size";

	static final String BTN_LBL_BEFORE = "button has not been pushed yet";
	static final String BTN_LBL_AFTER = "button has been pushed";
	static final String WELCOME = "Welcome to the test AWT Applet.";
	static final String INITIAL_SIZE = "unknown size";

	private final Label fBtnOutputLbl;
	private final Label fImageSizeLbl;

	public Applet() {
		setLayout(new FlowLayout());

		Label captionLabel = new Label(WELCOME, Label.CENTER);
		add(captionLabel);

		fBtnOutputLbl = new Label(BTN_LBL_BEFORE);
		fBtnOutputLbl.setName(NAME_LBL_BTN_OUTPUT);
		add(fBtnOutputLbl);

		Button btn = new Button("button");
		btn.setName(NAME_BTN);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fBtnOutputLbl.setText(BTN_LBL_AFTER);
			}
		});
		add(btn);

		fImageSizeLbl = new Label(INITIAL_SIZE);
		fImageSizeLbl.setName(NAME_LBL_IMG_SIZE);
		add(fImageSizeLbl);
	}

	public void init() {
		showStatus(getParameter("InitialStatus"));

		Image okImage = getImage(getDocumentBase(), "ok.gif");
		if (okImage != null) {
			fImageSizeLbl.setText(okImage.getWidth(this) + "x" + okImage.getHeight(this));
		}
	}

}
