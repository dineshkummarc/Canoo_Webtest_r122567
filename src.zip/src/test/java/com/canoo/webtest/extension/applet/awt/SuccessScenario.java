package com.canoo.webtest.extension.applet.awt;

import com.canoo.webtest.extension.applet.runner.AbstractScenario;
import com.canoo.webtest.extension.applet.runner.AppletRunner;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.LabelOperator;
import org.netbeans.jemmy.util.NameComponentChooser;

import java.awt.Frame;
import java.awt.Label;

/**
 * @author Denis N. Antonioli
 */
public class SuccessScenario extends AbstractScenario {
	public SuccessScenario(AppletRunner appletRunner, Frame applet) {
		super(appletRunner, applet);
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());

		Label compWelcomeLbl = (Label) appOper.findSubComponent(new LabelOperator.LabelByLabelFinder(Applet.WELCOME));
		if (compWelcomeLbl == null) {
			return 1;
		}

		LabelOperator compBtnLblOper = new LabelOperator(appOper, new NameComponentChooser(Applet.NAME_LBL_BTN_OUTPUT));
		if (compBtnLblOper == null ||
		   !Applet.BTN_LBL_BEFORE.equals(compBtnLblOper.getText())) {
			return 2;
		}

		LabelOperator imgBtnLblOper = new LabelOperator(appOper, new NameComponentChooser(Applet.NAME_LBL_IMG_SIZE));
		if (imgBtnLblOper == null ||
		   Applet.INITIAL_SIZE.equals(imgBtnLblOper.getText())) {
			return 3;
		}

/*
although this runs on the Mac, awt makes problem on the build server
		ButtonOperator btnOper = new ButtonOperator(appOper, new NameComponentChooser(Applet.NAME_BTN));
		if (btnOper == null) {
			return 3;
		}
		btnOper.push();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			return 4;
		}
		if (!Applet.BTN_LBL_AFTER.equals(compBtnLblOper.getText())) {
			LOG.error("Got '" + compBtnLblOper.getText() + "' instead of '" + Applet.BTN_LBL_AFTER + "'");
			return 5;
		}

		Label compStatusLbl = (Label) appOper.findSubComponent(new LabelOperator.LabelFinder(new NameComponentChooser(com.canoo.webtest.extension.applet.runner.AbstractAppletStub.APPLET_STATUS_NAME)));
		if (compStatusLbl == null) {
			return 6;
		}
		// the value of the label comes from the one of the applet's parameters.
		if (!compStatusLbl.getText().equals("Status: Init")) {
			return 7;
		}
*/
		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (success expected)";
	}
}