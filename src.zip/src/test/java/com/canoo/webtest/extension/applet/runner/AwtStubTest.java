package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;

import javax.swing.JApplet;

/**
 * @author Denis N. Antonioli
 */
public class AwtStubTest extends AbstractAppletStubTestCase {

	AbstractAppletStub createAppletStubInstance(JApplet applet, AbstractAppletTag appletTag) {
		return new AwtStub(null, applet,appletTag, "Unnamed");
	}
}
