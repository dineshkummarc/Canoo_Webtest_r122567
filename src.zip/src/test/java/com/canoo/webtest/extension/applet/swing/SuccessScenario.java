package com.canoo.webtest.extension.applet.swing;

import com.canoo.webtest.extension.applet.runner.AbstractScenario;
import com.canoo.webtest.extension.applet.AppletPluginResults;
import org.apache.log4j.Logger;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.JButtonOperator;
import org.netbeans.jemmy.operators.JLabelOperator;
import org.netbeans.jemmy.util.NameComponentChooser;

import javax.swing.JLabel;
import java.awt.Frame;

/**
 * @author Denis N. Antonioli
 */
public class SuccessScenario extends AbstractScenario {
	private static final Logger LOG = Logger.getLogger(SuccessScenario.class);

	public SuccessScenario(com.canoo.webtest.extension.applet.runner.AppletRunner appletRunnerStep, Frame applet) {
		super(appletRunnerStep, applet);
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());

		JLabel compWelcomeLbl = (JLabel) appOper.findSubComponent(new JLabelOperator.JLabelByLabelFinder(Applet.WELCOME));
		if (failsWelcomeExpectations(compWelcomeLbl)) {
			return 1;
		}

		JLabel compBtnLbl = (JLabel) appOper.findSubComponent(new NameComponentChooser(Applet.NAME_LBL_BTN_OUTPUT));
		if (compBtnLbl == null || !Applet.BTN_LBL_BEFORE.equals(compBtnLbl.getText())) {
			return 2;
		}
		JButtonOperator btnOper = new JButtonOperator(appOper, new NameComponentChooser(Applet.NAME_BTN));
		if (btnOper == null) {
			return 3; // TODO: remove, can never occur?
		}
		btnOper.push();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			return 4;
		}
		if (!Applet.BTN_LBL_AFTER.equals(compBtnLbl.getText())) {
			LOG.error("Got '" + compBtnLbl.getText() + "' instead of '" + Applet.BTN_LBL_AFTER + "'");
			return 5;
		}

		JLabel compStatusLbl = (JLabel) appOper.findSubComponent(new JLabelOperator.JLabelFinder(new NameComponentChooser(com.canoo.webtest.extension.applet.runner.AbstractAppletStub.APPLET_STATUS_NAME)));
		if (compStatusLbl == null) {
			return 6;
		}
		// the value of the label comes from the one of the applet's parameters.
		if (!"Status: Init".equals(compStatusLbl.getText())) {
			return 7;
		}

		getAppletRunner().getAppletContext().getAppletPluginResults().setProperty("applet.result.ant", "ant property", AppletPluginResults.Property.ANT);
		getAppletRunner().getAppletContext().getAppletPluginResults().setProperty("applet.result.dynamic", "dynamic property", AppletPluginResults.Property.DYNAMIC);
		return 0;
	}

    private static boolean failsWelcomeExpectations(JLabel compWelcomeLbl) {
        return compWelcomeLbl == null || compWelcomeLbl.getIcon() == null || compWelcomeLbl.getIcon().getIconHeight() != 10 || compWelcomeLbl.getIcon().getIconWidth() != 10;
    }

    public String getDescription() {
		return getClass().getName() + " test (success expected)";
	}
}