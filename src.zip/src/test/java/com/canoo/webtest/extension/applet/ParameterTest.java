package com.canoo.webtest.extension.applet;

import junit.framework.TestCase;

/**
 * @author Denis N. Antonioli
 */
public class ParameterTest extends TestCase {
	private Parameter fParameter;

	protected void setUp() throws Exception {
		fParameter = new Parameter();
		assertNull(fParameter.getName());
		assertNull(fParameter.getValue());
	}

	public void testName() throws Exception {
		fParameter.setName("nom");
		assertEquals("nom", fParameter.getName());
		assertNull(fParameter.getValue());
	}

	public void testValue() throws Exception {
		fParameter.setValue("valeur");
		assertEquals("valeur", fParameter.getValue());
		assertNull(fParameter.getName());
	}

	public void testFullConstructor() {
		fParameter = new Parameter("nom", "valeur");
		assertEquals("nom", fParameter.getName());
		assertEquals("valeur", fParameter.getValue());
	}
}
