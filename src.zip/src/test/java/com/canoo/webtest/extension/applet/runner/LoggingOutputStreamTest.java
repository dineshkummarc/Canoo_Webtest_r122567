package com.canoo.webtest.extension.applet.runner;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.log4j.Appender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.easymock.MockControl;
import org.easymock.ParameterMatcher;

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;

/**
 * @author Denis N. Antonioli
 */
public final class LoggingOutputStreamTest extends TestCase
{
    private Logger fLOG;
    private LoggingOutputStream fLoggingOutputStream;
    private MockControl fAppenderControl;
    private Appender fAppenderMock;
    private static final Class LAST_FRAMEWORK_CLASS = Logger.class;
    private static final Level TEST_PRIORITY = Level.INFO;

    protected void setUp() throws Exception {
        fAppenderControl = MockControl.createControl(Appender.class);
        fAppenderMock = (Appender) fAppenderControl.getMock();

        fLOG = Logger.getLogger(LoggingOutputStreamTest.class);
        fLOG.removeAllAppenders();
        fLOG.addAppender(fAppenderMock);
        fLOG.setLevel(TEST_PRIORITY);

        fLoggingOutputStream = new LoggingOutputStream(LAST_FRAMEWORK_CLASS, fLOG, TEST_PRIORITY);
    }

    protected void tearDown() throws Exception {
        fAppenderControl.reset();
    }

    public void testLoggingOutputStream() throws Exception {
        ThrowAssert.assertThrows("Accept missing last framework class.", RuntimeException.class, new TestBlock()
        {
            public void call() throws Exception {
                new LoggingOutputStream(null, fLOG, TEST_PRIORITY);
            }
        });
        ThrowAssert.assertThrows("Accept missing logger.", RuntimeException.class, new TestBlock()
        {
            public void call() throws Exception {
                new LoggingOutputStream(LAST_FRAMEWORK_CLASS, null, TEST_PRIORITY);
            }
        });
        ThrowAssert.assertThrows("Accept missing priority.", RuntimeException.class, new TestBlock()
        {
            public void call() throws Exception {
                new LoggingOutputStream(LAST_FRAMEWORK_CLASS, Logger.getRootLogger(), null);
            }
        });
        assertEquals(fLoggingOutputStream.getLastFrameworkClassName(), LAST_FRAMEWORK_CLASS.getName());
        assertEquals(fLoggingOutputStream.getLogger(), fLOG);
        assertEquals(fLoggingOutputStream.getPriority(), TEST_PRIORITY);
    }

    public void testClose() throws Exception {
        final StringBuffer sb = new StringBuffer("foo");
        fAppenderMock.doAppend(new LoggingEvent(LAST_FRAMEWORK_CLASS.getName(), fLOG, TEST_PRIORITY, "foo", null));
        fAppenderControl.setMatcher(new LoggingEventStringMatcher(sb));
        fAppenderControl.replay();

        fLoggingOutputStream.write(sb.toString().getBytes());
        fLoggingOutputStream.close();
        ThrowAssert.assertThrows("Write on closed stream.", IOException.class, new TestBlock()
        {
            public void call() throws Exception {
                fLoggingOutputStream.write(0x20);
            }
        });

        fAppenderControl.verify();
    }

    public void testWriteNull() throws Exception {
        fAppenderControl.replay();
        assertEquals(0, fLoggingOutputStream.getCount());
        fLoggingOutputStream.write(0);
        assertEquals(0, fLoggingOutputStream.getCount());
        fAppenderControl.verify();
    }

    public void testWriteGrowsBuffer() throws Exception {
        final StringBuffer sb = new StringBuffer(LoggingOutputStream.DEFAULT_BUFFER_LENGTH + 1);

        fAppenderMock.doAppend(new LoggingEvent(LAST_FRAMEWORK_CLASS.getName(), fLOG, TEST_PRIORITY, null, null));
        fAppenderControl.setMatcher(new LoggingEventStringMatcher(sb));
        fAppenderControl.replay();

        assertEquals(0, fLoggingOutputStream.getCount());
        writeAndStoreACharacter(sb, 'A');
        for (int i = 1; i < LoggingOutputStream.DEFAULT_BUFFER_LENGTH; i++) {
            writeAndStoreACharacter(sb, 'B');
        }
        writeAndStoreACharacter(sb, 'C');

        assertEquals(LoggingOutputStream.DEFAULT_BUFFER_LENGTH + 1, fLoggingOutputStream.getCount());
        fLoggingOutputStream.flush();
        fAppenderControl.verify();
    }

    public void testLoggingEventStringMatcher() {
        StringBuffer sb = new StringBuffer();
        final String message = "message";
        final Object[] arguments = new Object[]{
                new LoggingEvent(LAST_FRAMEWORK_CLASS.getName(), fLOG, TEST_PRIORITY, message, null)
        };

        LoggingEventStringMatcher lesm = new LoggingEventStringMatcher(sb);
        assertEquals(message, lesm.toString(arguments));
        assertFalse(lesm.matches(null, arguments));
        sb.append(message);
        assertTrue(lesm.matches(null, arguments));
    }

    private void writeAndStoreACharacter(final StringBuffer sb, final char b) throws IOException {
        fLoggingOutputStream.write(b);
        sb.append(b);
    }

    public void testFlushSkipsEmptyLine() throws Exception {
        fAppenderControl.replay();
        fLoggingOutputStream.write(LoggingOutputStream.LINE_SEPARATOR.getBytes());
        fLoggingOutputStream.flush();
        fAppenderControl.verify();
    }

    public void testFlushSkipsOnlyEmptyLine() throws IOException {
        LoggingOutputStream loggingOutputStream = new LoggingOutputStream(LAST_FRAMEWORK_CLASS, Logger.getRootLogger(), TEST_PRIORITY);
        byte[] testBytes = LoggingOutputStream.LINE_SEPARATOR.getBytes();
        // write same number of bytes as blank line but not line separator
        for (int i = 0; i < testBytes.length; i++) {
            testBytes[i] = 'x';
        }
        loggingOutputStream.write(testBytes);
        assertEquals(LoggingOutputStream.LINE_SEPARATOR.length(), loggingOutputStream.getCount());
        loggingOutputStream.flush(); // coverage will determine if this worked
        assertEquals(0, loggingOutputStream.getCount());
    }

    private static final class LoggingEventStringMatcher implements ParameterMatcher
    {
        private final StringBuffer fSb;

        private LoggingEventStringMatcher(StringBuffer sb) {
            fSb = sb;
        }

        public boolean matches(Object[] expected, Object[] actual) {
            return fSb.toString().equals(((LoggingEvent) actual[0]).getMessage());
        }

        public String toString(Object[] arguments) {
            return (String) ((LoggingEvent) arguments[0]).getMessage();
        }
    }
}