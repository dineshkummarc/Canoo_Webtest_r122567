// Released under the Canoo Webtest license.
package com.canoo.webtest.extension.applet.cookie;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import junit.framework.TestCase;

import org.easymock.MockControl;

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;

/**
 * @author Denis N. Antonioli
 */
public class ShowHeadersTest extends TestCase {
	private ShowHeaders fShowHeaders;
	private HttpServletResponse fServletResponse;
	private HttpServletRequest fServletRequest;
	private MockControl fServletResponseControl, fServletRequestControl;
	private ByteArrayOutputStream fOutputStream;


	protected void setUp() throws Exception {
		fServletResponseControl = MockControl.createControl(HttpServletResponse.class);
		fServletResponse = (HttpServletResponse) fServletResponseControl.getMock();
		fOutputStream = new ByteArrayOutputStream();
		fServletResponse.getWriter();
		fServletResponseControl.setReturnValue(new PrintWriter(fOutputStream));
		fServletResponse.setContentType("text/plain");
		fServletResponseControl.replay();

		fServletRequestControl = MockControl.createControl(HttpServletRequest.class);
		fServletRequest = (HttpServletRequest) fServletRequestControl.getMock();

		fShowHeaders = new ShowHeaders();
	}

	public void testDoGetWithoutContent() throws Exception {
		fServletRequest.getHeaderNames();
		fServletRequestControl.setReturnValue(new EmptyEnumeration());
		fServletRequestControl.replay();

		assertGet("", "");
	}

	public void testDoGetWithHeaders() throws Exception {
		final String expectedMsg = setUpHeaders();

		fServletRequestControl.replay();

		assertGet(expectedMsg, "");
	}

	public void testDoPostWithoutContent() throws Exception {
		final String body = "";

		fServletRequest.getHeaderNames();
		fServletRequestControl.setReturnValue(new EmptyEnumeration());
		fServletRequest.getInputStream();
		fServletRequestControl.setReturnValue(new StringServletInputStream(body));
		fServletRequestControl.replay();

		assertPost("", body);
	}

	public void testDoPostWithInputStream() throws Exception {
		final String body = "hello";

		fServletRequest.getHeaderNames();
		fServletRequestControl.setReturnValue(new EmptyEnumeration());
		fServletRequest.getInputStream();
		fServletRequestControl.setReturnValue(new StringServletInputStream(body));
		fServletRequestControl.replay();

		assertPost("", body);
	}

	public void testDoPostWithHeaders() throws Exception {
		final String body = "";

		final String expectedMsg = setUpHeaders();

		fServletRequest.getInputStream();
		fServletRequestControl.setReturnValue(new StringServletInputStream(body));
		fServletRequestControl.replay();

		assertPost(expectedMsg, body);
	}

	public void testDoPostWithHeadersAndBody() throws Exception {
		final String body = "hello";

		final String expectedMsg = setUpHeaders();

		fServletRequest.getInputStream();
		fServletRequestControl.setReturnValue(new StringServletInputStream(body));
		fServletRequestControl.replay();

		assertPost(expectedMsg, body);
	}

	private String setUpHeaders() {
		final Map headers = new Hashtable();
		headers.put("header1", new Vector(Arrays.asList(new String[]{"value1"})));
		headers.put("header2", new Vector(Arrays.asList(new String[]{"value2.1", "value2.2"})));

		fServletRequest.getHeaderNames();
		fServletRequestControl.setReturnValue(((Hashtable) headers).keys());
		final StringBuffer expectedMsg = new StringBuffer();
		for (Enumeration names = ((Hashtable) headers).keys(); names.hasMoreElements();) {
			final String name = (String) names.nextElement();
			fServletRequest.getHeaders(name);
			fServletRequestControl.setReturnValue(((Vector) headers.get(name)).elements());
			final Enumeration values = ((Vector) headers.get(name)).elements();
			while (values.hasMoreElements()) {
				expectedMsg.append(name).append(": ").append(values.nextElement()).append(ShowHeaders.CRLF);
			}
		}
		return expectedMsg.toString();
	}

	private void assertGet(final String header, final String body) throws ServletException, IOException {
		fShowHeaders.doGet(fServletRequest, fServletResponse);
		assertResponse(header, body);
		fServletRequestControl.verify();
		fServletResponseControl.verify();
	}

	private void assertPost(final String header, final String body) throws ServletException, IOException {
		fShowHeaders.doPost(fServletRequest, fServletResponse);
		assertResponse(header, body);
		fServletRequestControl.verify();
		fServletResponseControl.verify();
	}

	private void assertResponse(final String header, final String body) {
		assertEquals(ShowHeaders.TITLE_HEADER + header + ShowHeaders.TITLE_BODY + body + ShowHeaders.END_BODY,
		   fOutputStream.toString());
	}

	public void testEmptyEnumeration() {
		final Enumeration en = new EmptyEnumeration();
		assertFalse(en.hasMoreElements());
		ThrowAssert.assertThrows(NoSuchElementException.class, new TestBlock() {
			public void call() throws Exception {
				en.nextElement();
			}
		});
	}

	private static class EmptyEnumeration implements Enumeration {
		public boolean hasMoreElements() {
			return false;
		}

		public Object nextElement() {
			throw new NoSuchElementException("Basta");
		}
	}

	private static final class StringServletInputStream extends ServletInputStream {
		private final ByteArrayInputStream fInputStream;

		private StringServletInputStream(final String body) {
			fInputStream = new ByteArrayInputStream(body.getBytes());
		}

		public int read() throws IOException {
			return fInputStream.read();
		}
	}
}
