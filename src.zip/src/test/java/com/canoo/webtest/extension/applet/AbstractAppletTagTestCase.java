// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.extension.applet;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.html.HtmlPage;


/**
 * @author Denis N. Antonioli
 */
public abstract class AbstractAppletTagTestCase extends TestCase {
	private URL fDocumentURL;
	private AbstractAppletTag fAppletTag;

	protected void setUp() throws Exception {
		fAppletTag = createAppletTagInstance("http://localhost:9090/index.html");
		fDocumentURL = new URL("http://localhost:9090/");
	}

	protected abstract AbstractAppletTag createAppletTagInstance(String url) throws MalformedURLException;

	/**
	 * Helper method for the subclasses.
	 *
	 * @param currentResponse Contains the html.
	 * @param id Selects within the currentRepsonse the desired applet/object.
	 * @return An instance of an implementation of AbstractAppletTag
	 * @throws NoSuchFieldException
	 * @throws MalformedURLException
	 */
	AbstractAppletTag newInstance(final Page currentResponse, final String id) throws NoSuchFieldException, MalformedURLException {
		return AbstractAppletTag.newInstance(fDocumentURL,
		   ((HtmlPage) currentResponse).getHtmlElementById(id));
	}

	public void testSetCodebase() throws Exception {
		AbstractAppletTag ap = createAppletTagInstance("http://localhost:9090/selftest/");

		ap.setCodebase("http://localhost:9090/selftest/codebase/");
		assertEquals("http://localhost:9090/selftest/codebase/", ap.getCodebase().toExternalForm());
		ap.setCodebase("codebase/");
		assertEquals("http://localhost:9090/selftest/codebase/", ap.getCodebase().toExternalForm());
		ap.setCodebase("/codebase/");
		assertEquals("http://localhost:9090/codebase/", ap.getCodebase().toExternalForm());
		ap.setCodebase("http://remotehost:9090/codebase/");
		assertEquals("http://remotehost:9090/codebase/", ap.getCodebase().toExternalForm());
	}

	public void testSetBase() throws Exception {
		AbstractAppletTag ap;

		ap = createAppletTagInstance(fDocumentURL.toExternalForm());
		assertEquals(fDocumentURL.toExternalForm(), ap.getBase().toString());
		ap = createAppletTagInstance("http://localhost:9090/index.html");
		assertEquals(fDocumentURL.toExternalForm(), ap.getBase().toString());
		ap = createAppletTagInstance("http://localhost:9090/selftest/");
		assertEquals("http://localhost:9090/selftest/", ap.getBase().toString());
		ap = createAppletTagInstance("http://localhost:9090/selftest/index.html");
		assertEquals("http://localhost:9090/selftest/", ap.getBase().toString());
	}

	public void testSetArchive() throws Exception {
		fAppletTag.getArchive().clear();
		fAppletTag.setArchive("");
		assertTrue(fAppletTag.getArchive().isEmpty());
		fAppletTag.setArchive("a.jar, b.jar");
		assertFalse(fAppletTag.getArchive().isEmpty());
		assertEquals(2, fAppletTag.getArchive().size());
		assertEquals("a.jar", fAppletTag.getArchive().get(0));
		assertEquals("b.jar", fAppletTag.getArchive().get(1));
	}

	public void testGetArchiveURL() throws MalformedURLException {
		assertTrue(fAppletTag.getArchive().isEmpty());
		URL urls[] = fAppletTag.getArchiveURL();

		assertEquals(1, urls.length);
		assertEquals(fDocumentURL.toExternalForm(), urls[0].toString());
		fAppletTag.setArchive("a.jar, b.jar");
		urls = fAppletTag.getArchiveURL();
		assertEquals(3, urls.length);
		assertEquals("http://localhost:9090/a.jar", urls[0].toString());
		assertEquals("http://localhost:9090/b.jar", urls[1].toString());
		assertEquals(fDocumentURL.toExternalForm(), urls[2].toString());

	}

	public void testGetArchiveURLWithCodebase() throws MalformedURLException {
		fAppletTag.setArchive("a.jar");
		fAppletTag.setCodebase("applet/");
		URL urls[] = fAppletTag.getArchiveURL();
		assertEquals(2, urls.length);
		assertEquals("http://localhost:9090/applet/a.jar", urls[0].toString());
		assertEquals(fDocumentURL.toExternalForm() + "applet/", urls[1].toString());

		fAppletTag.setCodebase("applet");
		urls = fAppletTag.getArchiveURL();
		assertEquals(2, urls.length);
		assertEquals("http://localhost:9090/applet/a.jar", urls[0].toString());
		assertEquals(fDocumentURL.toExternalForm() + "applet/", urls[1].toString());
	}

	public void testSetCode() throws MalformedURLException {
		fAppletTag.addParameter(AbstractAppletTag.ATTR_CODE, "java.net.URL");
		assertEquals("java.net.URL", fAppletTag.getCode());
		fAppletTag.addParameter(AbstractAppletTag.ATTR_CODE, "java.net.URL.class");
		assertEquals("java.net.URL", fAppletTag.getCode());
	}

	public void testSetWidth() {
		assertEquals("0", fAppletTag.getWidth());
		fAppletTag.addParameterLength(AbstractAppletTag.ATTR_WIDTH, "10");
		assertEquals("10", fAppletTag.getWidth());
	}

	public void testSetHeight() {
		assertEquals("0", fAppletTag.getHeight());
		fAppletTag.addParameterLength(AbstractAppletTag.ATTR_HEIGHT, "20");
		assertEquals("20", fAppletTag.getHeight());
	}

	public void testSetName() throws MalformedURLException {
		assertNull(fAppletTag.getName());
		fAppletTag.addParameter(AbstractAppletTag.ATTR_NAME, "nom");
		assertEquals("nom", fAppletTag.getName());
	}

	public void testAddParameter() throws MalformedURLException {
		fAppletTag.addParameter("key", "value");
		assertEquals("value", fAppletTag.getParameter("key"));
		assertEquals("value", fAppletTag.getParameter("kEy"));
		assertEquals("value", fAppletTag.getParameter("KEY"));
	}

	public void testGetParameter() {
		final List list = new ArrayList();

		assertNull(fAppletTag.getParameter("aList"));

		fAppletTag.addParameterObject("aList", list);
		assertEquals("", fAppletTag.getParameter("aList"));
		list.add("1");
		assertEquals("1", fAppletTag.getParameter("aList"));
		list.add("2");
		assertEquals("1, 2", fAppletTag.getParameter("aList"));

		fAppletTag.addParameterObject("aString", "hello");
		assertEquals("hello", fAppletTag.getParameter("aString"));

		fAppletTag.addParameterObject("aUrl", fDocumentURL);
		assertEquals(fDocumentURL.toExternalForm(), fAppletTag.getParameter("aUrl"));
	}

    protected void checkNewInstanceParameters(final Page currentResponse) throws NoSuchFieldException, MalformedURLException {
        AbstractAppletTag ap;
        ap = newInstance(currentResponse, "1");
        ThrowAssert.assertThrows("Attribute name of param is missing.",
           NoSuchFieldException.class,
           new TestBlock() {
               public void call() throws Exception {
                   newInstance(currentResponse, "2");
               }
           });

        ap = newInstance(currentResponse, "3");
        assertNull(ap.getParameter("p1"));
        ap = newInstance(currentResponse, "4");
        assertEquals("v1", ap.getParameter("p1"));
        assertNull(ap.getParameter("key is missing"));

        ap = newInstance(currentResponse, "5");
        assertEquals("v1", ap.getParameter("p1"));
        assertEquals("v2", ap.getParameter("p2"));

        ap = newInstance(currentResponse, "6");
        assertEquals("v2", ap.getParameter("p1"));

        ap = newInstance(currentResponse, "7");
        assertEquals("&", ap.getParameter("p1"));
    }

    protected void checkNewInstanceParameterOverwriteAttribute(Page currentResponse) throws NoSuchFieldException, MalformedURLException {
        AbstractAppletTag ap;
        ap = newInstance(currentResponse, "1");
        assertEquals("100", ap.getParameter("width"));
        assertEquals(ap.getWidth(), ap.getParameter("width"));

        ap = newInstance(currentResponse, "2");
        assertEquals("http://localhost:9090/foo/", ap.getCodebase().toExternalForm());
    }
}
