package com.canoo.webtest.extension.applet;

import junit.framework.TestCase;
import org.netbeans.jemmy.JemmyException;

import java.net.MalformedURLException;
import java.net.URL;

public class AppletPluginResultsTest extends TestCase {
	private AppletPluginResults fAppletPluginResults;

	protected void setUp() {
		fAppletPluginResults = new AppletPluginResults();
	}

	public void testFrame() throws MalformedURLException {
		assertTrue(fAppletPluginResults.getFrames().isEmpty());
		final URL url = new URL("http://www.canoo.com");
		final String target = "_self";
		fAppletPluginResults.setFrame(target, url);
		assertFalse(fAppletPluginResults.getFrames().containsKey("not" + target));
		assertTrue(fAppletPluginResults.getFrames().containsKey(target));
		assertEquals(url, fAppletPluginResults.getFrames().get(target));
	}

	public void testReturnValue() {
		assertNull(fAppletPluginResults.getReturnValue());
		Integer rv = new Integer(2046);
		fAppletPluginResults.setReturnValue(rv);
		assertEquals(rv, fAppletPluginResults.getReturnValue());
	}

	public void testException() {
		assertNull(fAppletPluginResults.getException());
		Throwable rv = new NullPointerException("foo");
		fAppletPluginResults.setException(rv);
		assertEquals(rv.getMessage(), fAppletPluginResults.getException());
	}

	public void testJemmyException() {
		assertNull(fAppletPluginResults.getJemmyException());
		JemmyException rv = new JemmyException("foo");
		fAppletPluginResults.setJemmyException(rv);
		assertEquals(rv.getMessage(), fAppletPluginResults.getJemmyException());
	}

	public void testProperty() {
		assertTrue(fAppletPluginResults.getProperties().isEmpty());
		fAppletPluginResults.setProperty("nom", "valeur", AppletPluginResults.Property.ANT);
		assertEquals(1, fAppletPluginResults.getProperties().size());
		AppletPluginResults.Property prop = (AppletPluginResults.Property) fAppletPluginResults.getProperties().get(0);
		assertEquals("nom", prop.getName());
		assertEquals("valeur", prop.getValue());
		assertEquals(AppletPluginResults.Property.ANT, prop.getType());
	}
}
