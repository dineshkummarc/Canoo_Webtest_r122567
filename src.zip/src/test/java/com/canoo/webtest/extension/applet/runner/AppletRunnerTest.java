package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;
import com.canoo.webtest.extension.applet.AppletPluginArguments;
import com.canoo.webtest.extension.applet.AppletPluginResults;
import com.canoo.webtest.extension.applet.AppletRunnerStep;
import com.canoo.webtest.extension.applet.AppletTag;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.TestCase;

import java.applet.Applet;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class AppletRunnerTest extends TestCase {
    private AppletRunner fAppletRunner;
    private AppletPluginArguments fAppletPluginArguments;
    private static final String AN_APPLET = "com.canoo.webtest.extension.applet.awt.Applet";

    protected void setUp() throws Exception {
        AppletRunnerStep ars = new AppletRunnerStep();
        ars.setScenario("Scenario.class");
        ars.setScenarioLocation("lib/scenario.jar");
        fAppletPluginArguments = new AppletPluginArguments();
        fAppletRunner = new AppletRunner(fAppletPluginArguments);
    }

    public void testGetAppletContext() {
        assertNotNull(fAppletRunner.getAppletContext());
    }

    public void testGetAppletPluginArguments() {
        assertEquals(fAppletPluginArguments, fAppletRunner.getAppletPluginArguments());
    }

    public void testSurvivesInterruption() throws Exception {
        AppletPluginResults fAppletPluginResults = new AppletPluginResults();
        final AppletTag appletTag = new AppletTag("http://localhost:9090/");
        appletTag.addParameter(AbstractAppletTag.ATTR_NAME, "nom");

        final AppletPluginArguments apa = new AppletPluginArguments();
        apa.setBaseWindowName("Unnamed");
        Context fContext = new com.canoo.webtest.extension.applet.runner.Context(fAppletPluginResults);
        Applet applet = new Applet();
        final AbstractAppletStub stub = new AwtStub(fContext, applet, appletTag, apa.getBaseWindowName());
        fAppletRunner = new AppletRunner(fAppletPluginArguments) {
            protected void writeArguments(AppletPluginResults apr) {
            }
        };
        final ScenarioRunner jemmyRunnable = new ScenarioRunner(ScenarioRunnerTest.NOOP_SCENARIO) {
            public void startTest() throws InterruptedException {
                throw new InterruptedException();
            }
        };
        ThrowAssert.assertThrows(InterruptedException.class, new TestBlock() {
            public void call() throws Throwable {
                fAppletRunner.internalRun(stub, jemmyRunnable);
            }
        });
    }

    public void testLoadApplet() throws Exception {
        final AppletTag appletTag = new AppletTag("http://localhost:9090/") {
            /**
             * Sets the classpath to fetch resources from the url where the test class is.
             * @throws java.net.MalformedURLException
             */
            public URL[] getArchiveURL() throws MalformedURLException {
                final URL appletURL = AppletRunnerStep.getUrlForClass(getParameter(AbstractAppletTag.ATTR_CODE));
                final URL cloverURL = AppletRunnerStep.getUrlForClass(AppletRunnerStep.A_CLOVER_CLASS);
                ///CLOVER:OFF ignore clover/non-clover for clover coverage
                return cloverURL == null ? new URL[]{appletURL} : new URL[]{appletURL, cloverURL};
                ///CLOVER:ON
            }

        };
        appletTag.addParameter(AbstractAppletTag.ATTR_CODE, AN_APPLET);
        appletTag.addParameter(AbstractAppletTag.ATTR_ARCHIVE, AppletRunnerStep.getUrlForClass(AN_APPLET).toExternalForm());

        java.applet.Applet applet = fAppletRunner.newApplet(appletTag);
// We must compare the name due to the different class loaders.
        assertEquals(AN_APPLET, applet.getClass().getName());

        appletTag.addParameter(AbstractAppletTag.ATTR_CODE, Context.class.getName());
        ThrowAssert.assertThrows("Wrong type of class loaded.",
           NoClassDefFoundError.class,
           new TestBlock() {
               public void call() throws Exception {
                   fAppletRunner.newApplet(appletTag);
               }
           });
    }

}
