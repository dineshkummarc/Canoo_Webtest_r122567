package com.canoo.webtest.extension.applet.runner;

/**
 * @author Denis N. Antonioli
 */

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.AssertionFailedError;
import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.netbeans.jemmy.JemmyProperties;
import org.netbeans.jemmy.Scenario;
import org.netbeans.jemmy.TestOut;
import org.netbeans.jemmy.TimeoutExpiredException;
import org.netbeans.jemmy.Timeouts;

import java.io.PrintWriter;
import java.io.StringWriter;

public class ScenarioRunnerTest extends TestCase {
	private static final Logger LOG = Logger.getLogger(ScenarioRunnerTest.class);
	static final Scenario NOOP_SCENARIO = new Scenario() {
		public int runIt(Object param) {
			return 0;
		}
	};

	private ScenarioRunner fScenarioRunner;

	protected void setUp() throws Exception {
		JemmyProperties.setCurrentTimeout(ScenarioRunner.WHOLE_TEST_TIMEOUT_NAME, 50);
		fScenarioRunner = new ScenarioRunner(NOOP_SCENARIO);
	}

	public void testOutputAccessors() {
		assertNotNull(fScenarioRunner.getOutput());
		final TestOut newOutput = new TestOut();
		fScenarioRunner.setOutput(newOutput);
		assertSame(newOutput, fScenarioRunner.getOutput());
	}

	public void testTimeoutAccessors() {
		assertSame(JemmyProperties.getCurrentTimeouts(), fScenarioRunner.getTimeouts());
		Timeouts newTimeouts = new Timeouts();
		fScenarioRunner.setTimeouts(newTimeouts);
		assertSame(newTimeouts, fScenarioRunner.getTimeouts());
	}

	public void testSuccess() throws InterruptedException {
		fScenarioRunner.startTest();
		fScenarioRunner.join();

		assertNotNull(fScenarioRunner.getResult());
		assertEquals(0, ((Integer) fScenarioRunner.getResult()).intValue());

		assertNull(fScenarioRunner.getException());
		assertNull(fScenarioRunner.getJemmyException());
	}

	public void testException() throws InterruptedException {
		final String exceptionMessage = "Breaks the scenario!";
		ScenarioRunner scenarioRunner = new ScenarioRunner(new Scenario() {
			public int runIt(Object param) {
				throw new IllegalArgumentException(exceptionMessage);
			}
		});
		scenarioRunner.getTimeouts().setTimeout(ScenarioRunner.ACTION_PRODUCER_MAX_ACTION_TIME_NAME, 50);
		scenarioRunner.startTest();
		scenarioRunner.join();

		assertNull(scenarioRunner.getResult());

		Throwable thrown = scenarioRunner.getException();
		assertNotNull(thrown);
		assertSame(IllegalArgumentException.class, thrown.getClass());
		assertEquals(exceptionMessage, thrown.getMessage());
		assertNullException(scenarioRunner.getJemmyException());
	}

	private static void assertNullException(final Throwable exception) {
		if (exception != null) {
			LOG.error(exception.getMessage(), exception);
			fail("Expected null, but got " + exception);
		}
	}

	public void testAssertNullException() {
		assertNullException(null);
		ThrowAssert.assertThrows(AssertionFailedError.class, new TestBlock() {
			public void call() throws Throwable {
				assertNullException(new Throwable("foo"));
			}
		});
	}

	public void testGetDescription() throws Exception {
		final StringWriter stringWriter = new StringWriter();
		fScenarioRunner.setOutput(new TestOut(null, new PrintWriter(stringWriter), null));
		fScenarioRunner.printSynopsis();
		assertTrue(stringWriter.toString().startsWith(ScenarioRunner.DESCRIPTION));
	}

	public void testTimeout() throws InterruptedException {
		ScenarioRunner scenarioRunner = new ScenarioRunner(new SleepingScenario(1000));
		scenarioRunner.getTimeouts().setTimeout(ScenarioRunner.ACTION_PRODUCER_MAX_ACTION_TIME_NAME, 50);
		scenarioRunner.startTest();
		scenarioRunner.join();

		assertNotNull(scenarioRunner.getResult());
		assertEquals(2, ((Integer) scenarioRunner.getResult()).intValue());

		assertNullException(scenarioRunner.getException());

		Throwable thrown = scenarioRunner.getJemmyException();
		assertNotNull(thrown);
		assertSame(TimeoutExpiredException.class, thrown.getClass());
	}

	/**
	 * Test nothing, but complete test coverage.
	 */
	public void testSleeper() {
		Scenario scenario = new SleepingScenario(0);
		assertEquals(0, scenario.runIt(null));
	}

	private static final class SleepingScenario implements Scenario {
		private final int fNapDuration;

		private SleepingScenario(final int sleepDuration) {
			fNapDuration = sleepDuration;
		}

		public int runIt(Object param) {
			try {
				Thread.sleep(fNapDuration);
			} catch (InterruptedException e) {
				return 2;
			}
			return 0;
		}
	}
}
