// Copyright (c) 2002-2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.awt;

import com.canoo.webtest.extension.applet.runner.AbstractScenario;
import com.canoo.webtest.extension.applet.runner.AppletRunner;
import junit.framework.Assert;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.LabelOperator;

import java.awt.Frame;
import java.awt.Label;

/**
 * This scenario has a dependency on junit.
 * This is to make sure that any jar can be specified when calling the appletRunnerStep.
 * @author Denis N. Antonioli
 */
public class JunitScenario extends AbstractScenario {
	public JunitScenario(AppletRunner appletRunner, Frame applet) {
		super(appletRunner, applet);
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());

		Label compWelcomeLbl = (Label) appOper.findSubComponent(new LabelOperator.LabelByLabelFinder(Applet.WELCOME));
		Assert.assertNotNull(compWelcomeLbl);
		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (success expected)";
	}
}