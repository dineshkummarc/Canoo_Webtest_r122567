package com.canoo.webtest.extension.applet.jemmy;

import junit.framework.TestCase;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class ClassNameComponentChooserTest extends TestCase {
	private ClassNameComponentChooser fComponentChooser;
	static final String DESCRIPTION = "Descriptive text";

	protected void setUp() throws Exception {
		fComponentChooser = new ClassNameComponentChooser(DESCRIPTION, "javax.swing.JLabel");
	}

	public void testDescription() {
		assertTrue(fComponentChooser.getDescription().indexOf(DESCRIPTION) > -1);
	}

	public void testCheckComponent() {
		assertTrue(fComponentChooser.checkComponent(new JLabel()));
		assertFalse(fComponentChooser.checkComponent(new JTextField()));
	}
}