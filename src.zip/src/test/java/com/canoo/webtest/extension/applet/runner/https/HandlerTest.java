// Copyright (c) 2002-2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.runner.https;

import com.canoo.webtest.engine.Configuration;
import com.canoo.webtest.extension.applet.runner.http.HttpURLConnection;
import com.canoo.webtest.interfaces.IConnectionInitializer;
import com.canoo.webtest.security.ConnectionInitializationException;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.TestCase;
import org.apache.commons.httpclient.HttpsURL;

import java.net.URL;

public class HandlerTest extends TestCase {
	private Handler fHandler;

	protected void setUp() throws Exception {
		fHandler = new Handler();
	}

	public void testGetDefaultPort() {
		assertEquals(HttpsURL.DEFAULT_PORT, fHandler.getDefaultPort());
	}

	public void testOpenConnection() throws Exception {
		assertTrue(fHandler.openConnection(new URL("https://webtest.canoo.com/")) instanceof HttpURLConnection);
	}

	public void testAllocateAndInit() throws Exception {
		Handler.allocateAndInit(GoodConnectionInitializer.class.getName());
		Handler.allocateAndInit(BadConnectionInitializer.class.getName());
		ThrowAssert.assertThrows(Exception.class, new TestBlock() {
			public void call() throws Throwable {
				Handler.allocateAndInit(HandlerTest.class.getName());
			}
		});
	}

    public void testInitializeCustomConnectionInitializer(){
        Handler.initializeCustomConnectionInitializer();
        assertTrue(Handler.isAlreadyInitialized());
        Handler.initializeCustomConnectionInitializer();
    }

    public static class GoodConnectionInitializer implements IConnectionInitializer {
		public void initializeConnection(Configuration config) throws ConnectionInitializationException {
			// do nothing
		}
	}

	public static class BadConnectionInitializer implements IConnectionInitializer {
		public void initializeConnection(Configuration config) throws ConnectionInitializationException {
			throw new ConnectionInitializationException("");
		}
	}
}