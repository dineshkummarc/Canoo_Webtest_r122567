package com.canoo.webtest.extension.applet.runner;

import junit.framework.TestCase;

import java.awt.*;

/**
 * @author Denis N. Antonioli
 */
public class AbstractScenarioTest extends TestCase {
	private AbstractScenario fAbstractScenario;
	private AppletRunner fAppletRunner = new AppletRunner(null);
	private Frame fRootFrame = new Frame();

//	{
//		AppletRunnerStep ars = new AppletRunnerStep();
//		ars.setScenario("Scenario.class");
//		ars.setScenarioLocation("lib/scenario.jar");
//	}

    protected void setUp() throws Exception {
        super.setUp();
        fAbstractScenario = new AbstractScenario(fAppletRunner, fRootFrame)
        {
            public int runIt(Object o) {
                return 0;
            }
        };
    }

    public void testGetRootFrame() throws Exception {
		assertEquals(fRootFrame, fAbstractScenario.getRootFrame());
	}

	public void testGetAppletRunner() throws Exception {
		assertEquals(fAppletRunner, fAbstractScenario.getAppletRunner());
	}

	public void testScenarioIsImplemented() {
		assertEquals(0, fAbstractScenario.runIt(null));
	}
}
