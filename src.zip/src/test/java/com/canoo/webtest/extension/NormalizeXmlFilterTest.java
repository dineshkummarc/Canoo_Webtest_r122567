// Copyright � 2006-2007 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.extension;

/**
 * NormalizeXmlFilter Tester.
 *
 * @author Paul King
 */
public class NormalizeXmlFilterTest extends ResponseFilterTestCase
{
    private static final String SOURCE_1 = "<xml><tag attribute='123'>\r\n</tag></xml>\r\n";
    private static final String EXPECTEDXML_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<xml>\n" +
            "  <tag attribute=\"123\"/>\n" +
            "</xml>\n";

    public void testNormalizesContent() {
        final NormalizeXmlFilter filter = new NormalizeXmlFilter();
        checkFilterContentAsXml(filter, SOURCE_1, EXPECTEDXML_1);
        assertEquals(SOURCE_1.length(), getFilterContent(filter, SOURCE_1, "text/plain").length());
    }

}
