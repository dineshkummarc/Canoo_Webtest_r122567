// Copyright � 2005 ASERT. Released under the Canoo Webtest license.
package com.canoo.webtest.extension.applet.runner;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.canoo.webtest.boundary.AppletRunnerBoundary;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.TestCase;

/**
 * @author Paul King
 */
public class AppletRunnerHelperTest extends TestCase {
    private static final String IO_ERROR_MESSAGE = "AppletRunnerHelperTest.testReadPluginArgumentsIoError";
    private static final String NOT_FOUND_ERROR_MESSAGE = "AppletRunnerHelperTest.testReadPluginArgumentsNotFoundError";

    public void testReadPluginArgumentsIoError() {
        AppletRunnerBoundary boundary = new AppletRunnerBoundary() {
            public void processIoException(int ioErrorCode) {
                throw new RuntimeException(IO_ERROR_MESSAGE);
            }
        };
        final AppletRunnerHelper appletRunnerHelper = new AppletRunnerHelper(0, 0, boundary);
        String message = ThrowAssert.assertThrows(RuntimeException.class, new TestBlock()
        {
            public void call() throws Throwable {
                appletRunnerHelper.readPluginArguments(".");
            }
        });
        assertEquals(IO_ERROR_MESSAGE, message);
    }

    public void testReadPluginArgumentsNotFoundError() {
        AppletRunnerBoundary boundary = new AppletRunnerBoundary()
        {
            public void processClassNotFound(int classNotFoundErrorCode) {
                throw new RuntimeException(NOT_FOUND_ERROR_MESSAGE);
            }
            public void processIoException(int ioErrorCode) {
            }
        };
        final AppletRunnerHelper appletRunnerHelper = new AppletRunnerHelper(0, 0, boundary) {
            protected ObjectInputStream createObjectInputStream(FileInputStream fis) throws IOException {
                return null;
            }
            protected Object readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
                return Class.forName("wont.be.Found");
            }
        };
        String message = ThrowAssert.assertThrows(RuntimeException.class, new TestBlock()
        {
            public void call() throws Throwable {
                appletRunnerHelper.readPluginArguments("pom.xml"); // any file
            }
        });
        assertEquals(NOT_FOUND_ERROR_MESSAGE, message);
        // coverage
        assertNull(appletRunnerHelper.readPluginArguments("."));
    }
}
