package com.canoo.webtest.extension.applet.swing;

import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class Applet extends JApplet {
	private final JLabel fBtnOutputLbl;
	private final JLabel fCaptionLabel;

	static final String NAME_LBL_BTN_OUTPUT = "field.output";
	static final String NAME_BTN = "clickMe";
	static final String NAME_TXT_FIELD = "field.input";

	static final String BTN_LBL_BEFORE = "button has not been pushed yet";
	static final String BTN_LBL_AFTER = "button has been pushed";
	static final String WELCOME = "Welcome to the test Swing Applet.";

	public Applet() {
		getContentPane().setLayout(new FlowLayout());


		fCaptionLabel = new JLabel(WELCOME, JLabel.CENTER);
		fCaptionLabel.setHorizontalAlignment(JLabel.CENTER);
		getContentPane().add(fCaptionLabel);

		fBtnOutputLbl = new JLabel(BTN_LBL_BEFORE);
		fBtnOutputLbl.setName(NAME_LBL_BTN_OUTPUT);
		getContentPane().add(fBtnOutputLbl);

		JButton btn = new JButton("button");
		btn.setName(NAME_BTN);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fBtnOutputLbl.setText(BTN_LBL_AFTER);
			}
		});
		getContentPane().add(btn);
	}

	public void init() {
		try {
			fCaptionLabel.setIcon(new ImageIcon(new URL(getDocumentBase(), "ok.gif")));
		} catch (MalformedURLException e) {
			System.out.println(e.getMessage());
		}

		showStatus(getParameter("InitialStatus"));
	}

}
