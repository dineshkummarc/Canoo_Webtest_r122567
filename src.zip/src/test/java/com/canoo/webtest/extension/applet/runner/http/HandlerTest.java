// Copyright (c) 2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.runner.http;

import junit.framework.TestCase;
import org.apache.commons.httpclient.HttpURL;

import java.net.URL;

public class HandlerTest extends TestCase {
	private Handler fHandler;

	protected void setUp() throws Exception {
		fHandler = new Handler();
	}

	public void testGetDefaultPort() {
		assertEquals(HttpURL.DEFAULT_PORT, fHandler.getDefaultPort());
	}

	public void testOpenConnection() throws Exception {
		assertTrue(fHandler.openConnection(new URL("http://webtest.canoo.com/")) instanceof HttpURLConnection);
	}
}