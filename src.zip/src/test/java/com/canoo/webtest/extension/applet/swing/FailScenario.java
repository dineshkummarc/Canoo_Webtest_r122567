package com.canoo.webtest.extension.applet.swing;

import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.JLabelOperator;

import java.awt.Component;
import java.awt.Frame;

/**
 * A simple failing scenario.
 * Scenario may signal error by throwing exceptions.
 * @see com.canoo.webtest.extension.applet.awt.FailScenario
 * @author Denis N. Antonioli
 */
public class FailScenario extends com.canoo.webtest.extension.applet.runner.AbstractScenario {
	public FailScenario(com.canoo.webtest.extension.applet.runner.AppletRunner appletRunner, Frame applet) {
		super(appletRunner, applet);
	}

	public int runIt(Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());
		Component comp = appOper.findSubComponent(new JLabelOperator.JLabelByLabelFinder("XXXX " + Applet.WELCOME));
		if (comp == null) {
			throw new IllegalStateException("The applet does not display the expected message.");
		}
		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (failure expected)";
	}
}