package com.canoo.webtest.extension.applet.jemmy;

import com.canoo.webtest.extension.applet.AppletPluginResults;
import com.canoo.webtest.extension.applet.runner.Context;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.TestCase;
import org.netbeans.jemmy.JemmyException;
import org.netbeans.jemmy.JemmyProperties;
import org.netbeans.jemmy.TestOut;
import org.netbeans.jemmy.Timeouts;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class ContextOperatorTest extends TestCase {
	private ContextOperator fContextOperator;
	private Context fContext;

	protected void setUp() throws Exception {
		fContext = new Context(new AppletPluginResults());
		fContextOperator = new ContextOperator(fContext);
	}

	public void testGetContext() {
		assertEquals(fContext, fContextOperator.getContext());
	}

	public void testOutputAccessors() {
		assertNotNull(fContextOperator.getOutput());
		final TestOut newOutput = new TestOut();
		fContextOperator.setOutput(newOutput);
		assertSame(newOutput, fContextOperator.getOutput());
	}

	public void testTimeoutAccessors() {
		assertSame(JemmyProperties.getCurrentTimeouts(), fContextOperator.getTimeouts());
		Timeouts newTimeouts = new Timeouts();
		fContextOperator.setTimeouts(newTimeouts);
		assertSame(newTimeouts, fContextOperator.getTimeouts());
	}

	public void testWaitAnyDocument() throws MalformedURLException {

		final Timeouts timeouts = new Timeouts();
		timeouts.setTimeout(ContextOperator.WAIT_TIMEOUT_NAME, 1);

		fContextOperator.setTimeouts(timeouts);
		ThrowAssert.assertThrows(JemmyException.class, new TestBlock() {
			public void call() throws Exception {
				fContextOperator.waitShowDocument();
			}
		});
		fContext.showDocument(new URL("http://webtest.canoo.com/"));
		fContextOperator.waitShowDocument();
	}

	public void testWaitDocument() throws MalformedURLException {
		final URL url = new URL("http://webtest.canoo.com/");

		final Timeouts timeouts = new Timeouts();
		timeouts.setTimeout(ContextOperator.WAIT_TIMEOUT_NAME, 1);

		fContextOperator.setTimeouts(timeouts);
		ThrowAssert.assertThrows(JemmyException.class, new TestBlock() {
			public void call() throws Exception {
				fContextOperator.waitShowDocument(url);
			}
		});
		fContext.showDocument(url);
		fContextOperator.waitShowDocument(url);
	}
}
