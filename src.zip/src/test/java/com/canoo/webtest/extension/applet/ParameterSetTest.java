// Released under the Canoo Webtest license.
package com.canoo.webtest.extension.applet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import junit.framework.TestCase;

import org.apache.tools.ant.Project;

import com.canoo.webtest.ant.WebtestTask;
import com.canoo.webtest.self.ContextStub;
import com.canoo.webtest.steps.Step;
import com.canoo.webtest.steps.StepTest;

/**
 * @author Denis N. Antonioli
 */
public class ParameterSetTest extends TestCase {
	private ParameterSet fParameterSet;
	private Step fStep;

	protected void setUp() {
		fParameterSet = new ParameterSet();
		fStep = new StepTest.RevealingStepStub();
		fStep.setProject(new Project());
		WebtestTask.setThreadContext(new ContextStub());
		fStep.setWebtestProperty("nom.0", "valeur.0", Step.PROPERTY_TYPE_DYNAMIC);
		fStep.setWebtestProperty("nom.1", "valeur.1", Step.PROPERTY_TYPE_DYNAMIC);
		fStep.setWebtestProperty("nom.zero", "valeur.zero", Step.PROPERTY_TYPE_DYNAMIC);
	}

	public void testIterator() {
		assertFalse(fParameterSet.iterator().hasNext());
	}

	public void testAdd() {
		final Parameter parameter = new Parameter("nom", "valeur");
		final ParameterRef parameterRef = new ParameterRef("nom", "regex", "type");

		fParameterSet.add(parameter);
		fParameterSet.add(parameterRef);
		Iterator iter = fParameterSet.iterator();
		assertEquals(parameter, iter.next());
		assertEquals(parameterRef, iter.next());
		assertFalse(iter.hasNext());
	}

	public void testExpandProperties() {
		fParameterSet.add(new Parameter("nom", "valeur"));
		fParameterSet.add(new ParameterRef("Name.\\1", "nom.(\\d)", Step.PROPERTY_TYPE_DYNAMIC));

		fParameterSet.expandProperties(fStep);

		final Map expected = new HashMap();
		expected.put("nom", "valeur");
		expected.put("Name.0", "valeur.0");
		expected.put("Name.1", "valeur.1");
		assertParameters(expected, fParameterSet);
	}

	public void testAddMatchedParameters() {
		assertTrue(ParameterSet.addMatchedParameters(fStep, new ParameterRef("nom", "regex", Step.PROPERTY_TYPE_ANT)).isEmpty());
		final List parameters = ParameterSet.addMatchedParameters(fStep, new ParameterRef("Name.\\1", "nom.(\\d)", Step.PROPERTY_TYPE_DYNAMIC));

		final Map actual = new HashMap();
		for (Iterator iter = parameters.iterator(); iter.hasNext();)
		{
			final Parameter param = (Parameter) iter.next();
			actual.put(param.getName(), param.getValue());
		}
		
		final Map expected = new HashMap();
		expected.put("Name.0", "valeur.0");
		expected.put("Name.1", "valeur.1");
		assertEquals(expected, actual);
	}

	private static void assertParameters(final Map expectedParams, final ParameterSet parameterSet) {
		final Map actual = new HashMap();
		for (final Iterator iter = parameterSet.iterator(); iter.hasNext();)
		{
			final Parameter param = (Parameter) iter.next();
			actual.put(param.getName(), param.getValue());
		}
		assertEquals(expectedParams, actual);
	}

	public void testReplaceGroups() {
		final Pattern pat = Pattern.compile("nom.(\\d)");
		final Matcher matcher = pat.matcher("nom.0");
		matcher.matches();
		assertEquals(1, matcher.groupCount());
		assertEquals("nom.0", matcher.group(0));
		assertEquals("0", matcher.group(1));

		assertEquals("nom.0", ParameterSet.replaceGroups("\\0", matcher));
		assertEquals("Name.0", ParameterSet.replaceGroups("Name.\\1", matcher));
		assertEquals("0=0", ParameterSet.replaceGroups("\\1=\\1", matcher));
		assertEquals("0=\\2", ParameterSet.replaceGroups("\\1=\\2", matcher));
		assertEquals("0=\\10", ParameterSet.replaceGroups("\\1=\\10", matcher));
	}
}