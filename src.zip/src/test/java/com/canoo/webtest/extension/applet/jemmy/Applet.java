package com.canoo.webtest.extension.applet.jemmy;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class Applet extends java.applet.Applet {
	static final String NAME_BTN = "clickMe";
	static final String WELCOME = "Welcome to the test Jemmy Applet.";
	private URL fNextPageUrl;

	public Applet() {
		setLayout(new FlowLayout());

		Label captionLabel = new Label(WELCOME, Label.CENTER);
		add(captionLabel);

		Button btn = new Button("button");
		btn.setName(NAME_BTN);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String target = getParameter("target");
				if (target == null) {
					getAppletContext().showDocument(fNextPageUrl);
				} else {
					getAppletContext().showDocument(fNextPageUrl, target);
				}
			}
		});
		add(btn);
	}

	public void init() {
		showStatus(getParameter("InitialStatus"));
		try {
			fNextPageUrl = new URL(getDocumentBase(), "postApplet.html");
		} catch (MalformedURLException e) {
			showStatus(e.getMessage());
			e.printStackTrace();
		}
	}
}
