package com.canoo.webtest.extension.applet;

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import com.canoo.webtest.steps.BaseStepTestCase;
import com.gargoylesoftware.htmlunit.Page;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.MalformedURLException;

/**
 * @author Denis N. Antonioli
 */
public class AppletTagTest extends AbstractAppletTagTestCase {

	protected AbstractAppletTag createAppletTagInstance(String url) throws MalformedURLException {
		return new AppletTag(url);
	}

	public void testNewInstance() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<applet id='1' width='1' height='2' />" +
		   "<applet id='2' code='foo' height='2'/>" +
		   "<applet id='3' code='foo' width='1' />" +
		   "<applet id='4' code='foo' width='1' height='2' />" +
		   "<applet id='5' code='foo' width='1%' height='2%' />" +
		   "</body></html>").getCurrentResponse();

		ThrowAssert.assertThrows("Applet element does not define the code.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "1");
			   }
		   });
		ThrowAssert.assertThrows("Applet element does not define the width.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "2");
			   }
		   });
		ThrowAssert.assertThrows("Applet element does not define the height.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "3");
			   }
		   });
		AbstractAppletTag ap;
		ap = newInstance(currentResponse, "4");
		assertEquals("foo", ap.getCode());
		assertEquals("1", ap.getWidth());
		assertEquals("2", ap.getHeight());
		ap = newInstance(currentResponse, "5");
		assertEquals("foo", ap.getCode());
		assertEquals("1%", ap.getWidth());
		assertEquals("2%", ap.getHeight());
	}

	public void testNewInstanceOptionalAttribute() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<applet id='1' code='foo' width='1' height='2' archive='arc' />" +
		   "<applet id='2' code='foo' width='1' height='2' name='nom' />" +
		   "<applet id='3' code='foo' width='1' height='2' codebase='http://localhost:9090/foo' />" +
		   "<applet id='4' code='foo' width='1' height='2' object='objet' />" +
		   "</body></html>").getCurrentResponse();
		AbstractAppletTag ap;
		ap = newInstance(currentResponse, "1");
		assertEquals(1, ap.getArchive().size());
		assertEquals("arc", ap.getArchive().get(0));
		ap = newInstance(currentResponse, "2");
		assertEquals("nom", ap.getName());
		ap = newInstance(currentResponse, "3");
		assertEquals("http://localhost:9090/foo/", ap.getCodebase().toExternalForm());
		ThrowAssert.assertThrows("Attribute object is not supported.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "4");
			   }
		   });
	}

	public void testNewInstanceParameters() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<applet id='1' code='foo' width='1' height='2' ></applet>" +
		   "<applet id='2' code='foo' width='1' height='2' ><param /></applet>" +
		   "<applet id='3' code='foo' width='1' height='2' ><param name='p1' /></applet>" +
		   "<applet id='4' code='foo' width='1' height='2' ><param name='p1' value='v1' /></applet>" +
		   "<applet id='5' code='foo' width='1' height='2' ><param name='p1' value='v1' /><param name='p2' value='v2' /></applet>" +
		   "<applet id='6' code='foo' width='1' height='2' ><param name='p1' value='v1' /><param name='p1' value='v2' /></applet>" +
		   "<applet id='7' code='foo' width='1' height='2' ><param name='p1' value='&amp;' /></applet>" +
		   "</body></html>").getCurrentResponse();
        checkNewInstanceParameters(currentResponse);
    }

    public void testNewInstanceParameterOverwriteAttribute() throws Exception {
        final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
           "<applet id='1' code='foo' width='1' height='2' ><param name='width' value='100' /></applet>" +
           "<applet id='2' code='foo' width='1' height='2' ><param name='codebase' value='http://localhost:9090/foo' /></applet>" +
           "</body></html>").getCurrentResponse();
        checkNewInstanceParameterOverwriteAttribute(currentResponse);
    }

	public void testGetParameterAccessAttributes() throws IOException, ParserConfigurationException, NoSuchFieldException {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<applet id='1' code='foo' width='1' height='2' archive='arc' name='nom' codebase='http://localhost:9090/foo' />" +
		   "</body></html>").getCurrentResponse();
		AbstractAppletTag ap;
		ap = newInstance(currentResponse, "1");
		assertEquals("foo", ap.getParameter("code"));
		assertEquals("1", ap.getParameter("width"));
		assertEquals("2", ap.getParameter("height"));
		assertEquals("arc", ap.getParameter("archive"));
		assertEquals("nom", ap.getParameter("name"));
		assertEquals("http://localhost:9090/foo/", ap.getParameter("codebase"));
	}
}
