// Copyright (c) 2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.jemmy;

import com.canoo.webtest.extension.applet.runner.AppletRunner;

import java.awt.Frame;

/**
 * @author Denis N. Antonioli
 */
public class ShowInBlankSuccessScenario extends SuccessScenario {

	public ShowInBlankSuccessScenario(AppletRunner appletRunner, Frame applet) {
		super(appletRunner, applet, "_blank");
	}
}
