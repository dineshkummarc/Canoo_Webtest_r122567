// Copyright (c) 2004 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.runner.http;

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.TestCase;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.StatusLine;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.easymock.MockControl;

import java.io.IOException;
import java.net.ProtocolException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownServiceException;
import java.util.List;
import java.util.Map;

/**
 * @author Denis N. Antonioli
 */
public class HttpURLConnectionTest extends TestCase {
	private HttpURLConnection fHttpURLConnection;
	private URL fUrl;
	private MockControl fMethodControl;
	private HttpMethod fMockMethod;
	private static final NoOpHttpClient NO_OP_HTTP_CLIENT;

	static {
		NO_OP_HTTP_CLIENT = new NoOpHttpClient();
	}

	protected void setUp() throws Exception {
		super.setUp();
		fMethodControl = MockControl.createStrictControl(HttpMethod.class);
		fMockMethod = (HttpMethod) fMethodControl.getMock();

		fUrl = new URL("http://webtest.canoo.com/index.html");
		fHttpURLConnection = new HttpURLConnection(fUrl, NO_OP_HTTP_CLIENT);
		fHttpURLConnection.setHttpRequestMethod(fMockMethod);
		HttpURLConnection.setCookies(null);
	}

	public void testUsingProxy() throws Exception {
		assertFalse(fHttpURLConnection.usingProxy());
	}

	public void testSetMethod() throws IOException {
		fHttpURLConnection = new HttpURLConnection(fUrl);
		assertEquals("Default method is GET", "GET", fHttpURLConnection.getRequestMethod());
		assertTrue("Default method class is GET", fHttpURLConnection.getHttpRequestMethod() instanceof GetMethod);

		fHttpURLConnection.setHttpRequestMethod(fMockMethod);
		assertEquals(0, fHttpURLConnection.getHttpRequestMethod().toString().indexOf("EasyMock"));

		fHttpURLConnection.setRequestMethod("GET");
		assertEquals("Method is GET", "GET", fHttpURLConnection.getRequestMethod());
		assertTrue("Method class is GET", fHttpURLConnection.getHttpRequestMethod() instanceof GetMethod);

		ThrowAssert.assertThrows(ProtocolException.class, new TestBlock() {
			public void call() throws Exception {
				fHttpURLConnection.setRequestMethod("ThisMethodDoesNotExist");
			}
		});
	}

	public void testGetInputStreamRequireDoInput() throws IOException {
		fHttpURLConnection.setDoInput(false);
		ThrowAssert.assertThrows(ProtocolException.class, new TestBlock() {
			public void call() throws Exception {
				fHttpURLConnection.getInputStream();
			}
		});
	}

	public void testGetOutputStreamRequireDoOutput() throws IOException {
		fHttpURLConnection.setDoOutput(false);
		ThrowAssert.assertThrows(ProtocolException.class, new TestBlock() {
			public void call() throws Exception {
				fHttpURLConnection.getOutputStream();
			}
		});
	}

	public void testGetOutputStreamFailsUnlessGetPostPut() throws IOException {
		fHttpURLConnection.setDoOutput(true);
		fMockMethod.getName();
		fMethodControl.setReturnValue("MOCK");
		fMethodControl.replay();
		fHttpURLConnection.setHttpRequestMethod(fMockMethod);

		ThrowAssert.assertThrows(UnknownServiceException.class, new TestBlock() {
			public void call() throws Exception {
				fHttpURLConnection.getOutputStream();
			}
		});
	}

	public void testGetOutputStreamGET() throws IOException {
		fHttpURLConnection = new HttpURLConnection(fUrl);
		fHttpURLConnection.setDoOutput(true);
		assertNotNull(fHttpURLConnection.getOutputStream());
		assertEquals("POST", fHttpURLConnection.getRequestMethod());
	}

	public void testGetOutputStreamPOST() throws IOException {
		fHttpURLConnection = new HttpURLConnection(fUrl);
		fHttpURLConnection.setDoOutput(true);
		fHttpURLConnection.setRequestMethod("POST");
		assertNotNull(fHttpURLConnection.getOutputStream());
		assertEquals("POST", fHttpURLConnection.getRequestMethod());

		ThrowAssert.assertThrows(ProtocolException.class, new TestBlock() {
			public void call() throws Exception {
				fHttpURLConnection.setRequestMethod("GET");
			}
		});
	}

	public void testGetOutputStreamPUT() throws IOException {
		fHttpURLConnection = new HttpURLConnection(fUrl);
		fHttpURLConnection.setDoOutput(true);
		fHttpURLConnection.setHttpRequestMethod(new PutMethod());
		assertNotNull(fHttpURLConnection.getOutputStream());
		assertEquals("PUT", fHttpURLConnection.getRequestMethod());
	}

	public void testSetRequestProperty() throws IOException {
		fHttpURLConnection.setRequestProperty("clef", "valeur");
		assertEquals("valeur", fHttpURLConnection.getRequestProperty("clef"));

		fHttpURLConnection.setRequestProperty("key", "value");
		assertEquals("valeur", fHttpURLConnection.getRequestProperty("clef"));
		assertEquals("value", fHttpURLConnection.getRequestProperty("key"));

		fHttpURLConnection.setRequestProperty("clef", "serrure");
		assertEquals("serrure", fHttpURLConnection.getRequestProperty("clef"));
		assertEquals("value", fHttpURLConnection.getRequestProperty("key"));

	}

	public void testAddRequestProperty() {
		fHttpURLConnection.addRequestProperty("clef", "valeur");
		assertEquals("valeur", fHttpURLConnection.getRequestProperty("clef"));

		fHttpURLConnection.addRequestProperty("clef", "serrure");
		assertEquals("valeur, serrure", fHttpURLConnection.getRequestProperty("clef"));

		List actual = (List) fHttpURLConnection.getRequestProperties().get("clef");
		assertEquals(2, actual.size());
		assertEquals("valeur", (String) actual.get(0));
		assertEquals("serrure", (String) actual.get(1));

		fHttpURLConnection.setRequestProperty("clef", "valeur");
		assertEquals("valeur", fHttpURLConnection.getRequestProperty("clef"));
	}

	public void testGetRequestProperty() throws IOException {
		assertNull(fHttpURLConnection.getRequestProperty(null));
		assertNull(fHttpURLConnection.getRequestProperty("NotSet"));

		fHttpURLConnection.setRequestProperty("clef", "valeur");
		assertEquals("valeur", fHttpURLConnection.getRequestProperty("clef"));
	}

	public void testGetRequestProperties() throws IOException {
		assertTrue((fHttpURLConnection.getRequestProperties()).isEmpty());

		ThrowAssert.assertThrows(java.lang.UnsupportedOperationException.class, new TestBlock() {
			public void call() throws Exception {
				fHttpURLConnection.getRequestProperties().put("key", "value");
			}
		});

		fHttpURLConnection.setRequestProperty("clef", "valeur");
		List actual = (List) fHttpURLConnection.getRequestProperties().get("clef");
		assertEquals(1, actual.size());
		assertEquals("valeur", (String) actual.get(0));
	}

	public void testGetHeaderFieldsEmpty() {
		fMockMethod.getResponseHeaders();
		fMethodControl.setReturnValue(new Header[0]);
		fMethodControl.replay();
		final Map headerFields = fHttpURLConnection.getHeaderFields();
		assertTrue(headerFields.isEmpty());
		ThrowAssert.assertThrows(UnsupportedOperationException.class, new TestBlock() {
			public void call() throws Exception {
				headerFields.put("key", "value");
			}
		});
		fMethodControl.verify();
	}

	public void testGetHeaderFields() {
		fMockMethod.getResponseHeaders();
		fMethodControl.setReturnValue(new Header[]{
			new Header("h0", "v0"),
			new Header("h1", "v1"),
			new Header("h2", "v21,v22")});
		fMethodControl.replay();

		final Map headerFields = fHttpURLConnection.getHeaderFields();
		assertFalse(headerFields.isEmpty());
		ThrowAssert.assertThrows(UnsupportedOperationException.class, new TestBlock() {
			public void call() throws Exception {
				headerFields.put("key", "value");
			}
		});

		assertEquals(new String[]{"v1"}, (List) headerFields.get("h1"));
		assertEquals(new String[]{"v21", "v22"}, (List) headerFields.get("h2"));

		fMethodControl.verify();
	}

	private void assertEquals(final String[] expected, final List values) {
		ThrowAssert.assertThrows(UnsupportedOperationException.class, new TestBlock() {
			public void call() throws Exception {
				values.add("key");
			}
		});
		assertEquals(expected.length, values.size());
		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], values.get(i));
		}
	}

	public void testGetHeaderFieldKeyNoHeader() {
		fMockMethod.getResponseHeaders();
		fMethodControl.setReturnValue(new Header[0]);
		fMethodControl.replay();
		assertNull(fHttpURLConnection.getHeaderFieldKey(2));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldKey() {
		fMockMethod.getResponseHeaders();
		fMethodControl.setReturnValue(new Header[]{
			new Header("h0", "v0"),
			new Header("h1", "v1"),
			new Header("h2", "v2")});
		fMethodControl.replay();
		assertEquals("h2", fHttpURLConnection.getHeaderFieldKey(2));
		fMethodControl.verify();
	}


	public void testGetHeaderFieldByIndexNoHeader() {
		fMockMethod.getResponseHeaders();
		fMethodControl.setReturnValue(new Header[0]);
		fMethodControl.replay();
		assertNull(fHttpURLConnection.getHeaderField(2));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldByIndex() {
		fMockMethod.getResponseHeaders();
		fMethodControl.setReturnValue(new Header[]{
			new Header("h0", "v0"),
			new Header("h1", "v1"),
			new Header("h2", "v2")});
		fMethodControl.replay();
		assertEquals("v2", fHttpURLConnection.getHeaderField(2));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldByNameNoHeader() {
		fMockMethod.getResponseHeader("h2");
		fMethodControl.setReturnValue(null);
		fMethodControl.replay();
		assertNull(fHttpURLConnection.getHeaderField("h2"));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldByNameNullValue() {
		fMockMethod.getResponseHeader("h2");
		fMethodControl.setReturnValue(new Header("h2", null));
		fMethodControl.replay();
		assertNull(fHttpURLConnection.getHeaderField("h2"));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldByNameEmptyValue() {
		fMockMethod.getResponseHeader("h2");
		fMethodControl.setReturnValue(new Header("h2", "     "));
		fMethodControl.replay();
		assertEquals("", fHttpURLConnection.getHeaderField("h2"));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldByNameSingleValue() {
		fMockMethod.getResponseHeader("h2");
		fMethodControl.setReturnValue(new Header("h2", "v2"));
		fMethodControl.replay();
		assertEquals("v2", fHttpURLConnection.getHeaderField("h2"));
		fMethodControl.verify();
	}

	public void testGetHeaderFieldByNameMultipleValue() {
		fMockMethod.getResponseHeader("h2");
		fMethodControl.setReturnValue(new Header("h2", "v21, v22"));
		fMethodControl.replay();
		assertEquals("v22", fHttpURLConnection.getHeaderField("h2"));
		fMethodControl.verify();
	}

	public void testConnect() throws IOException {
		fMockMethod.execute(null, null);
		fMethodControl.setMatcher(MockControl.ALWAYS_MATCHER);
		fMethodControl.setReturnValue(HttpStatus.SC_OK);
		fMethodControl.replay();

		assertFalse(fHttpURLConnection.isConnected());
		fHttpURLConnection.connect();
		assertTrue(fHttpURLConnection.isConnected());
		fMethodControl.verify();

		ThrowAssert.assertThrows(ProtocolException.class, new TestBlock() {
			public void call() throws Throwable {
				fHttpURLConnection.setRequestMethod("ThisMethodDoesNotExist");
			}
		});
		ThrowAssert.assertThrows(IllegalStateException.class, new TestBlock() {
			public void call() throws Throwable {
				fHttpURLConnection.setRequestProperty("clef", "valeur");
			}
		});
		ThrowAssert.assertThrows(IllegalStateException.class, new TestBlock() {
			public void call() throws Throwable {
				fHttpURLConnection.addRequestProperty("clef", "valeur");
			}
		});
		ThrowAssert.assertThrows(IllegalStateException.class, new TestBlock() {
			public void call() throws Throwable {
				fHttpURLConnection.getRequestProperty("clef");
			}
		});
		ThrowAssert.assertThrows(IllegalStateException.class, new TestBlock() {
			public void call() throws Throwable {
				fHttpURLConnection.getRequestProperties();
			}
		});

		fMethodControl.reset();
		// successive connect() do nothing
		fMethodControl.replay();

		fHttpURLConnection.connect();
		fMethodControl.verify();
	}

    public void testDisconnectNotImplemented() {
        // coverage purposes
        ThrowAssert.assertThrows(NoSuchMethodError.class, new TestBlock() {
			public void call() throws Throwable {
                fHttpURLConnection.disconnect();
            }
		});
	}

	public void testFailConnection() throws IOException, URISyntaxException {
		fMockMethod.execute(null, null);
		fMethodControl.setMatcher(MockControl.ALWAYS_MATCHER);
		fMethodControl.setReturnValue(HttpStatus.SC_NOT_FOUND);
		fMockMethod.getName();
		fMethodControl.setReturnValue("MOCK");
		fMockMethod.getStatusLine();
		fMethodControl.setReturnValue(new StatusLine("HTTP 1 404 This connection failed."));
		fMethodControl.replay();

		assertFalse(fHttpURLConnection.isConnected());
		fHttpURLConnection.connect();
		assertTrue(fHttpURLConnection.isConnected());
		fMethodControl.verify();
	}
/*
	public void testConnectCookieHandlingWithCookie() throws IOException {
		AppletPluginArguments cookieProvider = new AppletPluginArguments();
		HttpURLConnection.setCookieProvider(cookieProvider);

		fMethod.getRequestHeader("cookie");
		fMethodControl.setReturnValue(CookiePolicy.getDefaultSpec().formatCookieHeader(fCookie));
		fMethod.execute(null, null);
		fMethodControl.setMatcher(MockControl.ALWAYS_MATCHER);
		fMethodControl.setReturnValue(HttpStatus.SC_OK);
		fMethodControl.replay();

		assertFalse(fHttpURLConnection.isConnected());
		fHttpURLConnection.connect();
		assertTrue(fHttpURLConnection.isConnected());
		fMethodControl.verify();
	}

	public void testConnectCookieHandlingAddCookie() throws IOException {
		AppletPluginArguments cookieProvider = new AppletPluginArguments();
		cookieProvider.addCookies(new Cookie[]{fCookie});
		HttpURLConnection.setCookieProvider(cookieProvider);

		fMethod.getRequestHeader("cookie");
		fMethodControl.setReturnValue(null);
		fMethod.addRequestHeader(CookiePolicy.getDefaultSpec().formatCookieHeader(fCookie));
		fMethod.execute(null, null);
		fMethodControl.setMatcher(MockControl.ALWAYS_MATCHER);
		fMethodControl.setReturnValue(HttpStatus.SC_OK);
		fMethodControl.replay();

		assertFalse(fHttpURLConnection.isConnected());
		fHttpURLConnection.connect();
		assertTrue(fHttpURLConnection.isConnected());
		fMethodControl.verify();
	}

	public void testConnectCookieHandlingWithoutCookie() throws IOException {
		AppletPluginArguments cookieProvider = new AppletPluginArguments();
		HttpURLConnection.setCookieProvider(cookieProvider);

		fMethod.getRequestHeader("cookie");
		fMethodControl.setReturnValue(null);
		fMethod.execute(null, null);
		fMethodControl.setMatcher(MockControl.ALWAYS_MATCHER);
		fMethodControl.setReturnValue(HttpStatus.SC_OK);
		fMethodControl.replay();

		assertFalse(fHttpURLConnection.isConnected());
		fHttpURLConnection.connect();
		assertTrue(fHttpURLConnection.isConnected());
		fMethodControl.verify();
	}
*/
	public void testGetResponseCode() throws IOException {
		fMockMethod.getStatusCode();
		fMethodControl.setReturnValue(HttpStatus.SC_GONE);
		fMethodControl.replay();

		fHttpURLConnection.getResponseCode();
		fMethodControl.verify();
	}

	public void testGetResponseMessage() throws IOException {
		fMockMethod.getStatusText();
		fMethodControl.setReturnValue("Gone");
		fMethodControl.replay();

		fHttpURLConnection.getResponseMessage();
		fMethodControl.verify();
	}

	private static class NoOpHttpClient extends HttpClient {
		public int executeMethod(HttpMethod method) throws IOException, HttpException {
			// hope that the method is indeed a mock...
			return method.execute(null, null);
		}
	}
}