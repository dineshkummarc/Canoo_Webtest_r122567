package com.canoo.webtest.extension.applet.cookie;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Enumeration;

/**
 * This servlet sends back a text/plain stream that shows the headers and body it received.
 * It is used to test the appletRunner step.
 * @author Denis N. Antonioli
 */
public class ShowHeaders extends HttpServlet {
	static final String CRLF = "\r\n";
	static final String TITLE_HEADER = "Headers" + CRLF + "-------" + CRLF;
	static final String TITLE_BODY = "-------" + CRLF + "Stdin" + CRLF + "-------" + CRLF;
	static final String END_BODY = "-------" + CRLF;

	protected void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws ServletException, IOException {
		PrintWriter out = setupOutput(httpServletResponse);
		writeHeader(out, httpServletRequest);
		out.write(END_BODY);
		out.close();
	}

	protected void doPost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws ServletException, IOException {
		PrintWriter out = setupOutput(httpServletResponse);
		writeHeader(out, httpServletRequest);

		for (InputStream is = httpServletRequest.getInputStream(); ;) {
			int read = is.read();
			if (read == -1) {
				break;
			}
			out.write(read);
		}
		out.write(END_BODY);
		out.close();
	}

	private void writeHeader(PrintWriter out, HttpServletRequest httpServletRequest) {
		out.write(TITLE_HEADER);
		for (Enumeration headers = httpServletRequest.getHeaderNames(); headers.hasMoreElements();) {
			String headerName = (String) headers.nextElement();
			for (Enumeration values = httpServletRequest.getHeaders(headerName); values.hasMoreElements();) {
				out.write(headerName);
				out.write(": ");
				out.write((String) values.nextElement());
				out.write(CRLF);
			}
		}
		out.write(TITLE_BODY);
	}

	private PrintWriter setupOutput(HttpServletResponse httpServletResponse) throws IOException {
		PrintWriter out = httpServletResponse.getWriter();
		httpServletResponse.setContentType("text/plain");
		return out;
	}

}
