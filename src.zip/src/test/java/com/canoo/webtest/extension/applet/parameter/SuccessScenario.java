// Copyright (c) 2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.parameter;

import com.canoo.webtest.extension.applet.jemmy.ContextOperator;
import com.canoo.webtest.extension.applet.runner.AbstractScenario;
import com.canoo.webtest.extension.applet.runner.AppletRunner;
import org.netbeans.jemmy.operators.ButtonOperator;
import org.netbeans.jemmy.operators.ContainerOperator;
import org.netbeans.jemmy.operators.LabelOperator;
import org.netbeans.jemmy.operators.TextAreaOperator;
import org.netbeans.jemmy.util.NameComponentChooser;

import java.awt.Frame;
import java.awt.Label;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Denis N. Antonioli
 */
public class SuccessScenario extends AbstractScenario {


	public SuccessScenario(final AppletRunner appletRunner, final Frame applet) {
		super(appletRunner, applet);
	}

	public int runIt(final Object obj) {
		ContainerOperator appOper = new ContainerOperator(getRootFrame());

		Label compWelcomeLbl = (Label) appOper.findSubComponent(new LabelOperator.LabelByLabelFinder(Applet.WELCOME));
		if (compWelcomeLbl == null) {
			return 1;
		}

		TextAreaOperator taOper = new TextAreaOperator(appOper, new NameComponentChooser(Applet.NAME_TA_PARAMETERS));
		if (taOper == null) {
			return 2;
		}
		StringBuffer text = new StringBuffer();
		for (Iterator iter = getAppletRunner().getAppletPluginArguments().getArguments(); iter.hasNext();) {
			Map.Entry entry = (Map.Entry) iter.next();
			text.append(entry.getKey()).append('=').append(entry.getValue()).append('&');
		}
		if (text.length() > 0) {
			text.deleteCharAt(text.length() - 1);
		}
		taOper.setText(text.toString());

		ButtonOperator btnOper = new ButtonOperator(appOper, new NameComponentChooser(Applet.NAME_BTN));
		if (btnOper == null) {
			return 3;
		}
		btnOper.push();

		new ContextOperator(getAppletRunner().getAppletContext()).waitShowDocument();
		return 0;
	}

	public String getDescription() {
		return getClass().getName() + " test (success expected)";
	}

}
