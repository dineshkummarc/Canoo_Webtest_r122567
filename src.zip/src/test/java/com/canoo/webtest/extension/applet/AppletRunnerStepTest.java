// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.extension.applet;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.xpath.XPathException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.types.CommandlineJava;
import org.apache.tools.ant.types.Environment;
import org.apache.tools.ant.types.Path;
import org.netbeans.jemmy.JemmyException;
import org.xml.sax.SAXException;

import com.canoo.webtest.engine.Configuration;
import com.canoo.webtest.engine.Context;
import com.canoo.webtest.engine.StepExecutionException;
import com.canoo.webtest.engine.StepFailedException;
import com.canoo.webtest.interfaces.IPropertyHandler;
import com.canoo.webtest.self.ContextStub;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import com.canoo.webtest.steps.BaseStepTestCase;
import com.canoo.webtest.steps.Step;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebRequestSettings;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

/**
 * @author Denis N. Antonioli
 * @author Marc Guillemot
 */
public class AppletRunnerStepTest extends BaseStepTestCase {

	public static class AppletRunnerStepStub extends AppletRunnerStep {
		private String fUrl;

		public String getUrl() {
			return fUrl;
		}

		public AppletRunnerStepStub() {
		}

		public AppletRunnerStepStub(final String xpath) {
			setXpath(xpath);
			setScenario("AJemmyTest");
		}

		public Page findTargetWithResults(final AppletPluginResults results, final Context context) throws IOException, SAXException {
			return super.findTargetWithResults(results, context);
		}

		public Page findTarget() throws IOException, SAXException, XPathExpressionException {
			return super.findTarget();
		}

		protected Page getResponse(final WebRequestSettings _settings)
		{
			fUrl = _settings.getUrl().toExternalForm();
			return null;
		}
		
		@Override
		public String getTaskType()
		{
			return getClass().getName();
		}
	}

	private static final String DOCUMENT = "<html><head></head><body>" + "<applet\n"
		+ "\tcode=\"Applet.class\"\n" + "\tarchive=\"SwingApplet.jar\"\n" + "\twidth=\"600\"\n"
		+ "\theight=\"95\"\n" + "\t>\n" + "\t\t<param name=\"p1\" value=\"1\" />\n"
		+ "Your browser is completely ignoring the &lt;APPLET&gt; tag!\n" + "</applet>"
		+ "</body></html>";
	private static final String XPATH = "//input[@id='id']/@value";

	protected Step createStep() {
		return new AppletRunnerStep();
	}

	public static void testVerifyParametersXpath() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		step.setScenario("foo");
		assertStepRejectsNullParam("xpath", new TestBlock() {
			public void call() throws Exception {
				executeStep(step);
			}
		});
		step.setXpath(XPATH);
		assertEquals("Xpath attribute should be set", XPATH, step.getXpath());
	}

	public static void testVerifyParametersScenarioMissing() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub();

		step.setXpath("foo");
		assertStepRejectsNullParam("scenario", new TestBlock() {
			public void call() throws Exception {
				executeStep(step);
			}
		});
		step.setScenario("foo");
		assertEquals("Scenario attribute should be set", "foo", step.getScenario());
	}

	public void testRejectsNullCurrentResponse() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub(XPATH);
		assertStepRejectsNullResponse(step);
	}

	public void testRejectsNonHtmlResponse() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub(XPATH);
		getContext().setDefaultResponse("<foo></foo>", "text/xml");

		final TestBlock block = new TestBlock() {
			public void call() throws Exception {
				executeStep(step);
			}
		};
		ThrowAssert.assertThrows(StepExecutionException.class, "Current response is not an HTML page", block);
	}

	public void testExceptionIfNoMatch() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub("//input[@id='id']/@value");
		getContext().setDefaultResponse(DOCUMENT);

		ThrowAssert.assertThrows(StepFailedException.class, "The specified element <", new TestBlock() {
			public void call() throws Exception {
				executeStep(step);
			}
		});
	}

	public void testExceptionIfXpathError() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub("//input[@id='id'/@value");
		getContext().setDefaultResponse(DOCUMENT);

		assertThrowOnExecute(step, "", "", XPathException.class);
	}

	public static void testExtractAppletParameter() throws Exception {
		final URL url = new URL("http://localhost:9090/index.html");
		final HtmlPage currentResponse = (HtmlPage) getContextForDocument("<html><body>" 
				+ "<applet id='0'></applet>\n" 
				+ "<applet code='Applet.class' width='600' height='95' id='2'></applet>\n" 
				+ "</body></html>").getCurrentResponse();
		final AppletRunnerStep step = new AppletRunnerStepStub();

		ThrowAssert.assertThrows(StepFailedException.class, "Don't know how to handle element <body>.",
			new TestBlock() {
				public void call() throws Exception {
					step.extractAppletParameter(url,
						(HtmlElement) currentResponse.getFirstByXPath("/html/body"));
				}
			});
		ThrowAssert.assertThrows(StepFailedException.class, "Applet element does not define the code.",
			new TestBlock() {
				public void call() throws Exception {
					step.extractAppletParameter(url,
						(HtmlElement) currentResponse.getFirstByXPath("/html/body/applet[@id='0']"));
				}
			});

		final Object ap = step.extractAppletParameter(url,
			(HtmlElement) currentResponse.getFirstByXPath("/html/body/applet[@id='2']"));

		assertNotNull(ap);
		assertTrue(ap instanceof AppletTag);
	}

	/**
	 * @deprecated to remove when {@link AppletRunnerStep#addParam(Parameter)} is removed
     * @noinspection Deprecation
     */
	public static void testAddParam() {

		final AppletRunnerStep step = new AppletRunnerStepStub();
		final Parameter param = new Parameter("fooo", "foo");
		step.addParam(param);

		assertSame(param, step.getParameters().next());
	}
/*
 * TODO: expansion is made by PropertyHelper: test really needed?
	public void testParameters() {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		configureStep(step);

		final String key1 = "withoutExpansion";
		final String value1 = "value";
		final String key2 = "withExpansion";
		final String value2 = "expandedValue";

		step.addParameter(new Parameter(key1, value1));
		step.addParameter(new Parameter(key2, "#{x}"));
		step.setWebtestProperty("x", value2);

		final Iterator iter = step.getParameters();
		assertTrue(iter.hasNext());
		Parameter param = (Parameter) iter.next();

		assertEquals(key1, param.getName());
		assertEquals(value1, param.getValue());
		param = (Parameter) iter.next();
		assertEquals(key2, param.getName());
		assertEquals(value2, param.getValue());
		assertFalse(iter.hasNext());
	}
*/
	public static void testTarget() {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		assertNull(step.getTarget());
		final String aTarget = "_top";
		step.setTarget(aTarget);
		assertSame(aTarget, step.getTarget());
	}

	public void testFollowTargetNoTargetNoShow() throws Exception {
		final AppletPluginResults results = new AppletPluginResults();
		final AppletRunnerStep step = new AppletRunnerStepStub();
		assertNull(step.findTargetWithResults(results, getContext()));
	}

	public void testFollowTargetTargetNoShow() throws Exception {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		step.setTarget("_blank");
		ThrowAssert.assertThrows(StepFailedException.class, new TestBlock() {
			public void call() throws Exception {
				final AppletPluginResults results = new AppletPluginResults();
				step.findTargetWithResults(results, getContext());
			}
		});
	}

	public void testFollowTargetTargetShowWrong() throws Exception {
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setFrame("_blank", new URL("http://webtest.canoo.com/"));
		final AppletRunnerStep step = new AppletRunnerStepStub();
		step.setTarget("_top");
		ThrowAssert.assertThrows(StepFailedException.class, new TestBlock() {
			public void call() throws Exception {
				step.findTargetWithResults(apr, getContext());
			}
		});
	}

	public void testFollowTargetTargetShow() throws Exception {
		final ContextStub context = new ContextStub()
		{
			protected void initConfig(final Project project) {
				final Configuration myConfig = new Configuration();
				myConfig.setShowhtmlparseroutput(false);
				getWebtest().addConfig(myConfig);
			}
		};
		final IPropertyHandler handler = (IPropertyHandler) mock(IPropertyHandler.class, "handler");
		context.getConfig().setPropertyHandler(handler);
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setFrame("_blank", new URL("http://webtest.canoo.com/"));
		final AppletRunnerStepStub step = new AppletRunnerStepStub();
		step.setTarget("_blank");
		step.findTargetWithResults(apr, context);
		assertEquals("http://webtest.canoo.com/", step.getUrl());
	}

	public void testFollowTargetNoTargetShow() throws Exception {
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setFrame("_blank", new URL("http://webtest.canoo.com/"));
		final AppletRunnerStep step = new AppletRunnerStepStub();
		assertNull(step.findTargetWithResults(apr, getContext()));
	}

	public static void testVerifyAppletResultNoError() throws Exception {
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setReturnValue(AppletRunnerStep.ZERO);
		final AppletRunnerStep step = new AppletRunnerStepStub();
		step.verifyAppletResult(apr);
	}

	public static void testVerifyAppletResultException() throws Exception {
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setReturnValue(AppletRunnerStep.ZERO);
		apr.setException(new ArrayIndexOutOfBoundsException());
		final AppletRunnerStep step = new AppletRunnerStepStub();
		ThrowAssert.assertThrows(StepFailedException.class, new TestBlock() {
			public void call() throws Exception {
				step.verifyAppletResult(apr);
			}
		});
	}

	public static void testVerifyAppletResultJemmyException() throws Exception {
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setReturnValue(AppletRunnerStep.ZERO);
		apr.setJemmyException(new JemmyException("dummy"));
		final AppletRunnerStep step = new AppletRunnerStepStub();
		ThrowAssert.assertThrows(StepFailedException.class, new TestBlock() {
			public void call() throws Exception {
				step.verifyAppletResult(apr);
			}
		});
	}

	public static void testVerifyAppletResultErrorCode() throws Exception {
		final AppletPluginResults apr = new AppletPluginResults();
		apr.setReturnValue(new Integer(42));
		final AppletRunnerStep step = new AppletRunnerStepStub();
		ThrowAssert.assertThrows(StepFailedException.class, new TestBlock() {
			public void call() throws Exception {
				step.verifyAppletResult(apr);
			}
		});
	}

	public static void testSetupLog4jOverrides() throws Exception {
		final String saveInitOverride = System.getProperty(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES);
		System.setProperty(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES, "true");

		final CommandlineJava cmd = new CommandlineJava();
		assertEquals(0, cmd.getSystemProperties().size());
		AppletRunnerStep.setupLog4j(cmd);

		assertEquals(1, cmd.getSystemProperties().size());
		assertEquals("-D" + AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES + "=true", cmd.getSystemProperties().getVariables()[0]);

		restoreSystemPropertyState(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES, saveInitOverride);
	}

	public static void testSetupLog4jPlain() throws Exception {
		final String saveInitOverride = System.getProperty(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES);
		System.setProperty(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES, "false");
		final String saveConfig = System.getProperty(AppletRunnerStep.LOG4J_CONFIGURATION);
		System.getProperties().remove(AppletRunnerStep.LOG4J_CONFIGURATION);

		final CommandlineJava cmd = new CommandlineJava();
		assertEquals(0, cmd.getSystemProperties().size());
		AppletRunnerStep.setupLog4j(cmd);

		final String[] variables = cmd.getSystemProperties().getVariables();
		assertEquals(2, variables.length);
		assertTrue(variables[0].startsWith("-D" + AppletRunnerStep.LOG4J_CONFIGURATION));
		assertTrue(variables[0].endsWith("log4j.properties"));
		assertEquals("-D" + AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES + "=false", variables[1]);

		restoreSystemPropertyState(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES, saveInitOverride);
		restoreSystemPropertyState(AppletRunnerStep.LOG4J_CONFIGURATION, saveConfig);
	}

	public static void testSetupLog4jOwnConfig() throws Exception {
		final String saveInitOverride = System.getProperty(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES);
		System.setProperty(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES, "false");
		final String saveConfig = System.getProperty(AppletRunnerStep.LOG4J_CONFIGURATION);
		System.setProperty(AppletRunnerStep.LOG4J_CONFIGURATION, "This resource doesn't exist");

		final CommandlineJava cmd = new CommandlineJava();
		assertEquals(0, cmd.getSystemProperties().size());
		AppletRunnerStep.setupLog4j(cmd);

		final String[] variables = cmd.getSystemProperties().getVariables();
		assertEquals(1, variables.length);
		assertEquals("-D" + AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES + "=true", variables[0]);

		restoreSystemPropertyState(AppletRunnerStep.LOG4J_DEFAULT_INIT_OVERRIDES, saveInitOverride);
		restoreSystemPropertyState(AppletRunnerStep.LOG4J_CONFIGURATION, saveConfig);
	}

	public static void testGetProtocolHandler() throws Exception {
		final String saveHandlers = System.getProperty(AppletRunnerStep.PROTOCOL_HANDLER_LIST);

		System.setProperty(AppletRunnerStep.PROTOCOL_HANDLER_LIST, "");
		assertVariable(AppletRunnerStep.RUNNER_PACKAGE);

		final String pseudoHandlers = "dummy.handler.package";
		System.setProperty(AppletRunnerStep.PROTOCOL_HANDLER_LIST, pseudoHandlers);
		assertVariable(AppletRunnerStep.RUNNER_PACKAGE + "|" + pseudoHandlers);

        System.getProperties().remove(AppletRunnerStep.PROTOCOL_HANDLER_LIST);
        assertVariable(AppletRunnerStep.RUNNER_PACKAGE);

        restoreSystemPropertyState(AppletRunnerStep.PROTOCOL_HANDLER_LIST, saveHandlers);
	}

	private static void restoreSystemPropertyState(final String key, final String value) {
		if (value == null) {
			System.getProperties().remove(key);
		} else {
			System.setProperty(key, value);
		}
	}

	private static void assertVariable(final String value) {
		final Environment.Variable env = AppletRunnerStep.getProtocolHandler();
		assertEquals(AppletRunnerStep.PROTOCOL_HANDLER_LIST, env.getKey());
		assertEquals(value, env.getValue());
	}

	public void testGetUrlForClass() throws MalformedURLException {
		assertNull(AppletRunnerStep.getUrlForClass("com.canoo.webtest.extension.applet.ThisClassDoesNotExist"));
		assertNotNull(AppletRunnerStep.getUrlForClass(getClass().getName()));
	}

	public static void testExtractClasspathEntryFromURL() {
		assertEquals("/user/home/java/lib/", AppletRunnerStep.extractClasspathEntry("/user/home/java/lib/com/foo/Bar.class", "com/foo/Bar.class"));
		assertEquals("/user/home/java/lib.jar", AppletRunnerStep.extractClasspathEntry("/user/home/java/lib.jar!/com/foo/Bar.class", "com/foo/Bar.class"));
	}

	public static void testAppendOptionalToClasspathFail() {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		final Path classpath = new Path(step.getProject());
		assertEquals(0, classpath.list().length);
		assertFalse(step.appendOptionalToClasspath("com.canoo.webtest.extension.applet.ThisClassDoesNotExist", classpath));
		assertEquals(0, classpath.list().length);
	}

	public void testAppendOptionalToClasspathOk() {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		final Path classpath = new Path(step.getProject());
		assertEquals(0, classpath.list().length);
		assertTrue(step.appendOptionalToClasspath(getClass().getName(), classpath));
		assertEquals(1, classpath.list().length);
	}

	public static void testAppendToClasspathFail() {
		final AppletRunnerStep step = new AppletRunnerStepStub() {
			boolean appendOptionalToClasspath(final String aClassName, final Path classpath) {
				return !AppletRunnerStep.class.getName().equals(aClassName);
			}
		};
		final Path classpath = new Path(step.getProject());

		assertEquals(0, classpath.list().length);
		ThrowAssert.assertThrows(StepFailedException.class, new TestBlock() {
			public void call() throws Exception {
				step.appendToClasspath(AppletRunnerStep.class, classpath);
			}
		});
		assertEquals(0, classpath.list().length);
	}

	public void testAppendToClasspathOk() {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		final Path classpath = new Path(step.getProject());

		assertEquals(0, classpath.list().length);
		step.appendToClasspath(getClass(), classpath);
		assertEquals(1, classpath.list().length);
	}

	public static void testMapPathToURL() {
		final AppletRunnerStep step = new AppletRunnerStepStub();
		assertEquals(0, step.convertPathToURL(null).length);
		assertEquals(0, step.convertPathToURL(new Path(step.getProject())).length);
	}

	public void testCreateAppletPluginArguments() {
		final AppletRunnerStep step = new AppletRunnerStepStub();

		final String testName = "testName";

		getContext().getWebtest().setName(testName);

		AppletPluginArguments appletPluginArguments = step.createAppletPluginArguments();
		assertEquals(testName, appletPluginArguments.getBaseWindowName());

		final String description = "desc";
		step.setDescription(description);
		appletPluginArguments = step.createAppletPluginArguments();
		assertEquals(testName + " - " + description, appletPluginArguments.getBaseWindowName());

	}
}
