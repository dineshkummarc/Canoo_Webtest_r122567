package com.canoo.webtest.extension.applet.runner;

import com.canoo.webtest.extension.applet.AbstractAppletTag;

import javax.swing.JApplet;

/**
 * @author Denis N. Antonioli
 */
public class SwingStubTest extends AbstractAppletStubTestCase {

	AbstractAppletStub createAppletStubInstance(JApplet applet, AbstractAppletTag appletTag) {
		return new SwingStub(null, applet,appletTag, "Unnamed");
	}
}
