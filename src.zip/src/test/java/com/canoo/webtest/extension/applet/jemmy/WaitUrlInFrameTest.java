package com.canoo.webtest.extension.applet.jemmy;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class WaitUrlInFrameTest extends WaitFrameTest {
	ContextOperator.WaitFrame createFrameWaiter() throws MalformedURLException {
		return new ContextOperator.WaitUrlInFrame(new URL(DOCUMENT_URL), WAITED_FRAME_NAME);
	}

	public void testActionProduced() throws MalformedURLException {
		super.testActionProduced();

		getContext().showDocument(new URL(DOCUMENT_URL+"index.html"), WAITED_FRAME_NAME);
		assertNull(getWaiter().actionProduced(getContext()));
	}
}
