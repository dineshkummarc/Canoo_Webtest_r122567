package com.canoo.webtest.extension.applet.runner;

/**
 * @author Denis N. Antonioli
 */

import com.canoo.webtest.extension.applet.AbstractAppletTag;
import com.canoo.webtest.extension.applet.AppletPluginArguments;
import com.canoo.webtest.extension.applet.AppletPluginResults;
import com.canoo.webtest.extension.applet.AppletTag;
import junit.framework.TestCase;

import java.applet.Applet;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;

public class ContextTest extends TestCase {
	private Context fContext;

	private AbstractAppletStub fAppletStub;
	private AppletPluginResults fAppletPluginResults;

	public void setUp() throws MalformedURLException, IllegalAccessException, InstantiationException, ClassNotFoundException {
		final AppletTag appletTag = new AppletTag("http://localhost:9090/");
		appletTag.addParameter(AbstractAppletTag.ATTR_NAME, "nom");

		final AppletPluginArguments apa = new AppletPluginArguments();
		apa.setBaseWindowName("Unnamed");

		fAppletPluginResults = new AppletPluginResults();
		fContext = new Context(fAppletPluginResults);
		fAppletStub = fContext.newStub(new Applet(), appletTag, apa);
	}

	public void testGetApplet() {
		assertNull(fContext.getApplet(null));
		assertNull(fContext.getApplet("Name"));
		assertEquals(fAppletStub.getApplet(), fContext.getApplet("nom"));
	}

	public void testGetApplets() {
		Enumeration en = fContext.getApplets();
		assertTrue(en.hasMoreElements());
		assertEquals(fAppletStub, en.nextElement());
		assertFalse(en.hasMoreElements());
	}

	public void testShowDocument() throws MalformedURLException {
		final URL aURL = new URL("http://webtest.canoo.com/");
		final String fFrameName = "_top";

		assertTrue(fAppletPluginResults.getFrames().isEmpty());
		fContext.showDocument(aURL);
		assertTrue(fAppletPluginResults.getFrames().containsKey(fFrameName));
		assertEquals(aURL.toExternalForm(), ((URL) fAppletPluginResults.getFrames().get(fFrameName)).toExternalForm());
	}

	public void testShowDocumentInFrame() throws MalformedURLException {
		final URL aURL = new URL("http://webtest.canoo.com/");
		final String fFrameName = "cadre";

		assertTrue(fAppletPluginResults.getFrames().isEmpty());
		fContext.showDocument(aURL, fFrameName);
		assertTrue(fAppletPluginResults.getFrames().containsKey(fFrameName));
		assertEquals(aURL.toExternalForm(), ((URL) fAppletPluginResults.getFrames().get(fFrameName)).toExternalForm());
	}

	public void testGetAppletPluginResults() throws Exception {
		assertEquals(fAppletPluginResults, fContext.getAppletPluginResults());
	}

	public void testStream() throws IOException {
		final byte[] buf = new byte[0];
		final ByteArrayInputStream inputStream1 = new ByteArrayInputStream(buf);
		final ByteArrayInputStream inputStream2 = new ByteArrayInputStream(buf);

		assertFalse(fContext.getStreamKeys().hasNext());

		// adds a stream
		fContext.setStream("key1", inputStream1);
		assertEquals(inputStream1, fContext.getStream("key1"));

		// replaces the streams
		fContext.setStream("key1", inputStream2);
		assertEquals(inputStream2, fContext.getStream("key1"));

		Iterator keys = fContext.getStreamKeys();
		assertTrue(keys.hasNext());
		assertEquals("key1", (String) keys.next());
		assertFalse(keys.hasNext());

		// removes the stream
		fContext.setStream("key1", null);
		assertNull(fContext.getStream("key1"));

		assertFalse(fContext.getStreamKeys().hasNext());
	}

	public void testGetAudioClip() throws MalformedURLException {
		final URL aURL = new URL("http://webtest.canoo.com/");
		assertNotNull(fContext.getAudioClip(aURL));
	}
}
