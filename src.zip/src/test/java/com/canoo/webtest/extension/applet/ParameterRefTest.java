package com.canoo.webtest.extension.applet;

import junit.framework.TestCase;

/**
 * @author Denis N. Antonioli
 */
public class ParameterRefTest extends TestCase {
	private ParameterRef fParameterRef;

	protected void setUp() throws Exception {
		fParameterRef = new ParameterRef();
		assertNull(fParameterRef.getName());
		assertNull(fParameterRef.getRegex());
		assertNull(fParameterRef.getPropertyType());
	}

	public void testName() throws Exception {
		fParameterRef.setName("nom");
		assertEquals("nom", fParameterRef.getName());
		assertNull(fParameterRef.getRegex());
		assertNull(fParameterRef.getPropertyType());
	}

	public void testRegex() throws Exception {
		fParameterRef.setRegex("expression");
		assertEquals("expression", fParameterRef.getRegex());
		assertNull(fParameterRef.getName());
		assertNull(fParameterRef.getPropertyType());
	}

	public void testPropertyType() throws Exception {
		fParameterRef.setPropertyType("type");
		assertEquals("type", fParameterRef.getPropertyType());
		assertNull(fParameterRef.getName());
		assertNull(fParameterRef.getRegex());
	}

	public void testFullConstructor() {
		fParameterRef = new ParameterRef("nom", "expression", "type");
		assertEquals("nom", fParameterRef.getName());
		assertEquals("expression", fParameterRef.getRegex());
		assertEquals("type", fParameterRef.getPropertyType());
	}
}
