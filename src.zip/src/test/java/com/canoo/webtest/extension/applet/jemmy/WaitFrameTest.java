package com.canoo.webtest.extension.applet.jemmy;

import com.canoo.webtest.extension.applet.AppletPluginResults;
import com.canoo.webtest.extension.applet.runner.Context;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import junit.framework.TestCase;
import org.netbeans.jemmy.Waitable;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Denis N. Antonioli
 */
public class WaitFrameTest extends TestCase {
	static final String DOCUMENT_URL = "http://webtest.canoo.com/";
	static final String WAITED_FRAME_NAME = "cadre";

	private ContextOperator.WaitFrame fWaiter;
	private Context fContext;

	protected void setUp() throws Exception {
		fContext = new Context(new AppletPluginResults());
		fWaiter = createFrameWaiter();
	}

	ContextOperator.WaitFrame createFrameWaiter() throws MalformedURLException {
		return new ContextOperator.WaitFrame(WAITED_FRAME_NAME);
	}

	public void testGetDescription() {
		assertTrue(-1 < fWaiter.getDescription().indexOf(WAITED_FRAME_NAME));
	}

	public void testGetTarget() {
		assertEquals(WAITED_FRAME_NAME, fWaiter.getTarget());
	}

	public void testActionProduced() throws MalformedURLException {
		ThrowAssert.assertThrows(NullPointerException.class, new TestBlock() {
			public void call() throws Exception {
				fWaiter.actionProduced(null);
			}
		});

		assertNull(fWaiter.actionProduced(fContext));

		URL documentURL = new URL(DOCUMENT_URL);
		fContext.showDocument(documentURL, WAITED_FRAME_NAME+"_");
		assertNull(fWaiter.actionProduced(fContext));

		fContext.showDocument(documentURL, WAITED_FRAME_NAME );
		assertEquals(documentURL,  fWaiter.actionProduced(fContext));
	}

	public Context getContext() {
		return fContext;
	}

	public Waitable getWaiter() {
		return fWaiter;
	}
}
