package com.canoo.webtest.extension.applet.runner;

/**
 * @author Denis N. Antonioli
 */

import com.canoo.webtest.extension.applet.AbstractAppletTag;
import com.canoo.webtest.extension.applet.AppletTag;
import junit.framework.TestCase;

import javax.swing.JApplet;
import java.awt.Dimension;
import java.net.MalformedURLException;
import java.net.URL;
/**
 * Tests common to all AppletStub. This class is not to be extecuted directly, it is to be used as
 * an ancestor for tests of the concrete AppletStub.
 */
public abstract class AbstractAppletStubTestCase extends TestCase {
	private AbstractAppletStub fAbstractAppletStub;
	private AppletTag fAppletTag;
	private JApplet fApplet;

	static final class MockApplet extends JApplet {
		static final int LIFECYCLE_INIT = 1;
		static final int LIFECYCLE_START = LIFECYCLE_INIT << 1;
		static final int LIFECYCLE_STOP = LIFECYCLE_START << 1;
		static final int LIFECYCLE_DESTROY = LIFECYCLE_STOP << 1;
		private int fCalled; // still visible to outer class

		public void init() {
			fCalled |= LIFECYCLE_INIT;
		}

		public void start() {
			fCalled |= LIFECYCLE_START;
		}

		public void stop() {
			fCalled |= LIFECYCLE_STOP;
		}

		public void destroy() {
			fCalled |= LIFECYCLE_DESTROY;
		}
	}

	static final class MockAppletTag extends AppletTag {
		private String fLastMethod; // still visible to outer class

		MockAppletTag(String base) throws MalformedURLException {
			super(base);
		}

		public URL getBase() {
			fLastMethod = "getBase";
			return super.getBase();
		}

		public URL getCodebase() {
			fLastMethod = "getCodebase";
			return super.getCodebase();
		}

		public String getParameter(String name) {
			fLastMethod = "getParameter";
			return super.getParameter(name);
		}
	}

	abstract AbstractAppletStub createAppletStubInstance(JApplet applet, AbstractAppletTag appletTag);

	public void setUp() throws MalformedURLException {
		fAppletTag = new MockAppletTag("http://localhost:9090/");
		fAppletTag.addParameter(AbstractAppletTag.ATTR_NAME, "nom");
		fApplet = new MockApplet();
		fAbstractAppletStub = createAppletStubInstance(fApplet,  fAppletTag);
	}

	public void testIsActive() {
		assertFalse(fAbstractAppletStub.isActive());
		fAbstractAppletStub.start();
		assertTrue(fAbstractAppletStub.isActive());
		fAbstractAppletStub.stop();
		assertFalse(fAbstractAppletStub.isActive());
	}

	public void testGetDocumentBase() {
		fAbstractAppletStub.getDocumentBase();
		assertEquals("getBase", ((MockAppletTag) fAppletTag).fLastMethod);
	}

	public void testGetCodeBase() {
		fAbstractAppletStub.getCodeBase();
		assertEquals("getCodebase", ((MockAppletTag) fAppletTag).fLastMethod);
	}
	public void testGetParameter() throws MalformedURLException {
		fAbstractAppletStub.getParameter("key1");
		assertEquals("getParameter", ((MockAppletTag) fAppletTag).fLastMethod);
	}
	public void testInit() {
		fAbstractAppletStub.init();
		assertEquals(MockApplet.LIFECYCLE_INIT, ((MockApplet) fApplet).fCalled);
	}

	public void testStart() {
		fAbstractAppletStub.start();
		assertEquals(MockApplet.LIFECYCLE_START, ((MockApplet) fApplet).fCalled);
	}

	public void testStop() {
		fAbstractAppletStub.stop();
		assertEquals(MockApplet.LIFECYCLE_STOP, ((MockApplet) fApplet).fCalled);
	}

	public void testDestroy() {
		fAbstractAppletStub.destroy();
		assertEquals(MockApplet.LIFECYCLE_DESTROY, ((MockApplet) fApplet).fCalled);
	}

	public void testGetAppletDimension() {
        setAppletDimension("10", "20");
        assertAppletDimension(10, 20);

        setAppletDimension("30%", "40");
        assertAppletDimension(30, 40);

        setAppletDimension("50", "60%");
        assertAppletDimension(50, 60);

        setAppletDimension("70%", "80%");
        assertAppletDimension(70, 80);
	}

    private void setAppletDimension(String width, String height) {
        fAppletTag.addParameterLength(AbstractAppletTag.ATTR_WIDTH, width);
        fAppletTag.addParameterLength(AbstractAppletTag.ATTR_HEIGHT, height);
    }

    private void assertAppletDimension(int width, int height) {
        Dimension dim = fAbstractAppletStub.getAppletDimension();
        assertEquals(width, dim.width);
        assertEquals(height, dim.height);
    }

    public void testResize(){
		assertEquals(0, fAbstractAppletStub.getRootFrame().getWidth());
		assertEquals(0, fAbstractAppletStub.getRootFrame().getHeight());
		fAbstractAppletStub.appletResize(10, 20);
		assertEquals(10, fAbstractAppletStub.getRootFrame().getWidth());
		assertEquals(20, fAbstractAppletStub.getRootFrame().getHeight());
	}
}
