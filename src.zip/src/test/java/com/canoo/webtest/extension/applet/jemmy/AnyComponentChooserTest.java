// Copyright (c) 2002-2005 Canoo Engineering AG, Switzerland. All Rights Reserved.
package com.canoo.webtest.extension.applet.jemmy;

import junit.framework.TestCase;

public class AnyComponentChooserTest extends TestCase {
	public void testCheckComponent() throws Exception {
		// Must always be true
		// Also for null???
		assertTrue(AnyComponentChooser.ANY_COMPONENT_CHOOSER.checkComponent(null));
	}

	public void testGetDescription() throws Exception {
		// don't care how the description looks like, as long as there is one
		assertNotNull(AnyComponentChooser.ANY_COMPONENT_CHOOSER.getDescription());
	}
}