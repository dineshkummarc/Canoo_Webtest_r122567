package com.canoo.webtest.extension.applet;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.parsers.ParserConfigurationException;

import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import com.canoo.webtest.steps.BaseStepTestCase;
import com.gargoylesoftware.htmlunit.Page;

/**
 * @author Denis N. Antonioli
 */
public class ObjectTagTest extends AbstractAppletTagTestCase {

	protected AbstractAppletTag createAppletTagInstance(String url) throws MalformedURLException {
		return new ObjectTag(url);
	}

	public void testNewInstance() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<object id='1' width='1' height='2'></object>" +
		   "<object id='2' width='1' height='2' ><param name='type' value='img/gif' /></object>" +
		   "<object id='3' height='2' ><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='4' width='1' ><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='5' width='1' height='2' ><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='6' width='1' height='2' ><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='7' width='1%' height='2%' ><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "</body></html>").getCurrentResponse();

		ThrowAssert.assertThrows("Object element does not define the required parameter 'type'.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "1");
			   }
		   });
		ThrowAssert.assertThrows("The parameter 'type' must start with 'application/x-java-applet;'.",
		   IllegalArgumentException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "2");
			   }
		   });
		ThrowAssert.assertThrows("Object element does not define the width.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "3");
			   }
		   });
		ThrowAssert.assertThrows("Object element does not define the height.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "4");
			   }
		   });
		ThrowAssert.assertThrows("Object element does not define the required parameter 'code'.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "5");
			   }
		   });
		AbstractAppletTag ap;
		ap = newInstance(currentResponse, "6");
		assertEquals("foo", ap.getCode());
		assertEquals("1", ap.getWidth());
		assertEquals("2", ap.getHeight());
		ap = newInstance(currentResponse, "7");
		assertEquals("foo", ap.getCode());
		assertEquals("1%", ap.getWidth());
		assertEquals("2%", ap.getHeight());
	}

	public void testNewInstanceOptionalAttribute() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<object id='1' width='1' height='2' ><param name='archive' value='arc' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='2' width='1' height='2' ><param name='name' value='nom' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='3' width='1' height='2' name='nom'><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='4' width='1' height='2' ><param name='codebase' value='http://localhost:9090/foo' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='5' width='1' height='2' ><param name='codebase' value='bar' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='6' width='1' height='2' ><param name='object' value='objet' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "</body></html>").getCurrentResponse();
		AbstractAppletTag ap;
		ap = newInstance(currentResponse, "1");
		assertEquals(1, ap.getArchive().size());
		assertEquals("arc", ap.getArchive().get(0));
		ap = newInstance(currentResponse, "2");
		assertEquals("nom", ap.getName());
		ap = newInstance(currentResponse, "3");
		assertEquals("nom", ap.getName());
		ap = newInstance(currentResponse, "4");
		assertEquals("http://localhost:9090/foo/", ap.getCodebase().toExternalForm());
		ap = newInstance(currentResponse, "5");
		assertEquals("http://localhost:9090/bar/", ap.getCodebase().toExternalForm());
		ThrowAssert.assertThrows("Attribute object is not supported.",
		   NoSuchFieldException.class,
		   new TestBlock() {
			   public void call() throws Exception {
				   newInstance(currentResponse, "6");
			   }
		   });
	}

	public void testNewInstanceParameters() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<object id='1' width='1' height='2' ><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='2' width='1' height='2' ><param /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='3' width='1' height='2' ><param name='p1' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='4' width='1' height='2' ><param name='p1' value='v1' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='5' width='1' height='2' ><param name='p1' value='v1' /><param name='p2' value='v2' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='6' width='1' height='2' ><param name='p1' value='v1' /><param name='p1' value='v2' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='7' width='1' height='2' ><param name='p1' value='&amp;' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "</body></html>").getCurrentResponse();
        checkNewInstanceParameters(currentResponse);
    }

	public void testNewInstanceParameterOverwriteAttribute() throws Exception {
		final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
		   "<object id='1' width='1' height='2' ><param name='width' value='100' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "<object id='2' width='1' height='2' codebase='http://localhost:9090/bar' ><param name='codebase' value='http://localhost:9090/foo' /><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
		   "</body></html>").getCurrentResponse();
        checkNewInstanceParameterOverwriteAttribute(currentResponse);
    }

    public void testGetParameterAccessAttribute() throws IOException, ParserConfigurationException, NoSuchFieldException {
        final Page currentResponse = BaseStepTestCase.getContextForDocument("<html><body>" +
           "<object id='1' width='1' height='2'><param name='code' value='foo' /><param name='type' value='application/x-java-applet;' /></object>" +
           "</body></html>").getCurrentResponse();
        AbstractAppletTag ap;
        ap = newInstance(currentResponse, "1");
        assertEquals("foo", ap.getParameter("code"));
        assertEquals("1", ap.getParameter("width"));
        assertEquals("2", ap.getParameter("height"));
    }
}
