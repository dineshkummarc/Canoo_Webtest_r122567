package com.canoo.webtest.engine;

/**
 * @author Denis N. Antonioli
 */
public class OptionTest extends NameValuePairTest {
    NameValuePair getNameValuePair() {
        return new Option();
    }
}