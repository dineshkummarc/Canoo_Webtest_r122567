// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.engine;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.auth.BasicScheme;
import org.apache.commons.httpclient.auth.CredentialsNotAvailableException;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.SSLProtocolSocketFactory;
import org.apache.commons.lang.StringUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.RuntimeConfigurable;
import org.apache.tools.ant.taskdefs.Echo;

import com.canoo.webtest.ant.WebtestTask;
import com.canoo.webtest.self.TestBlock;
import com.canoo.webtest.self.ThrowAssert;
import com.canoo.webtest.steps.Step;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.DefaultCredentialsProvider;
import com.gargoylesoftware.htmlunit.ProxyConfig;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.ssl.InsecureSSLProtocolSocketFactory;

/**
 * Tests for {@link Configuration}.
 *
 * @author unknown
 * @author Marc Guillemot
 * @author Paul King
 */
public class ConfigurationTest extends TestCase
{
	static final String[] PROPERTIES_BOOL = {"autorefresh", "haltonerror", "haltonfailure", 
    		"saveresponse", "showhtmlparseroutput", "summary"};
	static final String[] PROPERTIES_STRING = {"basepath",  
    		"errorproperty", "failureproperty",  "host", "resultpath", "saveprefix"};
	static final String[] PROPERTIES_INT = {"timeout", "port"};

    public void testCtorBasePath() {
        String host = "somehost";
        int port = 10;
        String basePath = "somepath";

        Configuration simpleConfig = new Configuration();

        simpleConfig.setHost(host);
        simpleConfig.setPort(port);
        simpleConfig.setBasepath(basePath);

        assertEquals("host", host, simpleConfig.getHost());
        assertEquals("port", port, simpleConfig.getPort());
        assertEquals("protocol", Configuration.PROTOCOL_HTTP, simpleConfig.getProtocol());
        assertEquals("base path", basePath, simpleConfig.getBasePath());
    }

    public void testCtorDefaultPage() {
        // String defaultProtocol = "http";
        String host = "xxx";
        int port = 10;
        String basePath = "frontnet";
        // String baseUrl = defaultProtocol + "://" + host + ":" + port;
        // String defaultPage = "start.html";
        // String defaultPageUrl = baseUrl + "/" + basePath + "/" + defaultPage;

        Configuration conf = new Configuration();

        conf.setHost(host);
        conf.setPort(port);
        conf.setBasepath(basePath);

        assertEquals("base path", basePath, conf.getBasePath());
    }

    public void testStandard() {
        Configuration standard = new Configuration();

        assertEquals("port", Configuration.PORT_HTTP, standard.getPort());
        assertEquals("protocol", Configuration.PROTOCOL_HTTP, standard.getProtocol());
        assertEquals("host", Configuration.DEFAULT_HOST, standard.getHost());
        assertFalse("saveResp", standard.isSaveResponse());
        assertFalse("summary", standard.isSummary());

        assertNotNull("urlForPage", standard.getUrlForPage(null));

        assertNull("basePath", standard.getBasePath());
        assertNull("errorProperty", standard.getErrorProperty());
        assertNull("failureProperty", standard.getFailureProperty());
    }

    public void testErrorAndFailureProperties() {
        Configuration propConf = new Configuration();

        propConf.setErrorProperty("errorProp");
        propConf.setFailureProperty("failureProp");
        assertNotNull("errorProperty", propConf.getErrorProperty());
        assertNotNull("failureProperty", propConf.getFailureProperty());
    }

    public void testDefaultPropertyType() {
        Configuration propConf = new Configuration();

        propConf.setDefaultPropertyType(Step.PROPERTY_TYPE_ANT);
        assertEquals(Step.PROPERTY_TYPE_ANT, propConf.getDefaultPropertyType());
    }

    public void testGetUrlForPage() {
        Configuration config = new Configuration();

        config.setHost("myHost");
        config.setBasepath("/myApplication");

        assertEquals("http://myHost/myApplication", config.getUrlForPage(""));

        config.setProtocol("https");
        config.setPort(443);
        assertEquals("https://myHost/myApplication", config.getUrlForPage(""));

        assertEquals("https://myHost/myApplication", config.getUrlForPage("https://myHost/myApplication"));
        assertEquals("http://myHost/myPage", config.getUrlForPage("http://myHost/myPage"));
        assertEquals("file://myFile", config.getUrlForPage("file://myFile"));
    }

    public void testUrlFromHostPort() {
        Configuration hostPortConfig = new Configuration();

        hostPortConfig.setHost("somehost");
        hostPortConfig.setPort(8080);

        String expectedUrl = "http://somehost:8080/somepage.html";

        assertEquals("urlForPage", expectedUrl, hostPortConfig.getUrlForPage("somepage.html"));
        assertEquals("urlForPage", expectedUrl, hostPortConfig.getUrlForPage("/somepage.html"));
    }

    public void testUrlFromHostWitheEfaultPort() {
        Configuration hostPortConfig = new Configuration();

        hostPortConfig.setHost("somehost");
        assertEquals("urlForPage", "http://somehost/somepage.html",
                hostPortConfig.getUrlForPage("somepage.html"));

        hostPortConfig.setProtocol("https");
        hostPortConfig.setPort(443);
        assertEquals("urlForPage", "https://somehost/somepage.html",
                hostPortConfig.getUrlForPage("somepage.html"));
    }

    public void testUrlFromHostPortBasePath() {
        Configuration basePathConfig = new Configuration();

        basePathConfig.setHost("somehost");
        basePathConfig.setPort(8080);
        basePathConfig.setBasepath("somepath");

        String expectedUrl = "http://somehost:8080/somepath/somepage.html";

        assertEquals(expectedUrl, basePathConfig.getUrlForPage("somepage.html"));
        assertEquals(expectedUrl, basePathConfig.getUrlForPage("/somepage.html"));

        basePathConfig.setBasepath("/somepath");
        assertEquals(expectedUrl, basePathConfig.getUrlForPage("somepage.html"));
        assertEquals(expectedUrl, basePathConfig.getUrlForPage("/somepage.html"));

        basePathConfig.setBasepath("/somepath/");
        assertEquals(expectedUrl, basePathConfig.getUrlForPage("somepage.html"));
        assertEquals(expectedUrl, basePathConfig.getUrlForPage("/somepage.html"));
    }

    public void testUrlFromFileDosPageWithBasepath() {
        Configuration fileConfig = new Configuration();

        fileConfig.setProtocol("file");
        fileConfig.setBasepath("C:/temp");
        assertEquals("page", "file:/C:/temp/XX.xx", fileConfig.getUrlForPage("XX.xx"));
    }

    public void testUrlFromFileUnixPageWithBasepath() {
        Configuration fileConfig = new Configuration();

        fileConfig.setProtocol("file");
        fileConfig.setBasepath("/temp");
        assertEquals("", "file:/temp/XX.xx", fileConfig.getUrlForPage("XX.xx"));
    }

    public void testUrlFromFileDosPageAbsolute() {
        Configuration fileConfig = new Configuration();

        fileConfig.setProtocol("file");
        fileConfig.setBasepath("/");
        assertEquals("", "file:/c:/temp/XX.xx", fileConfig.getUrlForPage("c:/temp/XX.xx"));
    }

    public void testUrlFromFileDosPageAbsoluteNoBasePath() {
        Configuration fileConfig = new Configuration();

        fileConfig.setProtocol("file");
        assertEquals("", "file:/c:/temp/XX.xx", fileConfig.getUrlForPage("c:/temp/XX.xx"));
    }

    public void testUrlFromFileDosPageRelative() {
        Configuration fileConfig = new Configuration();

        fileConfig.setProtocol("file");
        fileConfig.setBasepath("c:/temp");
        assertEquals("", "file:/c:/temp/XX.xx", fileConfig.getUrlForPage("XX.xx"));
    }

    public void testUrlFromFileUnixPageRelative() {
        Configuration fileConfig = new Configuration();

        fileConfig.setProtocol("file");
        fileConfig.setBasepath("/");
        assertEquals("", "file:/temp/XX.xx", fileConfig.getUrlForPage("temp/XX.xx"));
    }

    public void testNoPropertyHandler() {
        ThrowAssert.assertThrows(IllegalStateException.class, new TestBlock()
        {
            public void call() throws Exception {
                Configuration fileConfig = new Configuration();

                fileConfig.setPropertyHandler(null);
                fileConfig.getExternalProperty("some property");
            }
        });
    }

    public void testResultDirNotDirectoryThrowsBuildException() {
        final Configuration config = new Configuration();
        config.setSummary(true);
        final File nonDirFile = new File("dummy")
        {
            public boolean exists() {
                return true;
            }
            public boolean isDirectory() {
                return false;
            }
        };
        ThrowAssert.assertThrows(BuildException.class, "Result dir is not a directory", new TestBlock()
        {
            public void call() throws Throwable {
                config.prepareResultDir(nonDirFile);
            }
        });
    }

    public void testCantCreateResultDirThrowsBuildException() {
        final File cantCreateDir = new File("dummy")
        {
            public boolean exists() {
                return false;
            }
            public boolean mkdirs() {
                return false;
            }
        };
        final Configuration config = new Configuration()
        {
        	protected File computeSubFolder(File _resultDir)
        	{
        		return cantCreateDir;
        	}
        };
        config.setSummary(true);
        ThrowAssert.assertThrows(BuildException.class, "Failed to create result dir", new TestBlock() {
            public void call() throws Throwable {
                config.prepareResultDir(cantCreateDir);
            }
        });
    }

    public void testComputeSubFolder() {
    	final List files = new ArrayList();
        final File reportBaseDir = new File("dummy")
        {
        	public File[] listFiles() {
        		return (File[]) files.toArray(new File[] {});
        	}
        };
        final WebtestTask webTest = new WebtestTask();
        final Project project = new Project();
        final Context context = new Context(webTest);
        Configuration config = new Configuration();
        config.setProject(project);
        config.setContext(context);
        
        assertEquals(context, config.getContext());
        
        webTest.setName("foo");
        assertEquals(1, config.getResultFolderIndex(reportBaseDir));
        assertEquals("001_Foo", config.computeSubFolder(reportBaseDir).getName());
        
        webTest.setName("first test - blabla");
        assertEquals(1, config.getResultFolderIndex(reportBaseDir));
        assertEquals("001_FirstTestBlabla", config.computeSubFolder(reportBaseDir).getName());

        files.add(new File("001_blabla"));
        config.setResultFolderIndex(-1); // force to compute
        assertEquals(2, config.getResultFolderIndex(reportBaseDir));
        assertEquals("002_FirstTestBlabla", config.computeSubFolder(reportBaseDir).getName());

        files.add(new File("002_Xdkf"));
        files.add(new File("003_Zfkss"));
        files.add(new File("029_AnotherTest"));
        config.setResultFolderIndex(-1); // force to compute
        assertEquals(30, config.getResultFolderIndex(reportBaseDir));
        assertEquals("030_FirstTestBlabla", config.computeSubFolder(reportBaseDir).getName());

        // already 999 files with same webtest name (cf WT-413)
        for (int i=0; i<1000; ++i)
        {
        	final String prefix = StringUtils.leftPad(String.valueOf(i), 3, '0');
        	files.add(new File(prefix + "_justATest"));
        }
        config.setResultFolderIndex(-1); // force to compute
        assertEquals(1000, config.getResultFolderIndex(reportBaseDir));
        assertEquals("1000_FirstTestBlabla", config.computeSubFolder(reportBaseDir).getName());
    	files.add(new File("1000_FirstTestBlabla"));
        config.setResultFolderIndex(-1); // force to compute
        assertEquals(1001, config.getResultFolderIndex(reportBaseDir));
        assertEquals("1001_FirstTestBlabla", config.computeSubFolder(reportBaseDir).getName());
        
        // listFiles returns null "if this abstract pathname does not denote a directory"
        final File reportBaseDir2 = new File("dummy")
        {
        	public File[] listFiles() {
        		return null;
        	}
        };
        config.setResultFolderIndex(-1); // force to compute
        assertEquals("001_FirstTestBlabla", config.computeSubFolder(reportBaseDir2).getName());
    }

    public void testNoProxyHandling() throws CredentialsNotAvailableException {
        assertNull(getCredentials());
    }

    public void testProxyHandling() throws CredentialsNotAvailableException {
        System.setProperty("http.proxyUser", "user");
        System.setProperty("http.proxyPassword", "password");
        assertNotNull(getCredentials());
    }

    public void testDefaultPropertiesFromProject_NoConfig() {
    	final Project project = new Project();
    	
    	setProperties(project, "wt.config.", PROPERTIES_BOOL, "true");
    	setProperties(project, "wt.config.", PROPERTIES_STRING, "blabla");
    	setProperties(project, "wt.config.", PROPERTIES_INT, "1234");
    	project.setProperty("wt.config.protocol", "https");
    	project.setProperty("wt.config.defaultpropertytype", "ant");
    	
    	
    	WebtestTask webTest = new WebtestTask();
    	webTest.setProject(project);
    	webTest.addTask(new Echo()); // just to trigger creation of default config
    	
    	Configuration config = webTest.getConfig();
        verifyProperties(config, true, 1234, "blabla", "https", "ant");

        // change property values to be sure that this info is considered
    	setProperties(project, "wt.config.", PROPERTIES_BOOL, "false");
    	setProperties(project, "wt.config.", PROPERTIES_STRING, "foo");
    	setProperties(project, "wt.config.", PROPERTIES_INT, "4321");
    	project.setProperty("wt.config.protocol", "http");
    	project.setProperty("wt.config.defaultpropertytype", "dynamic");

    	webTest = new WebtestTask();
    	webTest.setProject(project);
    	webTest.addTask(new Echo()); // just to trigger creation of default config

    	config = webTest.getConfig();
        verifyProperties(config, false, 4321, "foo", "http", "dynamic");
    }

    public void testDefaultPropertiesFromProject_ConfigUsed() {
    	final Project project = new Project();
    	
    	setProperties(project, "wt.config.", PROPERTIES_BOOL, "true");
    	setProperties(project, "wt.config.", PROPERTIES_STRING, "blabla");
    	setProperties(project, "wt.config.", PROPERTIES_INT, "1234");
    	project.setProperty("wt.config.protocol", "https");
    	project.setProperty("wt.config.defaultpropertytype", "ant");
    	
    	
    	WebtestTask webTest = new WebtestTask();
    	webTest.setProject(project);
    	
    	final RuntimeConfigurable rc = new RuntimeConfigurable(null, "config");
    	rc.setAttribute("host", "myHost");
    	rc.setAttribute("port", "8080");
    	Configuration config = new Configuration();
    	config.setProject(project);
    	config.setRuntimeConfigurableWrapper(rc);
    	config.setHost("myHost");
    	config.setPort(8080);
    	config.init();
    	webTest.addConfig(config);

    	// test some properties that have been set form project's properties
    	assertEquals(true, config.isHaltOnError());
    	assertEquals(true, config.isShowHtmlParserOutput());
    	assertEquals(1234, config.getTimeout());
    	assertEquals("blabla", config.getBasePath());
    	assertEquals("blabla", config.getFailureProperty());
    	
    	// but that the ones explicitely configured haven't been overwritten
    	assertEquals("myHost", config.getHost());
    	assertEquals(8080, config.getPort());
    }

    private void verifyProperties(final Configuration config, final boolean bValue, final int intValue, final String strValue,
			final String protocol, final String propertyType) {
		assertEquals("autorefresh", String.valueOf(bValue), config.getAutoRefresh());
        assertEquals("haltonerror", bValue, config.isHaltOnError());
        assertEquals("haltonfailure", bValue, config.isHaltOnFailure());
        assertEquals("saveresponse", bValue, config.isSaveResponse());
        assertEquals("showhtmlparseroutput", bValue, config.isShowHtmlParserOutput());
        assertEquals("summary", bValue, config.isSummary());

        assertEquals("port", intValue, config.getPort());
        assertEquals("timeout", intValue, config.getTimeout());

        assertEquals("basepath", strValue, config.getBasePath());
        assertEquals("errorproperty", strValue, config.getErrorProperty());
        assertEquals("failureproperty", strValue, config.getFailureProperty());
        assertEquals("host", strValue, config.getHost());
        assertEquals("resultpath", strValue, config.getResultpath().getName());
        assertEquals("saveprefix", strValue, config.getSavePrefix());
        
        assertEquals("protocol", protocol, config.getProtocol());
        assertEquals("defaultpropertytype", propertyType, config.getDefaultPropertyType());
	}

    /**
     * Set the values on all properties
     */
    private void setProperties(final Project project, final String prefix, final String[] properties, final String value) {
    	for (int i = 0; i < properties.length; i++) {
			project.setProperty(prefix + properties[i], value);
		}
    	
    	assertEquals(value, project.getProperty(prefix + properties[0])); // just to test that it has been set
	}

	private static Credentials getCredentials() throws CredentialsNotAvailableException {
        System.setProperty("http.proxyHost", "dummyHost");
        WebClient wc = Configuration.setupWebClient(BrowserVersion.INTERNET_EXPLORER_6);
        return wc.getCredentialsProvider().getCredentials(new BasicScheme(), "dummyHost", 80, true);
    }

	public void testProxySettings() {
        System.setProperty("http.proxyHost", "dummyHost");
        System.setProperty("http.nonProxyHosts", "myhost.mydomain|*.myotherdomain.com");
        final List<String> proxyBypassPatterns = new ArrayList<String>();
        
        ProxyConfig proxyConfig = new ProxyConfig() {
        	public void addHostsToProxyBypass(final String _pattern)
        	{
        		proxyBypassPatterns.add(_pattern);
        		super.addHostsToProxyBypass(_pattern);
        	}
        };
        final WebClient webClient = new WebClient();
        webClient.setProxyConfig(proxyConfig);
		final DefaultCredentialsProvider credentialProvider = new DefaultCredentialsProvider();
        Configuration.configureProxy(webClient, credentialProvider);
        assertEquals(2, proxyBypassPatterns.size());
        assertEquals("myhost\\.mydomain", proxyBypassPatterns.get(0));
        assertEquals(".*\\.myotherdomain\\.com", proxyBypassPatterns.get(1));
	}
	
	public void testUseInsecureSSL()
	{
		// default => secure
		Configuration config = new Configuration();
		config.createWebClient();
		assertEquals(SSLProtocolSocketFactory.class, Protocol.getProtocol("https").getSocketFactory().getClass());

		// default => secure
		config = new Configuration();
		config.setUseInsecureSSL(true);
		config.createWebClient();
		assertEquals(InsecureSSLProtocolSocketFactory.class, Protocol.getProtocol("https").getSocketFactory().getClass());
	}

	public void testSetupBrowserVersion()
	{
//		assertSame(BrowserVersion.INTERNET_EXPLORER_6, Configuration.setupBrowserVersion(null, null));
//		assertSame(BrowserVersion.INTERNET_EXPLORER_6, Configuration.setupBrowserVersion("IE6", null));
//		assertSame(BrowserVersion.INTERNET_EXPLORER_6, Configuration.setupBrowserVersion("ie6", null));
//		assertSame(BrowserVersion.INTERNET_EXPLORER_6, Configuration.setupBrowserVersion("InternetExplorer6", null));

		assertSame(BrowserVersion.INTERNET_EXPLORER_7, Configuration.setupBrowserVersion("IE7", null));
		assertSame(BrowserVersion.INTERNET_EXPLORER_7, Configuration.setupBrowserVersion("ie7", null));
		assertSame(BrowserVersion.INTERNET_EXPLORER_7, Configuration.setupBrowserVersion("InternetExplorer7", null));

		assertSame(BrowserVersion.FIREFOX_2, Configuration.setupBrowserVersion("FF2", null));
		assertSame(BrowserVersion.FIREFOX_2, Configuration.setupBrowserVersion("ff2", null));
		assertSame(BrowserVersion.FIREFOX_2, Configuration.setupBrowserVersion("Firefox2", null));

		assertSame(BrowserVersion.FIREFOX_3, Configuration.setupBrowserVersion("FF3", null));
		assertSame(BrowserVersion.FIREFOX_3, Configuration.setupBrowserVersion("ff3", null));
		assertSame(BrowserVersion.FIREFOX_3, Configuration.setupBrowserVersion("Firefox3", null));

		BrowserVersion browser = Configuration.setupBrowserVersion("FF3", "myBrowser");
		assertEquals(BrowserVersion.FIREFOX_3.getApplicationCodeName(), browser.getApplicationCodeName());
		assertEquals(BrowserVersion.FIREFOX_3.getApplicationMinorVersion(), browser.getApplicationMinorVersion());
		assertEquals(BrowserVersion.FIREFOX_3.getApplicationName(), browser.getApplicationName());
		assertEquals(BrowserVersion.FIREFOX_3.getApplicationVersion(), browser.getApplicationVersion());
		assertEquals(BrowserVersion.FIREFOX_3.getBrowserLanguage(), browser.getBrowserLanguage());
		assertEquals(BrowserVersion.FIREFOX_3.getBrowserVersionNumeric(), browser.getBrowserVersionNumeric());
		assertEquals("myBrowser", browser.getUserAgent());
	}
}
