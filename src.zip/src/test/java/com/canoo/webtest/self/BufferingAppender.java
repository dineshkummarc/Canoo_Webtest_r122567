// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.self;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Appender conserving the received log messages what allows test to ask him
 * after execution of test code.
 * @author Marc Guillemot
 */
public class BufferingAppender extends AppenderSkeleton
{
	private List fEvents = new Vector();

	public boolean requiresLayout()
	{
		return false;
	}

	public void close()
	{
		// nothing to do
	}

	protected void append(final LoggingEvent event)
	{
		fEvents.add(event);
	}

	/**
	 * Gets the list of received events
	 * @return a list of {@link LoggingEvent}
	 */
	public List getEvents()
	{
		return fEvents;
	}

	/**
	 * Gets a string containing all messages received.
	 */
	public String allMessagesToString()
	{
		StringBuffer sb = new StringBuffer();
		for (Iterator iter = fEvents.iterator(); iter.hasNext();)
		{
			LoggingEvent elt = (LoggingEvent) iter.next();
			sb.append(elt.getMessage());
			if (iter.hasNext())
				sb.append("\n");
		}
		return sb.toString();
	}

	/**
	 * Indicates if one of the received events has the given message
	 */
	public boolean containsMessage(final String message)
	{
		for (Iterator iter = fEvents.iterator(); iter.hasNext();)
		{
			LoggingEvent elt = (LoggingEvent) iter.next();
			if (message.equals(elt.getMessage()))
				return true;
		}
		return false;
	}
}