// Copyright � 2002-2005 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.self;

public interface TestBlock
{
	void call() throws Throwable;
}
