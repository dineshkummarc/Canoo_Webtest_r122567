// Copyright � 2002-2007 Canoo Engineering AG, Switzerland.
package com.canoo.webtest.ant;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.tools.ant.Project;

/**
 * Unit tests for {@link WebtestPropertyHelper}.
 * @author Marc Guillemot
 */
public class WebTestPropertyHelperTest extends TestCase
{
	private WebtestPropertyHelper helper;
	public void testReplaceProperties()
	{
		final Project project = new Project();
		final Map dynProperties = new HashMap();
		helper = new WebtestPropertyHelper(project)
		{
			Map getDynamicProperties() 
			{
				return dynProperties;
			}
		};
		
		testReplacement("testtool", "testtool");
		testReplacement("testtool browser", "testtool browser");
		testReplacement("${testtool} #{browser}", "${testtool} #{browser}");
		testReplacement("${testtool.built.on.#{browser}}", "${testtool.built.on.#{browser}}");
		testReplacement("#{browser.of.${testtool}}", "#{browser.of.${testtool}}");

		// define ant property "testtool"
		project.setProperty("testtool", "WebTest");
		testReplacement("testtool", "testtool");
		testReplacement("testtool browser", "testtool browser");
		testReplacement("WebTest #{browser}", "${testtool} #{browser}");
		testReplacement("${testtool.built.on.#{browser}}", "${testtool.built.on.#{browser}}");
		testReplacement("#{browser.of.WebTest}", "#{browser.of.${testtool}}");

		// define dynamic property "browser"
		dynProperties.put("browser", "HtmlUnit");
		testReplacement("testtool", "testtool");
		testReplacement("testtool browser", "testtool browser");
		testReplacement("WebTest HtmlUnit", "${testtool} #{browser}");
		testReplacement("${testtool.built.on.HtmlUnit}", "${testtool.built.on.#{browser}}");
		testReplacement("#{browser.of.WebTest}", "#{browser.of.${testtool}}");

		// define dynamic property "browser.of.WebTest"
		dynProperties.put("browser.of.WebTest", "embedded HtmlUnit");
		testReplacement("embedded HtmlUnit", "#{browser.of.${testtool}}");

		// define ant property "testtool.built.on.HtmlUnit"
		project.setNewProperty("testtool.built.on.HtmlUnit", "WebTest");
		testReplacement("WebTest", "${testtool.built.on.#{browser}}");
		
		// misc tests
		dynProperties.put("foo", "#{foo}");
		testReplacement("#{foo}", "#{foo}");

		dynProperties.put("foo2", "#{foo}");
		testReplacement("#{foo}", "#{foo2}");

		project.setProperty("bla", "${bla}");
		testReplacement("${bla}", "${bla}");

		project.setProperty("bla", "#{foo}");
		testReplacement("#{foo}", "${bla}");
	}

	private void testReplacement(final String expected, final String original) {
		assertEquals(expected, helper.replaceProperties(null, original, null));
	}
}
